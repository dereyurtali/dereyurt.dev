#include "mainwindow.h"

#include <QApplication>
#include <QLockFile>
#include <QDir>
#include <QMessageBox>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.setApplicationName("HEDAP");
    a.setOrganizationName("HEDAP");

    // ── Tek örnek koruması ──────────────────────────────────────────────────
    // Geçici dizinde bir kilit dosyası oluşturulur.
    // İkinci bir örnek açılmaya çalışırsa kilit alınamaz ve program kapanır.
    QLockFile lockFile(QDir::tempPath() + "/HEDAP_instance.lock");
    lockFile.setStaleLockTime(0); // Eski kilidi temizleme — her zaman taze say

    if (!lockFile.tryLock(100))
    {
        QMessageBox::warning(
            nullptr,
            "HEDAP – Already Running",
            "HEDAP is already open.\n\nOnly one instance can run at a time."
        );
        return 1;
    }
    // ───────────────────────────────────────────────────────────────────────

    MainWindow w;
    w.show();
    return a.exec();

    // lockFile kapsam dışına çıkınca otomatik serbest bırakılır
}
