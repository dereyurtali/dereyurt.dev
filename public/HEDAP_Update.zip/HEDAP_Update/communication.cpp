#include "communication.h"
#include "ui_communication.h"

Communication::Communication(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Communication)
    , m_port(new QSerialPort(this))
{
    ui->setupUi(this);
    setWindowTitle("Communication");

    // Baud rate seçeneklerini ekle
    ui->comboBox_baudrate->addItems({"9600", "19200", "38400", "57600", "115200"});
    ui->comboBox_baudrate->setCurrentText("115200");

    // Portları listele
    portlariListele();

    // Veri gelince veriGeldi() çağrılsın
    connect(m_port, &QSerialPort::readyRead, this, &Communication::veriGeldi);
}

Communication::~Communication()
{
    if (m_port->isOpen())
        m_port->close();
    delete ui;
}

void Communication::portlariListele()
{
    ui->comboBox_port->clear();
    const auto ports = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &info : ports)
        ui->comboBox_port->addItem(info.portName());

    // Manuel giriş için düzenlenebilir yap
    ui->comboBox_port->setEditable(true);
}

void Communication::on_pushButton_yenile_clicked()
{
    portlariListele();
}

void Communication::on_pushButton_baglan_clicked()
{
    if (!m_bagli) {
        // Bağlan
        m_port->setPortName(ui->comboBox_port->currentText());
        m_port->setBaudRate(ui->comboBox_baudrate->currentText().toInt());
        m_port->setDataBits(QSerialPort::Data8);
        m_port->setParity(QSerialPort::NoParity);
        m_port->setStopBits(QSerialPort::OneStop);
        m_port->setFlowControl(QSerialPort::NoFlowControl);

        if (m_port->open(QIODevice::ReadWrite)) {
            m_bagli = true;
            ui->pushButton_baglan->setText("Bağlantıyı Kes");
            ui->textEdit_mesajlar->append(">> Bağlandı: " + ui->comboBox_port->currentText());
        } else {
            ui->textEdit_mesajlar->append(">> Hata: Port açılamadı!");
        }
    } else {
        // Bağlantıyı kes
        m_port->close();
        m_bagli = false;
        ui->pushButton_baglan->setText("Bağlan");
        ui->textEdit_mesajlar->append(">> Bağlantı kesildi.");
    }
}

void Communication::on_pushButton_gonder_clicked()
{
    if (!m_bagli) {
        ui->textEdit_mesajlar->append(">> Önce bağlanın!");
        return;
    }

    QString mesaj = ui->lineEdit_gonder->text();
    if (mesaj.isEmpty()) return;

    m_port->write((mesaj + "\n").toUtf8());
    ui->textEdit_mesajlar->append(">> Gönderildi: " + mesaj);
    ui->lineEdit_gonder->clear();
}

void Communication::veriGeldi()
{
    QByteArray veri = m_port->readAll();
    ui->textEdit_mesajlar->append("<< Alındı: " + QString::fromUtf8(veri).trimmed());
}
