#ifndef COMMUNICATION_H
#define COMMUNICATION_H

#include <QWidget>
#include <QSerialPort>
#include <QSerialPortInfo>

namespace Ui {
class Communication;
}

class Communication : public QWidget
{
    Q_OBJECT

public:
    explicit Communication(QWidget *parent = nullptr);
    ~Communication();


private slots:
    void on_pushButton_yenile_clicked();
    void on_pushButton_baglan_clicked();
    void on_pushButton_gonder_clicked();
    void veriGeldi();

private:
    Ui::Communication *ui;
    QSerialPort *m_port;
    bool m_bagli = false;

    void portlariListele();
};

#endif // COMMUNICATION_H
