#include "configwidget.h"
#include <QButtonGroup>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QTimer>
#include <QVBoxLayout>

ConfigWidget::ConfigWidget(QWidget *parent)
    : QWidget(parent), m_isEditMode(false) {
  setupUI();
}

void ConfigWidget::setupUI() {
  QVBoxLayout *rootLayout = new QVBoxLayout(this);
  rootLayout->setSpacing(10);
  rootLayout->setContentsMargins(12, 12, 12, 12);

  QHBoxLayout *panelsLayout = new QHBoxLayout();
  panelsLayout->setSpacing(12);

  // ── LEFT PANEL: Configuration List ─────────────────────────────────────
  QGroupBox *listGroup = new QGroupBox(this); // title drawn manually below
  QVBoxLayout *listGroupLayout = new QVBoxLayout(listGroup);
  listGroupLayout->setSpacing(8);

  QHBoxLayout *listTitleRow = new QHBoxLayout();
  QLabel *listTitleLabel = new QLabel("Configurations Library", this);
  listTitleLabel->setStyleSheet("font-weight: bold;");
  QPushButton *btnExportDBC = new QPushButton("Export as DBC", this);
  btnExportDBC->setCursor(Qt::PointingHandCursor);
  btnExportDBC->setToolTip("Exports the currently visible decoders as a DBC file.\n"
                           "All → exports all decoders\n"
                           "DBC → exports only DBC-imported decoders\n"
                           "Custom → exports only manually added decoders");
  listTitleRow->addWidget(listTitleLabel);
  listTitleRow->addStretch();
  listTitleRow->addWidget(btnExportDBC);
  listGroupLayout->addLayout(listTitleRow);

  // Filter buttons
  QHBoxLayout *filterRow = new QHBoxLayout();
  auto *btnAll    = new QPushButton("All",    this);
  auto *btnDBC    = new QPushButton("DBC",    this);
  auto *btnCustom = new QPushButton("Custom", this);
  const QString filterStyle =
      "QPushButton { font-size: 11px; padding: 2px 10px; border: 1px solid #555; border-radius: 3px; }"
      "QPushButton:checked { background: #0078D4; color: #FFF; border-color: #0078D4; }";
  for (auto *b : {btnAll, btnDBC, btnCustom}) {
    b->setCheckable(true);
    b->setStyleSheet(filterStyle);
  }
  btnAll->setChecked(true);
  filterRow->addWidget(btnAll);
  filterRow->addWidget(btnDBC);
  filterRow->addWidget(btnCustom);
  filterRow->addStretch();
  listGroupLayout->addLayout(filterRow);

  auto *filterGroup = new QButtonGroup(this);
  filterGroup->addButton(btnAll,    0);
  filterGroup->addButton(btnDBC,    1);
  filterGroup->addButton(btnCustom, 2);
  connect(filterGroup, &QButtonGroup::idClicked, this, [this](int id) {
    m_filterMode = id;
    refreshList();
    clearForm();
  });

  m_listWidget = new QListWidget(this);
  m_listWidget->setStyleSheet("QListWidget::item { padding: 5px 8px; }");
  listGroupLayout->addWidget(m_listWidget);

  QHBoxLayout *listBtnLayout = new QHBoxLayout();
  QPushButton *btnNew = new QPushButton("+  New", this);
  QPushButton *btnDelete = new QPushButton("Delete", this);
  QPushButton *btnDeleteAll = new QPushButton("Delete All", this);
  listBtnLayout->addWidget(btnNew);
  listBtnLayout->addWidget(btnDelete);
  listBtnLayout->addWidget(btnDeleteAll);
  listGroupLayout->addLayout(listBtnLayout);

  // ── RIGHT PANEL: Edit Form ──────────────────────────────────────────────
  QGroupBox *formGroup = new QGroupBox("Config Details", this);
  QVBoxLayout *formLayoutWrapper = new QVBoxLayout(formGroup);
  formLayoutWrapper->setSpacing(10);

  // Mode hint bar — changes depending on whether a config is selected
  m_modeLabel = new QLabel(this);
  m_modeLabel->setWordWrap(true);
  m_modeLabel->setContentsMargins(8, 6, 8, 6);
  m_modeLabel->setStyleSheet(
      "QLabel { background: #2A2D2E; color: #AAAAAA; border-radius: 4px; "
      "         font-size: 12px; padding: 6px 10px; }");
  m_modeLabel->setText("➕  Fill the form below and click <b>Save Config</b> to add a new decoder.");
  formLayoutWrapper->addWidget(m_modeLabel);

  QFormLayout *formLayout = new QFormLayout();
  formLayout->setSpacing(8);
  formLayout->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);

  m_nameEdit = new QLineEdit(this);
  m_nameEdit->setPlaceholderText("e.g. Battery Voltage");

  m_idCombo = new QComboBox(this);
  m_idCombo->setEditable(true);
  m_idCombo->setPlaceholderText("(Optional) Select or type ID");

  m_formulaEdit = new QLineEdit(this);
  m_formulaEdit->setPlaceholderText("x * 0.1  (x = raw decimal value)");

  formLayout->addRow("Config Name:", m_nameEdit);
  formLayout->addRow("Map to ID:", m_idCombo);
  formLayout->addRow("Formula:", m_formulaEdit);
  formLayoutWrapper->addLayout(formLayout);

  // Byte range spinboxes
  QHBoxLayout *spinLayout = new QHBoxLayout();
  m_startSpin = new QSpinBox(this);
  m_startSpin->setRange(0, 7);
  m_startSpin->setPrefix("Start Byte: ");

  m_endSpin = new QSpinBox(this);
  m_endSpin->setRange(0, 7);
  m_endSpin->setPrefix("End Byte: ");
  m_endSpin->setValue(1);

  spinLayout->addWidget(m_startSpin);
  spinLayout->addWidget(m_endSpin);
  formLayoutWrapper->addLayout(spinLayout);

  // Visual preview of byte selection
  QLabel *previewTitle = new QLabel("Byte Selection Preview:", this);
  previewTitle->setStyleSheet(
      "font-weight: 600; font-size: 12px; margin-top: 4px;");
  formLayoutWrapper->addWidget(previewTitle);

  m_previewLabel = new QLabel(this);
  m_previewLabel->setAlignment(Qt::AlignCenter);
  m_previewLabel->setStyleSheet("padding: 8px; font-size: 14px;");
  m_previewLabel->setMinimumHeight(50);
  formLayoutWrapper->addWidget(m_previewLabel);

  m_btnSave = new QPushButton("Save Config", this);
  m_btnSave->setStyleSheet(
      "QPushButton{background:#0078D4;color:#FFF;border:none;padding:5px "
      "16px;font-weight:bold;}QPushButton:hover{background:#106EBE;}");
  formLayoutWrapper->addWidget(m_btnSave);
  formLayoutWrapper->addStretch();

  // ── Assemble ────────────────────────────────────────────────────────────
  panelsLayout->addWidget(listGroup, 1);
  panelsLayout->addWidget(formGroup, 2);
  rootLayout->addLayout(panelsLayout, 1);

  // ── Signals ─────────────────────────────────────────────────────────────
  connect(btnExportDBC, &QPushButton::clicked, this,
          &ConfigWidget::exportAsDbcClicked);
  connect(btnNew, &QPushButton::clicked, this, &ConfigWidget::onNewClicked);
  connect(btnDelete, &QPushButton::clicked, this,
          &ConfigWidget::onDeleteClicked);
  connect(btnDeleteAll, &QPushButton::clicked, this,
          &ConfigWidget::onDeleteAllClicked);
  connect(m_btnSave, &QPushButton::clicked, this, &ConfigWidget::onSaveClicked);
  connect(m_listWidget, &QListWidget::itemClicked, this,
          &ConfigWidget::onItemClicked);
  connect(m_startSpin, QOverload<int>::of(&QSpinBox::valueChanged), this,
          &ConfigWidget::updateVisualPreview);
  connect(m_endSpin, QOverload<int>::of(&QSpinBox::valueChanged), this,
          &ConfigWidget::updateVisualPreview);

  updateVisualPreview();
}

// ─────────────────────────────────────────────────────────────────────────────
void ConfigWidget::setIDList(const QStringList &ids) {
  m_idCombo->clear();
  m_idCombo->addItem(""); // Empty = template only (no ID mapping)
  m_idCombo->addItems(ids);
}

void ConfigWidget::setConfigList(const QVector<HexConfig> &configs) {
  m_configs = configs;
  refreshList();
  clearForm();
}

void ConfigWidget::refreshList() {
  m_listWidget->clear();
  for (int i = 0; i < m_configs.size(); ++i) {
    const HexConfig &c = m_configs[i];
    if (m_filterMode == 1 && !c.isDBC) continue;
    if (m_filterMode == 2 &&  c.isDBC) continue;
    QString label = c.name;
    if (!c.targetID.isEmpty())
      label += QString("  [%1]").arg(c.targetID);
    auto *item = new QListWidgetItem(label);
    item->setData(Qt::UserRole, i);
    m_listWidget->addItem(item);
  }
}

QVector<HexConfig> ConfigWidget::getConfigList() const { return m_configs; }

// ─────────────────────────────────────────────────────────────────────────────
void ConfigWidget::onNewClicked() {
  m_listWidget->clearSelection();
  m_listWidget->setCurrentItem(nullptr);
  m_isEditMode = false;
  clearForm();
  m_nameEdit->setFocus();
}

void ConfigWidget::onDeleteClicked() {
  QListWidgetItem *cur = m_listWidget->currentItem();
  if (!cur)
    return;
  int realIdx = cur->data(Qt::UserRole).toInt();
  if (realIdx < m_configs.size())
    m_configs.removeAt(realIdx);
  refreshList();
  clearForm();
  emit configsUpdated(m_configs);
}

void ConfigWidget::onDeleteAllClicked() {
  if (m_configs.isEmpty())
    return;
  auto reply = QMessageBox::question(
      this, "Delete All Configurations",
      QString("Are you sure you want to delete all %1 decoder "
              "configuration(s)?\nThis action cannot be undone.")
          .arg(m_configs.size()),
      QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
  if (reply == QMessageBox::Yes) {
    m_configs.clear();
    m_listWidget->clear();
    clearForm();
    emit configsUpdated(m_configs);
  }
}

void ConfigWidget::onSaveClicked() {
  QString name = m_nameEdit->text().trimmed();
  QString id = m_idCombo->currentText().trimmed();

  if (name.isEmpty()) {
    QMessageBox::warning(this, "Validation", "Config Name cannot be empty.");
    return;
  }

  HexConfig conf;
  conf.name = name;
  conf.targetID = id;
  conf.formula = m_formulaEdit->text().trimmed();
  conf.startByte = m_startSpin->value();
  conf.endByte = m_endSpin->value();

  QString label = name;
  if (!id.isEmpty())
    label += QString("  [%1]").arg(id);

  if (m_isEditMode && m_listWidget->currentItem()) {
    int realIdx = m_listWidget->currentItem()->data(Qt::UserRole).toInt();
    conf.isDBC = m_configs[realIdx].isDBC; // preserve DBC flag
    m_configs[realIdx] = conf;
    refreshList();
    // re-select the updated item
    for (int i = 0; i < m_listWidget->count(); ++i) {
      if (m_listWidget->item(i)->data(Qt::UserRole).toInt() == realIdx) {
        m_listWidget->setCurrentRow(i);
        break;
      }
    }
  } else {
    m_configs.append(conf);
    refreshList();
    // select the newly added item (last in m_configs, may not be visible under DBC filter)
    int newIdx = m_configs.size() - 1;
    for (int i = 0; i < m_listWidget->count(); ++i) {
      if (m_listWidget->item(i)->data(Qt::UserRole).toInt() == newIdx) {
        m_listWidget->setCurrentRow(i);
        break;
      }
    }
    m_isEditMode = true;
  }
  emit configsUpdated(m_configs);

  // Brief "✓ Saved!" flash on the button
  m_btnSave->setText("✓  Saved!");
  m_btnSave->setStyleSheet(
      "QPushButton{background:#107C10;color:#FFF;border:none;padding:5px "
      "16px;font-weight:bold;}");
  const bool wasEdit = m_isEditMode;
  const QString savedName = name;
  QTimer::singleShot(1500, this, [this, wasEdit, savedName]() {
    m_btnSave->setStyleSheet(
        "QPushButton{background:#0078D4;color:#FFF;border:none;padding:5px "
        "16px;font-weight:bold;}QPushButton:hover{background:#106EBE;}");
    if (wasEdit) {
      m_btnSave->setText("Update Config");
      m_modeLabel->setStyleSheet(
          "QLabel { background: #1A3A5C; color: #4FC3F7; border-radius: 4px; "
          "         font-size: 12px; padding: 6px 10px; }");
      m_modeLabel->setText(
          QString("✏  Editing: <b>%1</b>  — Modify the fields then click <b>Update Config</b>.")
              .arg(savedName.toHtmlEscaped()));
    } else {
      m_btnSave->setText("Save Config");
    }
  });
}

void ConfigWidget::onItemClicked(QListWidgetItem *item) {
  int row = item->data(Qt::UserRole).toInt();
  if (row < 0 || row >= m_configs.size())
    return;

  // Same item clicked again → deselect and return to New mode
  if (row == m_lastClickedRow) {
    m_lastClickedRow = -1;
    m_isEditMode = false;
    m_listWidget->clearSelection();
    m_listWidget->setCurrentItem(nullptr);
    clearForm();
    return;
  }

  m_lastClickedRow = row;
  m_isEditMode = true;
  const HexConfig &c = m_configs[row];
  m_nameEdit->setText(c.name);
  m_idCombo->setCurrentText(c.targetID);
  m_formulaEdit->setText(c.formula);
  m_startSpin->setValue(c.startByte);
  m_endSpin->setValue(c.endByte);
  updateVisualPreview();

  m_modeLabel->setStyleSheet(
      "QLabel { background: #1A3A5C; color: #4FC3F7; border-radius: 4px; "
      "         font-size: 12px; padding: 6px 10px; }");
  m_modeLabel->setText(
      QString("✏  Editing: <b>%1</b>  — Modify the fields then click <b>Update Config</b>.")
          .arg(c.name.toHtmlEscaped()));
  m_btnSave->setText("Update Config");
}

void ConfigWidget::clearForm() {
  m_nameEdit->clear();
  m_idCombo->setCurrentIndex(0);
  m_formulaEdit->clear();
  m_startSpin->setValue(0);
  m_endSpin->setValue(1);
  updateVisualPreview();

  if (m_modeLabel) {
    m_modeLabel->setStyleSheet(
        "QLabel { background: #2A2D2E; color: #AAAAAA; border-radius: 4px; "
        "         font-size: 12px; padding: 6px 10px; }");
    m_modeLabel->setText("➕  Fill the form below and click <b>Save Config</b> to add a new decoder.");
  }
  if (m_btnSave)
    m_btnSave->setText("Save Config");
}

void ConfigWidget::updateVisualPreview() {
  int start = m_startSpin->value();
  int end = m_endSpin->value();
  if (start > end) {
    m_endSpin->setValue(start);
    end = start;
  }

  const QStringList dummy = {"00", "A1", "B2", "C3", "D4", "E5", "F6", "77"};
  QString html = "<html><body style='font-family:Consolas,monospace;'>";
  for (int i = 0; i < 8; i++) {
    if (i >= start && i <= end)
      html += QString("<span "
                      "style='color:#0078D4;font-size:16px;font-weight:bold;'>["
                      "%1]</span> ")
                  .arg(dummy[i]);
    else
      html += QString("<span style='color:#AAAAAA;font-size:14px;'>%1</span> ")
                  .arg(dummy[i]);
  }
  html += "</body></html>";
  m_previewLabel->setText(html);
}
