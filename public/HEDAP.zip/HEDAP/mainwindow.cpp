#include "mainwindow.h"
#include "safeeval.h"
#include "serialworker.h"
#include "ui_mainwindow.h"
#include <algorithm>
#include <QApplication>
#include <QCheckBox>
#include <QColorDialog>
#include <QComboBox>
#include <QDebug>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDrag>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMap>
#include <QMenu>
#include <QMessageBox>
#include <QMimeData>
#include <QPainter>
#include <QPalette>
#include <QProgressBar>
#include <QProgressDialog>
#include <QRadioButton>
#include <QRegularExpression>
#include <QResizeEvent>
#include <QScrollArea>
#include <QSet>
#include <QSplitter>
#include <QStandardPaths>
#include <QColorDialog>
#include <QDoubleSpinBox>
#include <QKeySequenceEdit>
#include <QSpinBox>
#include <QStyleFactory>
#include <QTableWidget>
#include <QTabWidget>
#include <QTextStream>
#include <QToolButton>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QVBoxLayout>
#include <QDesktopServices>
#include <QTemporaryFile>
#include <QUrl>
#include <functional>
#include <limits>

// Forward declarations for static helpers defined later in this file
static quint32 normaliseCanId(const QString &s);
static bool extractDbcSignalRaw(const QString &hexPayload, int startBit,
                                int bitLength, bool littleEndian, bool isSigned,
                                double &outValue);
static std::pair<double, double> parseLinearFormula(const QString &formula);

// ─────────────────────────────────────────────────────────────────────────────
//  Local drag-enabled table subclasses (used by buildLivePage only)
// ─────────────────────────────────────────────────────────────────────────────
namespace {

// Drags the text from column m_col of the selected row(s) as signal name(s).
class SignalDragTable : public QTableWidget {
  int m_col;

public:
  SignalDragTable(int col, QWidget *p = nullptr) : QTableWidget(p), m_col(col) {
    setDragEnabled(true);
    setSelectionBehavior(QAbstractItemView::SelectRows);
    setSelectionMode(QAbstractItemView::SingleSelection);
  }

protected:
  void startDrag(Qt::DropActions) override {
    QStringList names;
    QSet<int> seen;
    for (QTableWidgetItem *it : selectedItems()) {
      if (seen.contains(it->row()))
        continue;
      seen.insert(it->row());
      if (QTableWidgetItem *si = item(it->row(), m_col))
        if (!si->text().isEmpty())
          names << si->text();
    }
    if (names.isEmpty())
      return;
    QMimeData *mime = new QMimeData;
    mime->setData("application/x-hedap-signal", names.join(',').toUtf8());
    QDrag *drag = new QDrag(this);
    drag->setMimeData(mime);
    drag->exec(Qt::CopyAction);
  }
};

// Drags all decoded-signal names for the CAN ID in column 0 of the selected
// row.
class MsgRateDragTable : public QTableWidget {
  std::function<QStringList(const QString &)> m_resolver;

public:
  MsgRateDragTable(std::function<QStringList(const QString &)> resolver,
                   QWidget *p = nullptr)
      : QTableWidget(p), m_resolver(std::move(resolver)) {
    setDragEnabled(true);
    setSelectionBehavior(QAbstractItemView::SelectRows);
    setSelectionMode(QAbstractItemView::SingleSelection);
  }

protected:
  void startDrag(Qt::DropActions) override {
    int row = currentRow();
    if (row < 0)
      return;
    QTableWidgetItem *idItem = item(row, 0);
    if (!idItem)
      return;
    QStringList sigs = m_resolver(idItem->text());
    if (sigs.isEmpty())
      return;
    QMimeData *mime = new QMimeData;
    mime->setData("application/x-hedap-signal", sigs.join(',').toUtf8());
    QDrag *drag = new QDrag(this);
    drag->setMimeData(mime);
    drag->exec(Qt::CopyAction);
  }
};

// Drop zone widget: accepts "application/x-hedap-signal" drags and emits a
// signal when a signal name is dropped onto it.
class SignalDropZone : public QFrame {
  Q_OBJECT
public:
  explicit SignalDropZone(QWidget *parent = nullptr) : QFrame(parent) {
    setAcceptDrops(true);
    setMinimumHeight(48);
    setFrameShape(QFrame::StyledPanel);
    setLineWidth(2);
    setStyleSheet("SignalDropZone {"
                  "  background: rgba(0,120,212,0.06);"
                  "  border: 2px dashed rgba(0,120,212,0.35);"
                  "  border-radius: 6px;"
                  "  color: #888;"
                  "  font-size: 12px;"
                  "}");
    m_label = new QLabel("Drop a signal here to open its graph", this);
    m_label->setAlignment(Qt::AlignCenter);
    m_label->setStyleSheet("color: #888; font-size: 12px; border: none;");
    QVBoxLayout *lay = new QVBoxLayout(this);
    lay->setContentsMargins(0, 0, 0, 0);
    lay->addWidget(m_label);
  }

signals:
  void signalDropped(const QString &signalName);

protected:
  void dragEnterEvent(QDragEnterEvent *e) override {
    if (e->mimeData()->hasFormat("application/x-hedap-signal")) {
      e->acceptProposedAction();
      setStyleSheet("SignalDropZone {"
                    "  background: rgba(0,120,212,0.15);"
                    "  border: 2px solid #0078D4;"
                    "  border-radius: 6px;"
                    "}");
    }
  }
  void dragLeaveEvent(QDragLeaveEvent *) override {
    setStyleSheet("SignalDropZone {"
                  "  background: rgba(0,120,212,0.06);"
                  "  border: 2px dashed rgba(0,120,212,0.35);"
                  "  border-radius: 6px;"
                  "}");
  }
  void dropEvent(QDropEvent *e) override {
    setStyleSheet("SignalDropZone {"
                  "  background: rgba(0,120,212,0.06);"
                  "  border: 2px dashed rgba(0,120,212,0.35);"
                  "  border-radius: 6px;"
                  "}");
    QByteArray raw = e->mimeData()->data("application/x-hedap-signal");
    QStringList names = QString::fromUtf8(raw).split(',', Qt::SkipEmptyParts);
    for (const QString &n : names)
      emit signalDropped(n.trimmed());
    e->acceptProposedAction();
  }

private:
  QLabel *m_label;
};

} // namespace

// SignalDropZone uses Q_OBJECT inside an anonymous namespace; pull in the
// generated MOC so the meta-object system can find it at link time.
#include "mainwindow.moc"

static const char *QSS_COMMON = R"(

)";

static void buildLightPalette(QApplication *app) {
  QPalette p;
  p.setColor(QPalette::Window, QColor(0xF0, 0xF0, 0xF0));
  p.setColor(QPalette::WindowText, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::Base, QColor(0xFF, 0xFF, 0xFF));
  p.setColor(QPalette::AlternateBase, QColor(0xF5, 0xF5, 0xF5));
  p.setColor(QPalette::Text, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::BrightText, Qt::white);
  p.setColor(QPalette::Button, QColor(0xE1, 0xE1, 0xE1));
  p.setColor(QPalette::ButtonText, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::Highlight, QColor(0x38, 0x75, 0xD7));
  p.setColor(QPalette::HighlightedText, Qt::white);
  p.setColor(QPalette::ToolTipBase, QColor(0xFF, 0xFF, 0xE0));
  p.setColor(QPalette::ToolTipText, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::Link, QColor(0x00, 0x78, 0xD4));
  p.setColor(QPalette::Mid, QColor(0xC0, 0xC0, 0xC0));
  p.setColor(QPalette::Midlight, QColor(0xD8, 0xD8, 0xD8));
  p.setColor(QPalette::Dark, QColor(0xA0, 0xA0, 0xA0));
  p.setColor(QPalette::Shadow, QColor(0x80, 0x80, 0x80));
  p.setColor(QPalette::Disabled, QPalette::WindowText,
             QColor(0xA0, 0xA0, 0xA0));
  p.setColor(QPalette::Disabled, QPalette::Text, QColor(0xA0, 0xA0, 0xA0));
  p.setColor(QPalette::Disabled, QPalette::ButtonText,
             QColor(0xA0, 0xA0, 0xA0));
  p.setColor(QPalette::Disabled, QPalette::Base, QColor(0xF0, 0xF0, 0xF0));
  app->setPalette(p);
}

static void buildDarkPalette(QApplication *app) {
  QPalette p;
  p.setColor(QPalette::Window, QColor(0x2D, 0x2D, 0x2D));
  p.setColor(QPalette::WindowText, QColor(0xD4, 0xD4, 0xD4));
  p.setColor(QPalette::Base, QColor(0x1E, 0x1E, 0x1E));
  p.setColor(QPalette::AlternateBase, QColor(0x25, 0x25, 0x26));
  p.setColor(QPalette::Text, QColor(0xD4, 0xD4, 0xD4));
  p.setColor(QPalette::BrightText, Qt::white);
  p.setColor(QPalette::Button, QColor(0x3C, 0x3C, 0x3C));
  p.setColor(QPalette::ButtonText, QColor(0xD4, 0xD4, 0xD4));
  p.setColor(QPalette::Highlight, QColor(0x26, 0x4F, 0x78));
  p.setColor(QPalette::HighlightedText, Qt::white);
  p.setColor(QPalette::ToolTipBase, QColor(0x45, 0x45, 0x45));
  p.setColor(QPalette::ToolTipText, QColor(0xD4, 0xD4, 0xD4));
  p.setColor(QPalette::Link, QColor(0x4E, 0xC9, 0xB0));
  p.setColor(QPalette::Mid, QColor(0x55, 0x55, 0x55));
  p.setColor(QPalette::Midlight, QColor(0x44, 0x44, 0x44));
  p.setColor(QPalette::Dark, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::Shadow, QColor(0x14, 0x14, 0x14));
  p.setColor(QPalette::Disabled, QPalette::WindowText,
             QColor(0x60, 0x60, 0x60));
  p.setColor(QPalette::Disabled, QPalette::Text, QColor(0x60, 0x60, 0x60));
  p.setColor(QPalette::Disabled, QPalette::ButtonText,
             QColor(0x60, 0x60, 0x60));
  p.setColor(QPalette::Disabled, QPalette::Base, QColor(0x28, 0x28, 0x28));
  app->setPalette(p);
}

// ─────────────────────────────────────────────────────────────────────────────
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow),
      m_summaryModel(new QStandardItemModel(this)),
      m_resultModel(new QStandardItemModel(this)),
      m_signalTreeModel(new QStandardItemModel(this)), m_sidebar(nullptr),
      m_pages(nullptr), m_actLoadDBC(nullptr), m_actUnloadDBC(nullptr) {
  QApplication::setStyle(QStyleFactory::create("Fusion"));

  ui->setupUi(this);
  setWindowTitle("HEDAP - Hex Data Analysis Platform");

  buildToolbar();
  buildSidebar();
  setupTables();

  // ── Menu bar connections ─────────────────────────────────────────────────
  connect(ui->action_load, &QAction::triggered, this,
          &MainWindow::on_btn_load_clicked);
  connect(ui->action_unload, &QAction::triggered, this,
          &MainWindow::on_btn_unload_clicked);
  connect(ui->action_export_csv, &QAction::triggered, this,
          &MainWindow::on_btn_export_clicked);
  connect(ui->action_export_data, &QAction::triggered, this,
          &MainWindow::on_btn_exportdata_clicked);
  connect(ui->action_filter, &QAction::triggered, this,
          &MainWindow::on_btn_filter_clicked);
  connect(ui->action_reset, &QAction::triggered, this,
          &MainWindow::on_btn_reset_clicked);
  connect(ui->action_conf, &QAction::triggered, this,
          &MainWindow::on_btn_conf_clicked);
  // Qt's text heuristic on macOS assigns PreferencesRole to any action whose
  // text contains "Configure". Suppress it so action_conf stays out of the
  // HEDAP application menu and our explicit macPref action takes that slot.
  ui->action_conf->setMenuRole(QAction::NoRole);
  connect(ui->action_graph, &QAction::triggered, this,
          &MainWindow::on_btn_graph_clicked);
  connect(ui->action_theme_light, &QAction::triggered, this,
          &MainWindow::onThemeLight);
  connect(ui->action_theme_dark, &QAction::triggered, this,
          &MainWindow::onThemeDark);
  connect(ui->action_load_dbc, &QAction::triggered, this,
          &MainWindow::onLoadDBC);
  connect(ui->action_unload_dbc, &QAction::triggered, this,
          &MainWindow::onUnloadDBC);
  connect(ui->action_export_dbc, &QAction::triggered, this,
          &MainWindow::exportManualDecodersToDBC);
  connect(ui->action_about, &QAction::triggered, this, &MainWindow::onAbout);
  connect(ui->action_user_guide, &QAction::triggered, this, &MainWindow::onUserGuide);
  connect(ui->action_exit, &QAction::triggered, this, &QMainWindow::close);
  connect(ui->action_settings, &QAction::triggered, this,
          &MainWindow::openSettings);
  ui->action_settings->setEnabled(true);

  // On macOS, add a dedicated action with PreferencesRole so "Settings…"
  // appears in the HEDAP application menu (next to About).
  // Separate QAction avoids macOS managing the enabled state of action_settings.
  {
    auto *macPref = new QAction(tr("Settings…"), this);
    macPref->setMenuRole(QAction::PreferencesRole);
    connect(macPref, &QAction::triggered, this, &MainWindow::openSettings);
    menuBar()->addAction(macPref);
  }

  setInterfaceState(false);

  // Default shortcuts — overridden by loadSettings() if user has saved custom ones
  m_settings.shortcuts["action_load"]        = QKeySequence("Ctrl+O");
  m_settings.shortcuts["action_load_dbc"]    = QKeySequence("Ctrl+D");
  m_settings.shortcuts["action_export_csv"]  = QKeySequence("Ctrl+E");
  m_settings.shortcuts["action_filter"]      = QKeySequence("Ctrl+F");
  m_settings.shortcuts["action_conf"]        = QKeySequence("Ctrl+K");
  m_settings.shortcuts["action_graph"]       = QKeySequence("Ctrl+G");
  m_settings.shortcuts["action_settings"]    = QKeySequence("Ctrl+,");

  loadSettings();
  applyTheme(m_isDark);

  loadConfigsFromFile();

  // ── Serial worker ─────────────────────────────────────────────────────────
  m_serialWorker = new SerialWorker(this);
  connect(m_serialWorker, &SerialWorker::lineReceived, this,
          &MainWindow::onSerialLineReceived);
  connect(m_serialWorker, &SerialWorker::connectionChanged, this,
          &MainWindow::onSerialConnChanged);
  connect(m_serialWorker, &SerialWorker::errorOccurred, this,
          &MainWindow::onSerialError);
  connect(m_serialWorker, &SerialWorker::statsUpdated, this,
          &MainWindow::onSerialStats);

  // ── CAN bus worker (PCAN-USB / SocketCAN / etc.) ────────────────────────
  m_canBusWorker = new CanBusWorker(this);
  connect(m_canBusWorker, &CanBusWorker::lineReceived, this,
          &MainWindow::onSerialLineReceived);
  connect(m_canBusWorker, &CanBusWorker::connectionChanged, this,
          &MainWindow::onSerialConnChanged);
  connect(m_canBusWorker, &CanBusWorker::errorOccurred, this,
          &MainWindow::onSerialError);
  connect(m_canBusWorker, &CanBusWorker::statsUpdated, this,
          &MainWindow::onSerialStats);

  m_liveBatchTimer = new QTimer(this);
  m_liveBatchTimer->setInterval(50);
  connect(m_liveBatchTimer, &QTimer::timeout, this,
          &MainWindow::onLiveBatchTimer);
  m_liveBatchTimer->start();

  m_liveMsgRateTimer = new QTimer(this);
  m_liveMsgRateTimer->setInterval(1000);
  connect(m_liveMsgRateTimer, &QTimer::timeout, this,
          &MainWindow::onLiveMsgRateTimer);
  m_liveMsgRateTimer->start();

  m_reconnectTimer = new QTimer(this);
  m_reconnectTimer->setInterval(2000);
  connect(m_reconnectTimer, &QTimer::timeout, this,
          &MainWindow::onReconnectTimer);

  m_liveSimTimer = new QTimer(this);
  m_liveSimTimer->setInterval(100); // 10 fps
  connect(m_liveSimTimer, &QTimer::timeout, this, &MainWindow::onSimTick);

  // ── Start on Home page ───────────────────────────────────────────────────
  switchPage(PAGE_WELCOME);
  restoreLastDBC();
  statusBar()->showMessage("Ready.");
}

MainWindow::~MainWindow() {
  saveSettings();
  stopLiveLog();
  delete ui;
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::buildToolbar() {
  // Point m_act* members at the menu bar actions defined in mainwindow.ui.
  // Connections are made alongside the other ui->action_* connects in the ctor.
  m_actLoad = ui->action_load;
  m_actUnload = ui->action_unload;
  m_actFilter = ui->action_filter;
  m_actReset = ui->action_reset;
  m_actConf = ui->action_conf;
  m_actGraph = ui->action_graph;
  m_actExportCsv = ui->action_export_csv;
  m_actExportData = ui->action_export_data;
  m_actLoadDBC = ui->action_load_dbc;
  m_actUnloadDBC = ui->action_unload_dbc;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Sidebar + page navigation
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::buildSidebar() {
  // ── Create sidebar ───────────────────────────────────────────────────────
  m_sidebar = new QWidget(this);
  m_sidebar->setFixedWidth(140);
  m_sidebar->setObjectName("sidebar");

  QVBoxLayout *sideLayout = new QVBoxLayout(m_sidebar);
  sideLayout->setSpacing(2);
  sideLayout->setContentsMargins(4, 8, 4, 8);

  const QStringList labels = {"Home", "CSV Analysis", "Live Monitor",
                              "Decoders", "Graph"};

  for (int i = 0; i < labels.size(); ++i) {
    QPushButton *btn = new QPushButton(labels[i], m_sidebar);
    btn->setCheckable(true);
    btn->setMinimumHeight(36);
    btn->setCursor(Qt::PointingHandCursor);
    btn->setStyleSheet(
        "QPushButton { text-align: left; padding: 6px 12px; border: none; "
        "              font-size: 12px; border-radius: 4px; }"
        "QPushButton:checked { background: #0078D4; color: #FFF; font-weight: "
        "bold; }"
        "QPushButton:hover:!checked { background: rgba(255,255,255,0.08); }");
    connect(btn, &QPushButton::clicked, this, [this, i] { switchPage(i); });
    sideLayout->addWidget(btn);
    m_navButtons.append(btn);
  }

  sideLayout->addStretch();

  // ── Version label at bottom of sidebar ────────────────────────────────────
  QLabel *verLabel = new QLabel("v1.0", m_sidebar);
  verLabel->setAlignment(Qt::AlignCenter);
  verLabel->setStyleSheet("color: #888; font-size: 10px; padding: 4px;");
  sideLayout->addWidget(verLabel);

  // ── Create stacked widget ────────────────────────────────────────────────
  m_pages = new QStackedWidget(this);
  m_pages->addWidget(buildWelcomePage());  // 0 - Home
  m_pages->addWidget(buildCsvPage());      // 1 - CSV Analysis
  m_pages->addWidget(buildLivePage());     // 2 - Live Monitor
  m_pages->addWidget(buildDecodersPage()); // 3 - Decoders
  m_pages->addWidget(buildGraphPage());    // 4 - Graph

  // ── Replace central widget content ───────────────────────────────────────
  QWidget *container = new QWidget(this);
  QHBoxLayout *mainLayout = new QHBoxLayout(container);
  mainLayout->setSpacing(0);
  mainLayout->setContentsMargins(0, 0, 0, 0);

  QFrame *vLine = new QFrame(container);
  vLine->setFixedWidth(1);
  // semi-transparent line that adapts somewhat to light/dark behind it
  vLine->setStyleSheet("background-color: rgba(128, 128, 128, 0.3);");

  mainLayout->addWidget(m_sidebar);
  mainLayout->addWidget(vLine);
  mainLayout->addWidget(m_pages, 1);
  setCentralWidget(container);
}

void MainWindow::switchPage(int index) {
  if (index < 0 || index >= m_pages->count())
    return;
  m_pages->setCurrentIndex(index);

  // Refresh available serial ports when opening Live Monitor
  if (index == PAGE_LIVE && m_livePortCombo) {
    m_livePortCombo->clear();
    m_livePortCombo->addItems(SerialWorker::availablePorts());
    // Also refresh CAN interfaces
    if (m_canInterfaceCombo && m_canPluginCombo &&
        m_canPluginCombo->count() > 0) {
      m_canInterfaceCombo->clear();
      m_canInterfaceCombo->addItems(
          CanBusWorker::availableInterfaces(m_canPluginCombo->currentText()));
    }
  }

  for (int i = 0; i < m_navButtons.size(); ++i)
    m_navButtons[i]->setChecked(i == index);
}

QWidget *MainWindow::buildWelcomePage() {
  QWidget *page = new QWidget();
  QVBoxLayout *lay = new QVBoxLayout(page);
  lay->setAlignment(Qt::AlignCenter);
  lay->setSpacing(16);

  QLabel *title = new QLabel("HEDAP");
  title->setAlignment(Qt::AlignCenter);
  title->setStyleSheet(
      "font-size: 36px; font-weight: bold; letter-spacing: 4px;");
  lay->addWidget(title);

  QLabel *subtitle = new QLabel("Hex Data Analysis Platform");
  subtitle->setAlignment(Qt::AlignCenter);
  subtitle->setStyleSheet("font-size: 14px; color: #888;");
  lay->addWidget(subtitle);

  QLabel *ver = new QLabel("Version 1.0");
  ver->setAlignment(Qt::AlignCenter);
  ver->setStyleSheet("font-size: 11px; color: #666; margin-bottom: 24px;");
  lay->addWidget(ver);

  // ── Quick-action buttons ─────────────────────────────────────────────────
  auto makeBtn = [](const QString &text) -> QPushButton * {
    QPushButton *b = new QPushButton(text);
    b->setMinimumSize(220, 40);
    b->setCursor(Qt::PointingHandCursor);
    b->setStyleSheet(
        "QPushButton { background: #0078D4; color: #FFF; border: none; "
        "              border-radius: 4px; font-size: 13px; font-weight: bold; "
        "}"
        "QPushButton:hover { background: #106EBE; }");
    return b;
  };

  QPushButton *btnCsv = makeBtn("Open CSV File");
  QPushButton *btnLive = makeBtn("Connect to Device");

  QHBoxLayout *btnRow = new QHBoxLayout();
  btnRow->setSpacing(12);
  btnRow->addStretch();
  btnRow->addWidget(btnCsv);
  btnRow->addWidget(btnLive);
  btnRow->addStretch();
  lay->addLayout(btnRow);

  connect(btnCsv, &QPushButton::clicked, this, [this] {
    switchPage(PAGE_CSV);
    on_btn_load_clicked();
  });
  connect(btnLive, &QPushButton::clicked, this,
          [this] { switchPage(PAGE_LIVE); });

  return page;
}

QWidget *MainWindow::buildCsvPage() {
  QWidget *page = new QWidget();
  QVBoxLayout *lay = new QVBoxLayout(page);
  lay->setContentsMargins(0, 0, 0, 0);
  lay->setSpacing(0);

  // -- Empty-state overlay (visible when no CSV is loaded) --
  m_csvEmptyState = new QWidget(page);
  QVBoxLayout *emptyLay = new QVBoxLayout(m_csvEmptyState);
  emptyLay->setAlignment(Qt::AlignCenter);
  emptyLay->setSpacing(12);

  QLabel *emptyIcon = new QLabel("No Data Loaded");
  emptyIcon->setAlignment(Qt::AlignCenter);
  emptyIcon->setStyleSheet("font-size: 20px; font-weight: bold; color: #888;");
  emptyLay->addWidget(emptyIcon);

  QLabel *emptyDesc = new QLabel(
      "Load a CSV file to analyze CAN bus data.\n"
      "You can also load a DBC file first for automatic signal decoding.");
  emptyDesc->setAlignment(Qt::AlignCenter);
  emptyDesc->setWordWrap(true);
  emptyDesc->setStyleSheet("font-size: 12px; color: #666; max-width: 400px;");
  emptyLay->addWidget(emptyDesc);

  QPushButton *btnLoad = new QPushButton("Open CSV File");
  btnLoad->setMinimumSize(200, 36);
  btnLoad->setCursor(Qt::PointingHandCursor);
  btnLoad->setStyleSheet(
      "QPushButton { background: #0078D4; color: #FFF; border: none; "
      "              border-radius: 4px; font-size: 13px; font-weight: bold; }"
      "QPushButton:hover { background: #106EBE; }");
  emptyLay->addWidget(btnLoad, 0, Qt::AlignCenter);
  connect(btnLoad, &QPushButton::clicked, this,
          &MainWindow::on_btn_load_clicked);

  lay->addWidget(m_csvEmptyState);

  // -- Decoder guidance overlay (visible when data loaded but no decoders) --
  m_csvDecoderGuide = new QWidget(page);
  QVBoxLayout *guideLay = new QVBoxLayout(m_csvDecoderGuide);
  guideLay->setAlignment(Qt::AlignCenter);
  guideLay->setSpacing(10);

  QLabel *guideTitle = new QLabel("No Decoders Configured");
  guideTitle->setAlignment(Qt::AlignCenter);
  guideTitle->setStyleSheet("font-size: 16px; font-weight: bold; color: #888;");
  guideLay->addWidget(guideTitle);

  QLabel *guideDesc =
      new QLabel("To decode and view signal values, load a DBC file\n"
                 "or configure decoders manually from the Decoders page.");
  guideDesc->setAlignment(Qt::AlignCenter);
  guideDesc->setWordWrap(true);
  guideDesc->setStyleSheet("font-size: 12px; color: #666;");
  guideLay->addWidget(guideDesc);

  auto makeGuideBtn = [](const QString &text) -> QPushButton * {
    QPushButton *b = new QPushButton(text);
    b->setMinimumSize(180, 32);
    b->setCursor(Qt::PointingHandCursor);
    b->setStyleSheet(
        "QPushButton { background: #0078D4; color: #FFF; border: none; "
        "              border-radius: 4px; font-size: 12px; font-weight: bold; "
        "}"
        "QPushButton:hover { background: #106EBE; }");
    return b;
  };

  QHBoxLayout *guideBtnRow = new QHBoxLayout();
  guideBtnRow->setSpacing(10);
  guideBtnRow->addStretch();

  QPushButton *guideDbcBtn = makeGuideBtn("Load DBC File");
  QPushButton *guideConfBtn = makeGuideBtn("Open Decoders");
  guideBtnRow->addWidget(guideDbcBtn);
  guideBtnRow->addWidget(guideConfBtn);
  guideBtnRow->addStretch();
  guideLay->addLayout(guideBtnRow);

  connect(guideDbcBtn, &QPushButton::clicked, this, &MainWindow::onLoadDBC);
  connect(guideConfBtn, &QPushButton::clicked, this,
          [this] { switchPage(PAGE_DECODERS); });

  m_csvDecoderGuide->setVisible(false);
  ui->resultPanelLayout->addWidget(m_csvDecoderGuide);

  // -- Data tables (hidden until CSV is loaded) --
  lay->addWidget(ui->splitter_main);
  ui->splitter_main->setSizes({8000, 8000});
  ui->splitter_main->setVisible(false);

  return page;
}

QWidget *MainWindow::buildLivePage() {
  QWidget *page = new QWidget();
  QVBoxLayout *lay = new QVBoxLayout(page);
  lay->setContentsMargins(8, 8, 8, 8);
  lay->setSpacing(6);

  // ── Top bar: title + connection controls ──────────────────────────────────
  QHBoxLayout *topBar = new QHBoxLayout();
  topBar->setSpacing(6);

  QLabel *header = new QLabel("Live Monitor");
  header->setStyleSheet("font-size: 18px; font-weight: bold;");
  topBar->addWidget(header);
  topBar->addStretch();

  // ── Protocol selector (single unified combo) ─────────────────────────
  m_liveProtoCombo = new QComboBox();
  m_liveProtoCombo->setToolTip("Connection protocol");
  m_liveProtoCombo->addItems({"SLCAN", "UART"});
  if (CanBusWorker::isAvailable())
    m_liveProtoCombo->addItem("PCAN-USB");
  topBar->addWidget(m_liveProtoCombo);

  // ── Serial controls (shown for SLCAN & UART) ──────────────────────────
  m_serialControls = new QWidget();
  QHBoxLayout *serialLay = new QHBoxLayout(m_serialControls);
  serialLay->setContentsMargins(0, 0, 0, 0);
  serialLay->setSpacing(6);

  m_livePortCombo = new QComboBox();
  m_livePortCombo->setMinimumWidth(180);
  m_livePortCombo->setToolTip("Serial port");
  m_livePortCombo->addItems(SerialWorker::availablePorts());
  serialLay->addWidget(m_livePortCombo);

  m_liveBaudCombo = new QComboBox();
  m_liveBaudCombo->setToolTip("Baud rate");
  m_liveBaudCombo->addItems({"9600", "19200", "38400", "57600", "115200",
                             "230400", "460800", "921600", "1000000"});
  m_liveBaudCombo->setCurrentText("115200");
  serialLay->addWidget(m_liveBaudCombo);

  QPushButton *refreshPortsBtn = new QPushButton("\u27f3");
  refreshPortsBtn->setFixedWidth(28);
  refreshPortsBtn->setToolTip("Refresh port list");
  refreshPortsBtn->setCursor(Qt::PointingHandCursor);
  connect(refreshPortsBtn, &QPushButton::clicked, this, [this]() {
    m_livePortCombo->clear();
    m_livePortCombo->addItems(SerialWorker::availablePorts());
  });
  serialLay->addWidget(refreshPortsBtn);
  topBar->addWidget(m_serialControls);

  // ── CAN controls (shown for PCAN-USB) ────────────────────────────────
  m_canControls = new QWidget();
  QHBoxLayout *canLay = new QHBoxLayout(m_canControls);
  canLay->setContentsMargins(0, 0, 0, 0);
  canLay->setSpacing(6);

  m_canPluginCombo = new QComboBox();
  m_canPluginCombo->setToolTip("CAN plugin");
  m_canPluginCombo->setMinimumWidth(120);
  m_canPluginCombo->addItems(CanBusWorker::availablePlugins());
  canLay->addWidget(m_canPluginCombo);

  m_canInterfaceCombo = new QComboBox();
  m_canInterfaceCombo->setToolTip("CAN interface (e.g. usb0)");
  m_canInterfaceCombo->setEditable(true);
  m_canInterfaceCombo->setMinimumWidth(100);
  canLay->addWidget(m_canInterfaceCombo);

  // Helper lambda: populate interface combo with discovered + default entries
  auto refreshCanInterfaces = [this](const QString &plugin) {
    m_canInterfaceCombo->clear();
    QStringList discovered = CanBusWorker::availableInterfaces(plugin);
    m_canInterfaceCombo->addItems(discovered);
    // Add common defaults if not already discovered
    for (const QString &def : {"usb0", "usb1", "usb2", "usb3"}) {
      if (!discovered.contains(def))
        m_canInterfaceCombo->addItem(def);
    }
    m_canInterfaceCombo->setCurrentText(
        discovered.isEmpty() ? "usb0" : discovered.first());
  };

  connect(m_canPluginCombo, &QComboBox::currentTextChanged, this,
          refreshCanInterfaces);
  if (m_canPluginCombo->count() > 0)
    refreshCanInterfaces(m_canPluginCombo->currentText());

  m_canBitrateCombo = new QComboBox();
  m_canBitrateCombo->setToolTip("CAN bitrate");
  m_canBitrateCombo->addItems({"125000", "250000", "500000", "1000000"});
  m_canBitrateCombo->setCurrentText("500000");
  canLay->addWidget(m_canBitrateCombo);

  QPushButton *refreshCanBtn = new QPushButton("\u27f3");
  refreshCanBtn->setFixedWidth(28);
  refreshCanBtn->setToolTip("Refresh CAN interfaces");
  refreshCanBtn->setCursor(Qt::PointingHandCursor);
  connect(refreshCanBtn, &QPushButton::clicked, this, [this]() {
    m_canInterfaceCombo->clear();
    if (m_canPluginCombo->count() > 0)
      m_canInterfaceCombo->addItems(
          CanBusWorker::availableInterfaces(m_canPluginCombo->currentText()));
  });
  canLay->addWidget(refreshCanBtn);

  m_canControls->setVisible(false);
  topBar->addWidget(m_canControls);

  // Toggle controls based on protocol selection
  connect(m_liveProtoCombo, &QComboBox::currentTextChanged, this,
          [this](const QString &proto) {
            bool isCan = (proto == "PCAN-USB");
            m_serialControls->setVisible(!isCan);
            m_canControls->setVisible(isCan);
          });

  // ── Connect button ─────────────────────────────────────────────────────
  m_liveConnectBtn = new QPushButton("Connect");
  m_liveConnectBtn->setMinimumWidth(80);
  m_liveConnectBtn->setCursor(Qt::PointingHandCursor);
  m_liveConnectBtn->setStyleSheet(
      "QPushButton { background: #0078D4; color: #FFF; border: none; "
      "              border-radius: 4px; padding: 4px 14px; font-weight: bold; "
      "}"
      "QPushButton:hover { background: #106EBE; }");
  connect(m_liveConnectBtn, &QPushButton::clicked, this,
          &MainWindow::onLiveConnectClicked);
  topBar->addWidget(m_liveConnectBtn);

  m_liveSimBtn = new QPushButton("\u23ef Simulate");
  m_liveSimBtn->setMinimumWidth(90);
  m_liveSimBtn->setCursor(Qt::PointingHandCursor);
  m_liveSimBtn->setStyleSheet(
      "QPushButton { background: #107C10; color: #FFF; border: none; "
      "              border-radius: 4px; padding: 4px 14px; font-weight: bold; "
      "}"
      "QPushButton:hover { background: #0E6B0E; }");
  connect(m_liveSimBtn, &QPushButton::clicked, this, &MainWindow::onSimToggled);
  topBar->addWidget(m_liveSimBtn);

  topBar->addStretch();

  m_addChartBtn = new QPushButton("+ Add Chart");
  m_addChartBtn->setMinimumHeight(26);
  m_addChartBtn->setCursor(Qt::PointingHandCursor);
  m_addChartBtn->setStyleSheet(
      "QPushButton { background: #0078D4; color: #FFF; border: none; "
      "              border-radius: 4px; font-size: 11px; padding: 2px 10px; }"
      "QPushButton:hover { background: #106EBE; }");
  connect(m_addChartBtn, &QPushButton::clicked, this,
          &MainWindow::onAddChartClicked);
  topBar->addWidget(m_addChartBtn);

  lay->addLayout(topBar);

  // ── Status bar ────────────────────────────────────────────────────────────
  m_liveStatusLabel = new QLabel("○ Disconnected  |  0 fps  |  0 frames");
  m_liveStatusLabel->setStyleSheet(
      "color: #888; font-size: 11px; padding: 2px 0;");
  lay->addWidget(m_liveStatusLabel);

  // ── Decoded signals table + collapsible raw frames (full height) ──────────
  QLabel *decodedHdr = new QLabel(
      "Decoded Signals  —  drag a row onto a chart window to start plotting");
  decodedHdr->setStyleSheet(
      "font-size: 12px; font-weight: bold; padding: 2px 0;");
  lay->addWidget(decodedHdr);

  m_liveDecodedTable = new SignalDragTable(2 /*Signal column*/);
  m_liveDecodedTable->setColumnCount(4);
  m_liveDecodedTable->setHorizontalHeaderLabels(
      {"Time", "ID", "Signal", "Value"});
  m_liveDecodedTable->verticalHeader()->setVisible(false);
  m_liveDecodedTable->verticalHeader()->setDefaultSectionSize(18);
  m_liveDecodedTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
  m_liveDecodedTable->horizontalHeader()->setStretchLastSection(true);
  m_liveDecodedTable->horizontalHeader()->setDefaultSectionSize(100);
  m_liveDecodedTable->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);
  lay->addWidget(m_liveDecodedTable, 1);

  // ── Double-click on decoded signal → open chart ───────────────────────────
  connect(m_liveDecodedTable, &QTableWidget::cellDoubleClicked, this,
          [this](int row, int /*col*/) {
            QTableWidgetItem *sigItem = m_liveDecodedTable->item(row, 2);
            if (sigItem && !sigItem->text().isEmpty())
              openSignalChart(sigItem->text());
          });

  // ── Right-click context menu → "Open Graph" ───────────────────────────────
  m_liveDecodedTable->setContextMenuPolicy(Qt::CustomContextMenu);
  connect(m_liveDecodedTable, &QWidget::customContextMenuRequested, this,
          [this](const QPoint &pos) {
            QTableWidgetItem *sigItem =
                m_liveDecodedTable->item(m_liveDecodedTable->rowAt(pos.y()), 2);
            if (!sigItem || sigItem->text().isEmpty())
              return;
            QString sigName = sigItem->text();
            QMenu menu(this);
            menu.addAction("Open Graph", this,
                           [this, sigName] { openSignalChart(sigName); });
            menu.exec(m_liveDecodedTable->viewport()->mapToGlobal(pos));
          });

  // ── Drop zone: drag a signal here to open its chart ───────────────────────
  SignalDropZone *dropZone = new SignalDropZone(page);
  connect(dropZone, &SignalDropZone::signalDropped, this,
          &MainWindow::openSignalChart);
  lay->addWidget(dropZone);

  QPushButton *rawToggleBtn = new QPushButton("▶  Raw Frames");
  rawToggleBtn->setCheckable(true);
  rawToggleBtn->setChecked(false);
  rawToggleBtn->setFlat(true);
  rawToggleBtn->setCursor(Qt::PointingHandCursor);
  rawToggleBtn->setStyleSheet(
      "QPushButton { text-align: left; font-size: 11px; font-weight: bold; "
      "              padding: 2px 0; border: none; color: #888; }");
  lay->addWidget(rawToggleBtn);

  m_liveRawTable = new QTableWidget();
  m_liveRawTable->setColumnCount(4);
  m_liveRawTable->setHorizontalHeaderLabels({"Time", "ID", "DLC", "Data"});
  m_liveRawTable->verticalHeader()->setVisible(false);
  m_liveRawTable->verticalHeader()->setDefaultSectionSize(18);
  m_liveRawTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
  m_liveRawTable->horizontalHeader()->setStretchLastSection(true);
  m_liveRawTable->horizontalHeader()->setDefaultSectionSize(100);
  m_liveRawTable->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);
  m_liveRawTable->setVisible(false);
  lay->addWidget(m_liveRawTable);

  connect(rawToggleBtn, &QPushButton::toggled, this,
          [this, rawToggleBtn](bool checked) {
            m_liveRawTable->setVisible(checked);
            rawToggleBtn->setText(checked ? "▼  Raw Frames" : "▶  Raw Frames");
          });

  return page;
}

QWidget *MainWindow::buildDecodersPage() {
  QWidget *page = new QWidget();
  QVBoxLayout *lay = new QVBoxLayout(page);
  lay->setContentsMargins(12, 12, 12, 12);
  lay->setSpacing(8);

  // -- Header row --
  QHBoxLayout *headerRow = new QHBoxLayout();
  QLabel *header = new QLabel("Decoders");
  header->setStyleSheet("font-size: 18px; font-weight: bold;");
  headerRow->addWidget(header);
  headerRow->addStretch();
  lay->addLayout(headerRow);

  QLabel *desc =
      new QLabel("Configure byte decoders manually or import from a DBC file.");
  desc->setStyleSheet("color: #888; font-size: 12px; margin-bottom: 8px;");
  desc->setWordWrap(true);
  lay->addWidget(desc);

  // -- Info section --
  m_decoderInfoLabel = new QLabel();
  m_decoderInfoLabel->setAlignment(Qt::AlignCenter);
  m_decoderInfoLabel->setStyleSheet("color: #888; font-size: 13px;");
  updateDBCStatus(); // initialize label text
  lay->addWidget(m_decoderInfoLabel);

  // -- Embed Config Widget --
  m_configWidget = new ConfigWidget(this);
  m_configWidget->setConfigList(m_savedConfigs);
  m_configWidget->setIDList(allKnownIDs());

  connect(m_configWidget, &ConfigWidget::configsUpdated, this,
          [this](const QVector<HexConfig> &configs) {
            m_savedConfigs = configs;
            saveConfigsToFile();
            calculateAndPopulateResultTable();
            setInterfaceState(!m_allData.isEmpty());
            updateDBCStatus();
            statusBar()->showMessage("Decoder configurations saved.");
          });
  connect(m_configWidget, &ConfigWidget::exportAsDbcClicked, this,
          &MainWindow::exportManualDecodersToDBC);

  lay->addWidget(m_configWidget, 1);
  return page;
}

QWidget *MainWindow::buildGraphPage() {
  QWidget *page = new QWidget();
  QVBoxLayout *mainLay = new QVBoxLayout(page);
  mainLay->setContentsMargins(8, 8, 8, 8);
  mainLay->setSpacing(6);

  // -- Top bar: title + buttons --
  QHBoxLayout *topBar = new QHBoxLayout();
  QLabel *header = new QLabel("Graph");
  header->setStyleSheet("font-size: 18px; font-weight: bold;");
  topBar->addWidget(header);
  topBar->addStretch();

  auto makeBtn = [](const QString &text) -> QPushButton * {
    QPushButton *b = new QPushButton(text);
    b->setMinimumHeight(28);
    b->setCursor(Qt::PointingHandCursor);
    b->setStyleSheet(
        "QPushButton { background: #0078D4; color: #FFF; border: none; "
        "              border-radius: 4px; font-size: 12px; padding: 4px 14px; "
        "}"
        "QPushButton:hover { background: #106EBE; }");
    return b;
  };

  QPushButton *btnRefresh = makeBtn("Refresh Plot");
  QPushButton *btnSave = makeBtn("Save Image");
  topBar->addWidget(btnRefresh);
  topBar->addWidget(btnSave);
  mainLay->addLayout(topBar);

  // -- Content: settings panel (left) + chart (right) --
  QSplitter *splitter = new QSplitter(Qt::Horizontal, page);

  // ── Left: Signal settings panel ──
  QWidget *settingsPanel = new QWidget();
  settingsPanel->setMinimumWidth(220);
  settingsPanel->setMaximumWidth(320);
  QVBoxLayout *settingsLay = new QVBoxLayout(settingsPanel);
  settingsLay->setContentsMargins(4, 4, 4, 4);
  settingsLay->setSpacing(4);

  // ── Data source mode selector (segmented toggle) ──
  QFrame *modeToggle = new QFrame(settingsPanel);
  modeToggle->setObjectName("modeToggle");
  modeToggle->setFixedHeight(32);
  auto *toggleLay = new QHBoxLayout(modeToggle);
  toggleLay->setContentsMargins(3, 3, 3, 3);
  toggleLay->setSpacing(0);

  m_rbGraphCSV  = new QPushButton(tr("CSV Data"),     modeToggle);
  m_rbGraphLive = new QPushButton(tr("Live Session"), modeToggle);

  for (auto *b : {m_rbGraphCSV, m_rbGraphLive}) {
    b->setCheckable(true);
    b->setFlat(true);
    b->setCursor(Qt::PointingHandCursor);
    b->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
  }
  m_rbGraphCSV->setChecked(true);

  auto *btnGroup = new QButtonGroup(modeToggle);
  btnGroup->setExclusive(true);
  btnGroup->addButton(m_rbGraphCSV,  0);
  btnGroup->addButton(m_rbGraphLive, 1);

  toggleLay->addWidget(m_rbGraphCSV);
  toggleLay->addWidget(m_rbGraphLive);

  modeToggle->setStyleSheet(R"(
    QFrame#modeToggle {
        background: palette(mid);
        border-radius: 7px;
    }
    QPushButton {
        border: none;
        border-radius: 5px;
        font-size: 12px;
        color: palette(text);
        background: transparent;
    }
    QPushButton:checked {
        background: palette(highlight);
        color: palette(highlighted-text);
    }
  )");

  settingsLay->addWidget(modeToggle);

  connect(m_rbGraphCSV, &QPushButton::toggled, this, [this](bool checked) {
    if (checked) {
      m_graphDataMode = GraphDataMode::CSV;
      refreshGraphSignalList();
    }
  });
  connect(m_rbGraphLive, &QPushButton::toggled, this, [this](bool checked) {
    if (checked) {
      m_graphDataMode = GraphDataMode::Live;
      refreshGraphSignalList();
    }
  });

  QLabel *sigLabel = new QLabel("Signals");
  sigLabel->setStyleSheet(
      "font-size: 13px; font-weight: bold; margin-bottom: 4px;");
  settingsLay->addWidget(sigLabel);

  // Select All / Unselect All buttons
  QHBoxLayout *selRow = new QHBoxLayout();
  selRow->setSpacing(4);
  auto makeMiniBtn = [](const QString &text) -> QPushButton * {
    QPushButton *b = new QPushButton(text);
    b->setFixedHeight(22);
    b->setCursor(Qt::PointingHandCursor);
    b->setStyleSheet(
        "QPushButton { background: #3A3A3A; color: #CCC; border: 1px solid "
        "#555; "
        "              border-radius: 3px; font-size: 10px; padding: 1px 8px; }"
        "QPushButton:hover { background: #505050; }");
    return b;
  };
  QPushButton *btnSelectAll = makeMiniBtn("Select All");
  QPushButton *btnUnselectAll = makeMiniBtn("Unselect All");
  selRow->addWidget(btnSelectAll);
  selRow->addWidget(btnUnselectAll);
  selRow->addStretch();
  settingsLay->addLayout(selRow);

  connect(btnSelectAll, &QPushButton::clicked, this, [this] {
    for (GraphSeriesConfig &c : m_graphSeriesConfigs)
      c.enabled = true;
    refreshGraphSignalList();
    on_btn_graph_clicked();
  });
  connect(btnUnselectAll, &QPushButton::clicked, this, [this] {
    for (GraphSeriesConfig &c : m_graphSeriesConfigs)
      c.enabled = false;
    refreshGraphSignalList();
    QChart *empty = new QChart();
    empty->setTitle("Load data and configure decoders to see the plot.");
    empty->legend()->hide();
    m_chartView->setChart(empty);
  });

  // Scrollable signal list
  QScrollArea *scrollArea = new QScrollArea();
  scrollArea->setWidgetResizable(true);
  scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
  scrollArea->setFrameShape(QFrame::NoFrame);

  QWidget *scrollContent = new QWidget();
  m_graphSignalListLayout = new QVBoxLayout(scrollContent);
  m_graphSignalListLayout->setContentsMargins(0, 0, 0, 0);
  m_graphSignalListLayout->setSpacing(2);
  m_graphSignalListLayout->addStretch();

  scrollArea->setWidget(scrollContent);
  settingsLay->addWidget(scrollArea, 1);

  splitter->addWidget(settingsPanel);

  // ── Right: Chart view ──
  m_chartView = new DroppableChartView();
  m_chartView->setRenderHint(QPainter::Antialiasing);
  m_chartView->setAcceptDrops(false); // Graph page: drop-to-add not supported

  QChart *emptyChart = new QChart();
  emptyChart->setTitle("Load data and configure decoders to see the plot.");
  emptyChart->legend()->hide();
  m_chartView->setChart(emptyChart);

  splitter->addWidget(m_chartView);
  splitter->setStretchFactor(0, 0); // settings panel: don't stretch
  splitter->setStretchFactor(1, 1); // chart: stretch to fill
  splitter->setSizes({240, 600});

  mainLay->addWidget(splitter, 1);

  // -- Connections --
  connect(btnRefresh, &QPushButton::clicked, this,
          &MainWindow::on_btn_graph_clicked);
  connect(btnSave, &QPushButton::clicked, this, [this] {
    if (!m_chartView)
      return;
    QString p = QFileDialog::getSaveFileName(this, "Save Image", "",
                                             "PNG (*.png);;JPEG (*.jpg)");
    if (!p.isEmpty()) {
      m_chartView->clearHover();
      m_chartView->grab().save(p);
      statusBar()->showMessage("Graph saved: " + p);
    }
  });

  return page;
}

// ─────────────────────────────────────────────────────────────────────────────
// Build/refresh the signal list in the Graph settings panel.
// Called before plotting to discover available decoded signal names.
// ─────────────────────────────────────────────────────────────────────────────
// ═════════════════════════════════════════════════════════════════════════════
//  Live Monitor — slots & helpers
// ═════════════════════════════════════════════════════════════════════════════

static void setLiveIndicatorStyle(QLabel *lbl, bool connected) {
  if (!lbl)
    return;
  if (connected) {
    lbl->setText("● Live");
    lbl->setStyleSheet(
        "QLabel {"
        "  font-size: 10px; font-weight: bold; padding: 2px 10px;"
        "  color: #fff; background-color: #2e7d32;" // Dark green
        "  border: 1px solid #1b5e20; border-radius: 4px;"
        "}");
  } else {
    lbl->setText("○ Offline");
    lbl->setStyleSheet("QLabel {"
                       "  font-size: 10px; padding: 2px 10px;"
                       "  color: #ccc; background-color: #333;" // Dark grey
                       "  border: 1px solid #555; border-radius: 4px;"
                       "}");
  }
}

void MainWindow::onSerialLineReceived(const QString &csvLine) {
  m_livePendingLines.append(csvLine); // buffered; processed by batch timer
}

// ─────────────────────────────────────────────────────────────────────────────
//  Live session streaming log — opens a new CSV file on each connection and
//  streams all incoming raw lines to it. The file can be loaded directly into
//  the CSV Analysis page after the session.
// ─────────────────────────────────────────────────────────────────────────────

// Returns the default base log directory: "hedap_logs" next to HEDAP.app/.exe.
// On macOS the executable lives inside the bundle (HEDAP.app/Contents/MacOS),
// so we climb three levels to reach the directory containing HEDAP.app.
// On Windows/Linux, applicationDirPath() is already the .exe directory.
static QString defaultLogBase() {
  QDir d(QCoreApplication::applicationDirPath());
#ifdef Q_OS_MAC
  d.cdUp(); // MacOS  → Contents
  d.cdUp(); // Contents → HEDAP.app
  d.cdUp(); // HEDAP.app → build dir
#endif
  return d.absolutePath() + "/hedap_logs";
}

void MainWindow::startLiveLog() {
  stopLiveLog();

  // Base dir: user-configured override, or next to HEDAP.app
  QString baseDir = m_settings.logDirectory.isEmpty()
                        ? defaultLogBase()
                        : m_settings.logDirectory;

  // Date subfolder: logs/YYYY-MM-DD/
  QString logDir = baseDir + "/" + QDate::currentDate().toString("yyyy-MM-dd");
  QDir().mkpath(logDir);

  // File: HEDAP_live_HHmmss.csv (date is already encoded in the folder)
  m_liveLogPath = logDir + "/HEDAP_live_" +
                  QTime::currentTime().toString("HHmmss") + ".csv";

  m_liveLogFile = new QFile(m_liveLogPath);
  if (!m_liveLogFile->open(QIODevice::WriteOnly | QIODevice::Text)) {
    delete m_liveLogFile;
    m_liveLogFile = nullptr;
    qWarning() << "[MainWindow] Failed to open live log:" << m_liveLogPath;
    return;
  }
  m_liveLogStream = new QTextStream(m_liveLogFile);
  // Write 8-column header so the file is valid HEDAP CSV
  *m_liveLogStream
      << "ts_iso_ms,epoch_ms,millis,direction,id_hex,frame_type,dlc,data_hex\n";
  qDebug() << "[MainWindow] Live log started:" << m_liveLogPath;
}

void MainWindow::stopLiveLog() {
  if (m_liveLogStream) {
    m_liveLogStream->flush();
    delete m_liveLogStream;
    m_liveLogStream = nullptr;
  }
  if (m_liveLogFile) {
    m_liveLogFile->close();
    delete m_liveLogFile;
    m_liveLogFile = nullptr;
  }
  m_liveLogFlushCtr = 0;
}

void MainWindow::onSerialConnChanged(bool connected) {
  m_liveConnected = connected;
  if (m_liveConnectBtn)
    m_liveConnectBtn->setText(connected ? "Disconnect" : "Connect");
  if (connected) {
    if (m_settings.autoLogOnConnect)
      startLiveLog();
  } else {
    stopLiveLog();
  }
  if (!connected) {
    m_liveTotalFrames = 0;
    m_liveFps = 0;
    m_liveSeenIds.clear();
    // Table kept visible so user can review last values after disconnect

    // Inject a NaN gap so history lines break intentionally if we reconnect
    qint64 nowMs = QDateTime::currentMSecsSinceEpoch();
    for (auto &hist : m_liveHistory) {
      if (!hist.empty()) {
        hist.push_back({nowMs, qQNaN()});
      }
    }
    for (DroppableChartView *cv : m_liveCharts) {
      if (cv)
        cv->addGap(nowMs);
    }
    for (QLabel *lbl : m_liveIndicators) {
      if (lbl)
        setLiveIndicatorStyle(lbl, false);
    }

    bool wasIntentional = m_intentionalDisconnect;
    m_intentionalDisconnect = false;
    if (!wasIntentional && m_settings.autoReconnect &&
        (!m_lastPort.isEmpty() || !m_lastCanPlugin.isEmpty())) {
      m_reconnectTimer->start();
      statusBar()->showMessage("Connection lost. Reconnecting...");
    } else {
      statusBar()->showMessage("Live: disconnected.");
    }
  } else {
    m_reconnectTimer->stop();
    for (QLabel *lbl : m_liveIndicators) {
      if (lbl)
        setLiveIndicatorStyle(lbl, true);
    }
    statusBar()->showMessage(
        m_liveLogPath.isEmpty()
            ? "Live: connected."
            : tr("Live: connected. Recording to: %1").arg(m_liveLogPath));
  }
  updateLiveStatus();
}

void MainWindow::onSerialError(const QString &msg) {
  if (m_reconnectTimer && m_reconnectTimer->isActive())
    return; // suppress noisy errors during reconnect attempts
  statusBar()->showMessage("Serial error: " + msg);
}

void MainWindow::onReconnectTimer() {
  if (!m_lastPort.isEmpty())
    m_serialWorker->connectPort(m_lastPort, m_lastBaud, m_lastProto);
  else if (!m_lastCanPlugin.isEmpty())
    m_canBusWorker->connectDevice(m_lastCanPlugin, m_lastCanIface, m_lastCanBitrate);
  else
    m_reconnectTimer->stop();
}

void MainWindow::onSerialStats(int fps) {
  m_liveFps = fps;
  updateLiveStatus();
}

void MainWindow::updateLiveStatus() {
  if (!m_liveStatusLabel)
    return;
  QString dot = m_liveConnected ? "● Connected" : "○ Disconnected";
  m_liveStatusLabel->setText(QString("%1  |  %2 fps  |  %3 frames")
                                 .arg(dot)
                                 .arg(m_liveFps)
                                 .arg(m_liveTotalFrames));
}

// ─────────────────────────────────────────────────────────────────────────────
//  onLiveBatchTimer — called every 50 ms; processes pending serial lines
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onLiveBatchTimer() {
  if (m_livePendingLines.isEmpty())
    return;

  // MED-2: drop oldest lines if buffer grew too large between ticks
  while (m_livePendingLines.size() > MAX_PENDING_LINES)
    m_livePendingLines.removeFirst();

  QStringList batch = std::move(m_livePendingLines);
  m_liveTotalFrames += batch.size();

  // Stream raw lines to disk log (zero-cost when log not open)
  if (m_liveLogStream) {
    for (const QString &line : batch)
      *m_liveLogStream << line << '\n';
    if (++m_liveLogFlushCtr >= 20) { // flush ~every second (50 ms × 20)
      m_liveLogStream->flush();
      m_liveLogFlushCtr = 0;
    }
  }

  if (!m_liveRawTable || !m_liveDecodedTable)
    return;

  m_liveRawTable->setUpdatesEnabled(false);
  m_liveDecodedTable->setUpdatesEnabled(false);

  // Pre-normalise config IDs once per batch
  QVector<quint32> confNormIds;
  confNormIds.reserve(m_savedConfigs.size());
  for (const HexConfig &c : m_savedConfigs)
    confNormIds.append(normaliseCanId(c.targetID));

  bool newSignalAddedToTable = false;

  for (const QString &csvLine : batch) {
    const auto parts = QStringView(csvLine).split(u',');
    if (parts.size() < 8)
      continue;

    RawData rd;
    rd.isoTime = parts[0].trimmed().toString();
    rd.timestamp = parts[1].trimmed().toLongLong();
    rd.id = parts[4].trimmed().toString();
    rd.dataHex = parts[7].trimmed().toString();
    rd.numericId = normaliseCanId(rd.id);
    rd.cleanHex = rd.dataHex.simplified().replace(" ", "");
    m_liveSeenIds.insert(rd.numericId); // track for late DBC load

    // ── Raw table (cap at 2000 rows) ─────────────────────────────────────
    if (m_liveRawTable->rowCount() >= 2000)
      m_liveRawTable->removeRow(0);
    int rr = m_liveRawTable->rowCount();
    m_liveRawTable->insertRow(rr);

    auto *rrTimeItem = new QTableWidgetItem(rd.isoTime);
    rrTimeItem->setTextAlignment(Qt::AlignCenter);
    m_liveRawTable->setItem(rr, 0, rrTimeItem);

    auto *rrIdItem = new QTableWidgetItem(rd.id);
    rrIdItem->setTextAlignment(Qt::AlignCenter);
    m_liveRawTable->setItem(rr, 1, rrIdItem);

    auto *rrDlcItem =
        new QTableWidgetItem(QString::number(rd.cleanHex.length() / 2));
    rrDlcItem->setTextAlignment(Qt::AlignCenter);
    m_liveRawTable->setItem(rr, 2, rrDlcItem);

    auto *rrDataItem = new QTableWidgetItem(rd.dataHex.trimmed());
    rrDataItem->setTextAlignment(Qt::AlignCenter);
    m_liveRawTable->setItem(rr, 3, rrDataItem);

    // ── Per-ID message rate counter ──────────────────────────────────────
    m_liveMsgRateCurrent[rd.id]++;

    // ── Decode signals ───────────────────────────────────────────────────
    for (int ci = 0; ci < m_savedConfigs.size(); ++ci) {
      if (confNormIds[ci] != rd.numericId)
        continue;

      const HexConfig &conf = m_savedConfigs[ci];
      double rawVal = 0.0;

      if (conf.isDBC) {
        if (!extractDbcSignalRaw(rd.cleanHex, conf.startBit, conf.bitLength,
                                 conf.littleEndian, conf.isSigned, rawVal))
          continue;
      } else {
        int sp = conf.startByte * 2;
        int sl = (conf.endByte - conf.startByte + 1) * 2;
        if (sp + sl > rd.cleanHex.length())
          continue;
        bool ok;
        rawVal = (double)rd.cleanHex.mid(sp, sl).toLongLong(&ok, 16);
        if (!ok)
          continue;
      }
      double finalVal = evaluateFormula(rawVal, conf.formula);

      // Decoded table: one row per signal (grouped by CAN ID), updated in place
      QString key = rd.id + "|" + conf.name;
      int dr;
      if (!m_decodedTableRowMap.contains(key)) {
        dr = m_liveDecodedTable->rowCount();
        m_liveDecodedTable->insertRow(dr);

        auto *idItem = new QTableWidgetItem(rd.id);
        idItem->setTextAlignment(Qt::AlignCenter);
        m_liveDecodedTable->setItem(dr, 1, idItem);

        auto *sigItem = new QTableWidgetItem(conf.name);
        sigItem->setTextAlignment(Qt::AlignCenter);
        m_liveDecodedTable->setItem(dr, 2, sigItem);

        m_decodedTableRowMap[key] = dr;
        newSignalAddedToTable = true;
      } else {
        dr = m_decodedTableRowMap[key];
      }

      auto *timeItem = new QTableWidgetItem(rd.isoTime);
      timeItem->setTextAlignment(Qt::AlignCenter);
      m_liveDecodedTable->setItem(dr, 0, timeItem);

      QTableWidgetItem *valItem =
          new QTableWidgetItem(QString::number(finalVal, 'f', 4));
      valItem->setTextAlignment(Qt::AlignCenter);
      m_liveDecodedTable->setItem(dr, 3, valItem);

      // Store into chart history
      auto &hist = m_liveHistory[conf.name];
      hist.push_back({rd.timestamp, finalVal});
      // Cap at 300 k points per signal (~8.3 h at 10 Hz, ~4.8 MB each).
      // Time-based cutoff removed: disk log handles long-term archiving.
      static constexpr int LIVE_HIST_MAX = 300'000;
      while ((int)hist.size() > LIVE_HIST_MAX)
        hist.pop_front();

      // Gauge
      updateLiveGauge(conf.name, finalVal);

      // Push to charts that track this signal
      for (DroppableChartView *cv : m_liveCharts)
        if (cv->trackedSignals().contains(conf.name))
          cv->appendData(conf.name, rd.timestamp, finalVal);
    }
  }

  // Automatically resize content and add padding for Decoded Signals Table
  // Only execute this when new signals are added to prevent UI jitter
  if (newSignalAddedToTable) {
    for (int i = 0; i < m_liveDecodedTable->columnCount() - 1; ++i) {
      m_liveDecodedTable->resizeColumnToContents(i);
      m_liveDecodedTable->setColumnWidth(i, m_liveDecodedTable->columnWidth(i) +
                                                40);
    }
  }

  m_liveRawTable->setUpdatesEnabled(true);
  m_liveDecodedTable->setUpdatesEnabled(true);
  m_liveRawTable->scrollToBottom();
  updateLiveStatus();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::updateLiveGauge(const QString &name, double value) {
  if (!m_liveGaugesContent)
    return;

  if (!m_gaugeProgressBars.contains(name)) {
    QWidget *row = new QWidget(m_liveGaugesContent);
    QHBoxLayout *rl = new QHBoxLayout(row);
    rl->setContentsMargins(2, 1, 2, 1);
    rl->setSpacing(4);

    QLabel *nameLabel = new QLabel(name + ":");
    nameLabel->setFixedWidth(120);
    nameLabel->setStyleSheet("font-size: 11px;");

    QProgressBar *bar = new QProgressBar();
    bar->setRange(0, 1000);
    bar->setValue(0);
    bar->setTextVisible(false);
    bar->setFixedWidth(120);
    bar->setFixedHeight(14);

    QLabel *valLabel = new QLabel("—");
    valLabel->setFixedWidth(80);
    valLabel->setStyleSheet("font-size: 11px;");

    rl->addWidget(nameLabel);
    rl->addWidget(bar);
    rl->addWidget(valLabel);
    rl->addStretch();

    auto *vlay = qobject_cast<QVBoxLayout *>(m_liveGaugesContent->layout());
    vlay->insertWidget(vlay->count() - 1, row); // before the stretch

    m_gaugeProgressBars[name] = bar;
    m_gaugeValueLabels[name] = valLabel;
    m_gaugeRanges[name] = {value, value};
  }

  auto &range = m_gaugeRanges[name];
  range.first = qMin(range.first, value);
  range.second = qMax(range.second, value);

  double lo = range.first, hi = range.second;
  int barVal = (hi > lo) ? (int)(1000.0 * (value - lo) / (hi - lo)) : 500;
  m_gaugeProgressBars[name]->setValue(qBound(0, barVal, 1000));
  m_gaugeValueLabels[name]->setText(QString::number(value, 'f', m_settings.signalDecimalPlaces));
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onLiveMsgRateTimer() {
  if (!m_liveMsgRateTable)
    return;
  m_liveMsgRateTable->setRowCount(0);
  for (auto it = m_liveMsgRateCurrent.cbegin();
       it != m_liveMsgRateCurrent.cend(); ++it) {
    int row = m_liveMsgRateTable->rowCount();
    m_liveMsgRateTable->insertRow(row);
    m_liveMsgRateTable->setItem(row, 0, new QTableWidgetItem(it.key()));
    QTableWidgetItem *fpsItem =
        new QTableWidgetItem(QString::number(it.value()) + " fps");
    fpsItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
    m_liveMsgRateTable->setItem(row, 1, fpsItem);
  }
  m_liveMsgRateCurrent.clear();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onLiveConnectClicked() {
  if (m_liveConnected) {
    // DISCONNECT — user-initiated, must not trigger auto-reconnect
    m_intentionalDisconnect = true;
    m_reconnectTimer->stop();
    m_serialWorker->disconnectPort();
    m_canBusWorker->disconnectDevice();
    return;
  }

  // CONNECT - Clear historical plot buffer for a fresh start
  m_liveHistory.clear();
  if (m_loadedDbcFile.isEmpty()) {
    int choice = QMessageBox::question(
        this, "No DBC Loaded",
        "No DBC file is loaded \u2014 only raw CAN frames will be "
        "visible.\n\n"
        "Load a DBC file now to decode signals as they arrive?",
        QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel,
        QMessageBox::Yes);
    if (choice == QMessageBox::Cancel)
      return;
    if (choice == QMessageBox::Yes)
      onLoadDBC();
  }

  m_liveSeenIds.clear();

  QString proto = m_liveProtoCombo ? m_liveProtoCombo->currentText() : "SLCAN";

  if (proto == "PCAN-USB") {
    QString plugin =
        m_canPluginCombo ? m_canPluginCombo->currentText() : QString();
    QString iface =
        m_canInterfaceCombo ? m_canInterfaceCombo->currentText() : QString();
    int bitrate =
        m_canBitrateCombo ? m_canBitrateCombo->currentText().toInt() : 500000;
    if (plugin.isEmpty() || iface.isEmpty()) {
      statusBar()->showMessage("No CAN plugin or interface selected.");
      return;
    }
    m_lastCanPlugin  = plugin;
    m_lastCanIface   = iface;
    m_lastCanBitrate = bitrate;
    m_lastPort.clear();
    m_canBusWorker->connectDevice(plugin, iface, bitrate);
  } else {
    // SLCAN or UART
    QString port = m_livePortCombo ? m_livePortCombo->currentText() : QString();
    int baud =
        m_liveBaudCombo ? m_liveBaudCombo->currentText().toInt() : 115200;
    QString serialProto = (proto == "UART") ? "UART" : "CAN_SLCAN";
    if (port.isEmpty()) {
      statusBar()->showMessage("No serial port selected.");
      return;
    }
    m_lastPort  = port;
    m_lastBaud  = baud;
    m_lastProto = serialProto;
    m_lastCanPlugin.clear();
    m_serialWorker->connectPort(port, baud, serialProto);
  }
}
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onAddChartClicked() {
  openSignalChart(); // open an empty chart window
}

// ─────────────────────────────────────────────────────────────────────────────
//  openSignalChart — create a floating live chart window, optionally
//  pre-populated with the given signal.
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::openSignalChart(const QString &signalName) {
  // Create a floating window parented to MainWindow so it closes with the app
  QWidget *win = new QWidget(this, Qt::Window);
  win->setWindowTitle(
      signalName.isEmpty()
          ? QStringLiteral("Live Chart")
          : QStringLiteral("Live Chart \u2014 %1").arg(signalName));
  win->setAttribute(Qt::WA_DeleteOnClose);
  win->resize(800, 450);

  QVBoxLayout *wl = new QVBoxLayout(win);
  wl->setContentsMargins(4, 4, 4, 4);
  wl->setSpacing(2);

  // Toolbar row
  QHBoxLayout *tbRow = new QHBoxLayout();

  QLabel *liveIndicator = new QLabel();
  liveIndicator->setAlignment(Qt::AlignCenter);
  liveIndicator->setToolTip("Live connection status");
  setLiveIndicatorStyle(liveIndicator, m_liveConnected);

  tbRow->addWidget(liveIndicator);
  tbRow->addStretch();

  QPushButton *exportBtn = new QPushButton("Export PNG");
  exportBtn->setToolTip("Save chart as PNG image");
  exportBtn->setStyleSheet("font-size: 10px; padding: 1px 8px; border: 1px "
                           "solid #555; border-radius: 3px;");

  DroppableChartView *cv = new DroppableChartView(win);

  QPushButton *fitBtn = new QPushButton("Fit to Screen");
  fitBtn->setStyleSheet("font-size: 10px; padding: 1px 8px; border: 1px "
                          "solid #555; border-radius: 3px;");
  connect(fitBtn, &QPushButton::clicked, cv, &DroppableChartView::fitToScreen);

  tbRow->addWidget(exportBtn);
  tbRow->addWidget(fitBtn);
  wl->addLayout(tbRow);

  wl->addWidget(cv, 1);

  // Pre-populate with the requested signal
  if (!signalName.isEmpty()) {
    cv->addSignal(signalName);

    // Inject any available historical points backwards into the chart
    if (m_liveHistory.contains(signalName)) {
      QVector<QPair<qint64, double>> vec;
      const auto &hist = m_liveHistory.value(signalName);
      vec.reserve(hist.size());
      for (const auto &pair : hist) {
        vec.append(pair);
      }

      if (m_liveConnected) {
        cv->bulkLoadHistory(signalName, vec);
      } else {
        cv->loadStaticData(signalName, vec);
      }
    }
  }

  m_liveCharts.append(cv);
  m_liveIndicators.append(liveIndicator);

  // Clean up tracking when the window is destroyed
  connect(win, &QObject::destroyed, this, [this, cv, liveIndicator]() {
    m_liveCharts.removeOne(cv);
    m_liveIndicators.removeOne(liveIndicator);
  });

  // connect(fitBtn, ... handled above)
  connect(exportBtn, &QPushButton::clicked, this, [this, cv]() {
    QString path =
        QFileDialog::getSaveFileName(this, "Export Chart",
                                     QDateTime::currentDateTime().toString(
                                         "'chart_'yyyy-MM-dd_HH-mm-ss'.png'"),
                                     "PNG Images (*.png);;All Files (*)");
    if (!path.isEmpty()) {
      const int W = m_settings.exportWidth, H = m_settings.exportHeight;
      QPixmap px(W, H);
      px.fill(cv->palette().color(QPalette::Window));
      QPainter painter(&px);
      painter.setRenderHint(QPainter::Antialiasing);
      cv->chart()->scene()->render(&painter, QRectF(0, 0, W, H),
                                   cv->chart()->scene()->sceneRect());
      painter.end();
      px.save(path);
      statusBar()->showMessage("Chart exported: " + path);
    }
  });

  win->show();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::openCsvSignalChart(const QString &signalName) {
  // Collect (epoch_ms, value) from the already-decoded result model
  QVector<QPair<qint64, double>> pts;
  for (int r = 0; r < m_resultModel->rowCount(); ++r) {
    if (m_resultModel->item(r, 2)->text() != signalName)
      continue;
    qint64 ts = m_resultModel->item(r, 0)->data(Qt::UserRole).toLongLong();
    double val = m_resultModel->item(r, 4)->text().toDouble();
    if (ts == 0)
      continue;
    pts.append({ts, val});
  }
  if (pts.isEmpty())
    return;

  QWidget *win = new QWidget(this, Qt::Window);
  win->setWindowTitle(signalName + " \u2014 CSV Chart");
  win->setAttribute(Qt::WA_DeleteOnClose);
  win->resize(900, 500);

  QVBoxLayout *lay = new QVBoxLayout(win);
  lay->setContentsMargins(8, 8, 8, 8);
  lay->setSpacing(4);

  QHBoxLayout *tbr = new QHBoxLayout();
  tbr->addStretch();
  QPushButton *btnPng = new QPushButton("Export PNG");
  QPushButton *btnFit = new QPushButton("Fit to Screen");
  const QString btnStyle = "font-size: 10px; padding: 1px 8px; border: 1px solid #555; border-radius: 3px;";
  btnPng->setStyleSheet(btnStyle);
  btnFit->setStyleSheet(btnStyle);
  tbr->addWidget(btnPng);
  tbr->addWidget(btnFit);
  lay->addLayout(tbr);

  DroppableChartView *cv = new DroppableChartView(win);
  lay->addWidget(cv);

  cv->loadStaticData(signalName, pts);

  // Apply current settings (thresholds, delta, stats, fixed-Y, rect-zoom)
  cv->setDecimalPlaces(m_settings.signalDecimalPlaces);
  cv->setThresholds(m_settings.thresholds);
  cv->setDeltaModeEnabled(m_settings.deltaModeEnabled);
  cv->setStatsOverlayEnabled(m_settings.statsOverlayEnabled);
  cv->setFixedYAxis(m_settings.fixedYAxis, m_settings.fixedYMin, m_settings.fixedYMax);
  cv->setRectZoomEnabled(m_settings.rectZoomEnabled);

  connect(btnFit, &QPushButton::clicked, cv, &DroppableChartView::fitToScreen);
  connect(btnPng, &QPushButton::clicked, this, [this, cv, signalName]() {
    QString path = QFileDialog::getSaveFileName(
        this, "Export Chart", signalName + ".png", "PNG (*.png)");
    if (path.isEmpty())
      return;
    cv->clearHover();
    QImage img(m_settings.exportWidth, m_settings.exportHeight, QImage::Format_ARGB32);
    img.fill(Qt::white);
    QPainter p(&img);
    cv->render(&p, QRectF(), QRect(0, 0, m_settings.exportWidth, m_settings.exportHeight));
    p.end();
    img.save(path);
    statusBar()->showMessage("Chart saved: " + QFileInfo(path).fileName(),
                             3000);
  });

  win->show();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onSimToggled() {
  if (!m_liveSimActive) {
    // ── Step 1: optionally load a DBC if none is loaded ───────────────────
    if (m_loadedDbcFile.isEmpty()) {
      int choice = QMessageBox::question(
          this, "Load DBC for Decoding?",
          "No DBC file is loaded.\n\n"
          "Without a DBC, only raw frames will be visible.\n"
          "Load a DBC file now to also decode signals?",
          QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel,
          QMessageBox::Yes);
      if (choice == QMessageBox::Cancel)
        return;
      if (choice == QMessageBox::Yes) {
        QString dbcPath = QFileDialog::getOpenFileName(
            this, "Open DBC File", QString(), "DBC Files (*.dbc)");
        if (!dbcPath.isEmpty()) {
          if (m_dbcParser.parse(dbcPath)) {
            m_loadedDbcFile = dbcPath;
            updateDBCStatus();
          } else {
            QMessageBox::warning(this, "DBC Error", m_dbcParser.errorString());
          }
        }
      }
    }

    // ── Step 2: pick the CAN log CSV file ─────────────────────────────────
    QString file = QFileDialog::getOpenFileName(
        this, "Open CAN log for simulation", QString(), "CSV Files (*.csv)");
    if (file.isEmpty())
      return; // cancelled

    QFile f(file);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
      statusBar()->showMessage("Cannot open file: " + file);
      return;
    }
    QTextStream in(&f);
    m_liveSimLines.clear();
    in.readLine(); // skip header row
    while (!in.atEnd()) {
      QString line = in.readLine().trimmed();
      if (!line.isEmpty())
        m_liveSimLines.append(line);
    }
    if (m_liveSimLines.isEmpty()) {
      statusBar()->showMessage("No data lines found in CSV.");
      return;
    }
    m_liveSimLineIdx = 0;
    m_liveTotalFrames = 0;

    // ── Step 3: auto-import DBC signals matching IDs found in the CSV ─────
    if (!m_loadedDbcFile.isEmpty() && !m_dbcParser.messages().isEmpty()) {
      // Collect unique CAN IDs from the first pass of the sim lines
      QSet<quint32> simIds;
      for (const QString &ln : m_liveSimLines) {
        const auto parts = QStringView(ln).split(u',');
        if (parts.size() >= 5)
          simIds.insert(normaliseCanId(parts[4].trimmed().toString()));
      }
      // Remove stale DBC configs, then import matches
      for (int i = m_savedConfigs.size() - 1; i >= 0; --i)
        if (m_savedConfigs[i].isDBC)
          m_savedConfigs.removeAt(i);
      for (const DBCMessage &msg : m_dbcParser.messages()) {
        if (!simIds.contains(msg.rawCanId))
          continue;
        for (const DBCSignal &sig : msg.sigs) {
          HexConfig conf;
          conf.targetID = msg.hexID();
          conf.name = sig.name;
          conf.formula = sig.toFormula();
          conf.isDBC = true;
          conf.startBit = sig.startBit;
          conf.bitLength = sig.length;
          conf.littleEndian = sig.littleEndian;
          conf.isSigned = sig.isSigned;
          conf.startByte = sig.startByte();
          conf.endByte = sig.endByte();
          bool dup = false;
          for (const HexConfig &c : m_savedConfigs)
            if (c.name == conf.name &&
                normaliseCanId(c.targetID) == normaliseCanId(conf.targetID)) {
              dup = true;
              break;
            }
          if (!dup)
            m_savedConfigs.append(conf);
        }
      }
      saveConfigsToFile();
      if (m_configWidget)
        m_configWidget->setConfigList(m_savedConfigs);
      updateDBCStatus();
    }

    m_liveSimActive = true;
    if (m_liveSimBtn)
      m_liveSimBtn->setText("■ Stop Sim");
    if (m_liveConnectBtn)
      m_liveConnectBtn->setEnabled(false);
    m_liveSimTimer->start();
    if (m_liveStatusLabel)
      m_liveStatusLabel->setText("⬤ Simulating  |  0 frames");
  } else {
    m_liveSimActive = false;
    m_liveSimTimer->stop();
    m_liveSimLines.clear();
    // Table kept visible so user can review last values after simulation stops
    if (m_liveSimBtn)
      m_liveSimBtn->setText("⏯ Simulate");
    if (m_liveConnectBtn)
      m_liveConnectBtn->setEnabled(true);
    updateLiveStatus();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Replay ~10 CSV lines per tick (100ms timer → ~100 frames/sec).
//  Timestamps are replaced with "now" so the rolling chart window stays
//  current.
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onSimTick() {
  if (m_liveSimLines.isEmpty())
    return;

  qint64 now = QDateTime::currentMSecsSinceEpoch();
  QString isoNow =
      QDateTime::fromMSecsSinceEpoch(now).toString("yyyy-MM-dd HH:mm:ss.zzz");
  QString epochNow = QString::number(now);

  // Send 10 lines per 100 ms tick
  for (int i = 0; i < 10; ++i) {
    const QString &orig = m_liveSimLines.at(m_liveSimLineIdx);
    m_liveSimLineIdx = (m_liveSimLineIdx + 1) % m_liveSimLines.size();

    // Replace parts[0] (isoTime) and parts[1] (epoch_ms) with current time
    // so the chart's 30-second rolling window shows the data
    int c1 = orig.indexOf(',');
    if (c1 < 0)
      continue;
    int c2 = orig.indexOf(',', c1 + 1);
    if (c2 < 0)
      continue;
    // Build: isoNow + ',' + epochNow + rest_from_second_comma
    QString line = isoNow + ',' + epochNow + orig.mid(c2);
    onSerialLineReceived(line);
  }

  if (m_liveStatusLabel) {
    m_liveStatusLabel->setText(
        QString("⬤ Simulating  |  %1 frames").arg(m_liveTotalFrames));
  }
}

// ─────────────────────────────────────────────────────────────────────────────

static const QColor kDefaultColors[] = {
    QColor("#0078D4"), QColor("#E81123"), QColor("#107C10"), QColor("#FF8C00"),
    QColor("#5C2D91"), QColor("#008272"), QColor("#D13438"), QColor("#0063B1"),
    QColor("#767676"), QColor("#C239B3"),
};

void MainWindow::refreshGraphSignalList() {
  if (!m_graphSignalListLayout)
    return;

  // Signal names depend on the selected data source mode
  QStringList signalNames;
  if (m_graphDataMode == GraphDataMode::Live) {
    signalNames = m_liveHistory.keys();
    signalNames.sort();
  } else {
    // CSV mode: collect unique signal names from the decoded result model
    QSet<QString> signalSet;
    for (int i = 0; i < m_resultModel->rowCount(); ++i)
      signalSet.insert(m_resultModel->item(i, 2)->text());
    signalNames = signalSet.values();
    signalNames.sort();
  }

  // Preserve existing configs, add new ones, remove stale ones
  QMap<QString, GraphSeriesConfig> existing;
  for (const GraphSeriesConfig &c : m_graphSeriesConfigs)
    existing[c.name] = c;

  m_graphSeriesConfigs.clear();
  int colorIdx = 0;
  for (const QString &name : signalNames) {
    if (existing.contains(name)) {
      m_graphSeriesConfigs.append(existing[name]);
    } else {
      GraphSeriesConfig cfg;
      cfg.name = name;
      cfg.enabled = false;
      cfg.color = kDefaultColors[colorIdx % 10];
      cfg.style = 0;
      m_graphSeriesConfigs.append(cfg);
    }
    ++colorIdx;
  }

  // Clear existing UI rows
  QLayoutItem *child;
  while ((child = m_graphSignalListLayout->takeAt(0)) != nullptr) {
    if (child->widget()) {
      child->widget()->deleteLater();
    }
    delete child;
  }

  // Build UI rows for each signal
  for (int i = 0; i < m_graphSeriesConfigs.size(); ++i) {
    GraphSeriesConfig &cfg = m_graphSeriesConfigs[i];

    QWidget *row = new QWidget();
    QHBoxLayout *rowLay = new QHBoxLayout(row);
    rowLay->setContentsMargins(2, 1, 2, 1);
    rowLay->setSpacing(4);

    // Checkbox (enable/disable)
    QCheckBox *chk = new QCheckBox(cfg.name);
    chk->setChecked(cfg.enabled);
    chk->setStyleSheet("font-size: 11px;");
    connect(chk, &QCheckBox::toggled, this, [this, i](bool checked) {
      if (i < m_graphSeriesConfigs.size())
        m_graphSeriesConfigs[i].enabled = checked;
      bool anyEnabled = std::any_of(m_graphSeriesConfigs.begin(),
                                    m_graphSeriesConfigs.end(),
                                    [](const GraphSeriesConfig &c) { return c.enabled; });
      if (anyEnabled)
        on_btn_graph_clicked();
    });
    rowLay->addWidget(chk, 1);

    // Color button
    QPushButton *colorBtn = new QPushButton();
    colorBtn->setFixedSize(20, 20);
    colorBtn->setCursor(Qt::PointingHandCursor);
    colorBtn->setStyleSheet(
        QString("background: %1; border: 1px solid #888; border-radius: 3px;")
            .arg(cfg.color.name()));
    connect(colorBtn, &QPushButton::clicked, this, [this, i, colorBtn] {
      if (i >= m_graphSeriesConfigs.size())
        return;
      QColor c = QColorDialog::getColor(m_graphSeriesConfigs[i].color, this,
                                        "Signal Color");
      if (c.isValid()) {
        m_graphSeriesConfigs[i].color = c;
        colorBtn->setStyleSheet(QString("background: %1; border: 1px "
                                        "solid #888; border-radius: 3px;")
                                    .arg(c.name()));
      }
    });
    rowLay->addWidget(colorBtn);

    // Style combo
    QComboBox *styleCombo = new QComboBox();
    styleCombo->addItems({"Solid", "Dash", "Scatter"});
    styleCombo->setCurrentIndex(cfg.style);
    styleCombo->setFixedWidth(70);
    styleCombo->setStyleSheet("font-size: 10px;");
    connect(styleCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, [this, i](int idx) {
              if (i < m_graphSeriesConfigs.size())
                m_graphSeriesConfigs[i].style = idx;
            });
    rowLay->addWidget(styleCombo);

    m_graphSignalListLayout->addWidget(row);
  }
  m_graphSignalListLayout->addStretch();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::setupTables() {
  ui->tbl_summary->setModel(m_summaryModel);
  ui->tbl_summary->setEditTriggers(QAbstractItemView::NoEditTriggers);
  ui->tbl_summary->verticalHeader()->setVisible(false);
  ui->tbl_summary->verticalHeader()->setDefaultSectionSize(20);
  ui->tbl_summary->setSelectionMode(QAbstractItemView::SingleSelection);

  QHeaderView *sh = ui->tbl_summary->horizontalHeader();
  sh->setHighlightSections(false);
  sh->setStretchLastSection(true);
  sh->setSectionResizeMode(QHeaderView::Interactive);
  sh->setDefaultSectionSize(90);

  ui->tbl_result->setModel(m_signalTreeModel);
  ui->tbl_result->setEditTriggers(QAbstractItemView::NoEditTriggers);
  ui->tbl_result->setSelectionMode(QAbstractItemView::SingleSelection);
  ui->tbl_result->setAlternatingRowColors(true);
  ui->tbl_result->setAnimated(true);
  ui->tbl_result->header()->setStretchLastSection(true);
  ui->tbl_result->header()->setHighlightSections(false);
  ui->tbl_result->header()->setDefaultAlignment(Qt::AlignCenter);

  // Double-click on a signal row → open CSV chart
  connect(ui->tbl_result, &QTreeView::doubleClicked, this,
          [this](const QModelIndex &idx) {
            if (!idx.isValid())
              return;
            QStandardItem *item = m_signalTreeModel->itemFromIndex(idx);
            if (!item || !item->parent())
              return; // skip message-level items
            QString sig = item->data(Qt::UserRole).toString();
            if (!sig.isEmpty())
              openCsvSignalChart(sig);
          });
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::resizeEvent(QResizeEvent *event) {
  QMainWindow::resizeEvent(event);
  resizeSplitterAndColumns();
}

void MainWindow::resizeSplitterAndColumns() {
  int total = ui->splitter_main->width();
  if (total > 100) {
    int half = (total - ui->splitter_main->handleWidth()) / 2;
    ui->splitter_main->setSizes({half, half});
  }

  // Auto-fit columns to content, last column stretches to fill
  if (m_summaryModel->rowCount() > 0) {
    ui->tbl_summary->resizeColumnsToContents();
    // Add extra padding to columns
    for (int i = 0; i < m_summaryModel->columnCount() - 1; ++i) {
      ui->tbl_summary->setColumnWidth(i, ui->tbl_summary->columnWidth(i) + 30);
    }
  }

  // Also auto-fit and pad the Signals by Message tree.
  // It only contains grouped messages so it shouldn't cause the performance
  // issues seen when it historically contained thousands of raw frame rows.
  if (m_signalTreeModel->rowCount() > 0) {
    ui->tbl_result->resizeColumnToContents(0);
    ui->tbl_result->setColumnWidth(0, ui->tbl_result->columnWidth(0) + 40);
    ui->tbl_result->resizeColumnToContents(1);
    ui->tbl_result->setColumnWidth(1, ui->tbl_result->columnWidth(1) + 30);
  }

  // Automatically refresh graph signal list now that tabular data is
  // loaded
  refreshGraphSignalList();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::setInterfaceState(bool hasData) {
  m_actUnload->setEnabled(hasData);
  m_actFilter->setEnabled(hasData);
  m_actReset->setEnabled(hasData);
  m_actConf->setEnabled(hasData);
  m_actGraph->setEnabled(hasData);
  // Export actions stay always enabled — they handle the "no data" case
  // internally and also serve the Live Monitor page.

  // Toggle CSV page: show empty state or data tables
  if (m_csvEmptyState)
    m_csvEmptyState->setVisible(!hasData);

  // Toggle Decoder guidance visually in the right table (result)
  // If we have data, but no rows could be decoded (because no configs or
  // no matches)
  bool showGuide = hasData && (m_resultModel->rowCount() == 0);
  ui->tbl_result->setVisible(!showGuide);
  ui->lbl_result_header->setVisible(!showGuide);
  if (m_csvDecoderGuide)
    m_csvDecoderGuide->setVisible(showGuide);

  if (ui->splitter_main)
    ui->splitter_main->setVisible(hasData);
}

void MainWindow::applyTheme(bool dark) {
  m_isDark = dark;
  if (dark)
    buildDarkPalette(qApp);
  else
    buildLightPalette(qApp);
  setStyleSheet(QSS_COMMON);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ID normalisation: convert any hex/decimal string to uint32 for comparison.
//  Handles: "0x00C", "0x0C", "12", "00C" (bare hex)
// ─────────────────────────────────────────────────────────────────────────────
static quint32 normaliseCanId(const QString &s) {
  QString t = s.trimmed();
  if (t.startsWith("0x") || t.startsWith("0X"))
    return t.mid(2).toUInt(nullptr, 16);
  bool ok = false;
  quint32 v = t.toUInt(&ok, 10);
  if (ok)
    return v;
  // bare hex without prefix (e.g. "00C")
  return t.toUInt(nullptr, 16);
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::parseAndStoreLine(const QString &line) {
  const auto parts = QStringView(line).split(u',');

  if (m_csvIsLiveFormat) {
    // Format: Time,ID,DLC,Data  (live-export 4-column)
    if (parts.size() < 4)
      return;
    RawData data;
    data.isoTime = parts[0].trimmed().toString();
    data.id = parts[1].trimmed().toString();
    // parts[2] = DLC (ignored)
    data.dataHex = parts[3].trimmed().toString();
    QDateTime dt =
        QDateTime::fromString(data.isoTime, "yyyy-MM-dd HH:mm:ss.zzz");
    data.timestamp = dt.isValid() ? dt.toMSecsSinceEpoch() : 0;
    data.numericId = normaliseCanId(data.id);
    data.cleanHex = data.dataHex.simplified().replace(" ", "");
    m_allData.append(data);
  } else {
    // Original format:
    // ts_iso_ms,epoch_ms,millis,direction,id_hex,frame_type,dlc,data_hex
    if (parts.size() < 8)
      return;
    RawData data;
    data.isoTime = parts[0].trimmed().toString();
    data.timestamp = parts[1].trimmed().toLongLong();
    data.id = parts[4].trimmed().toString();
    data.dataHex = parts[7].trimmed().toString();
    data.numericId = normaliseCanId(data.id);
    data.cleanHex = data.dataHex.simplified().replace(" ", "");
    m_allData.append(data);
  }
}

void MainWindow::populateSignalTree() {
  m_signalTreeModel->clear();
  m_signalTreeModel->setHorizontalHeaderLabels(
      {"Signal / Message", "Avg Value", "End Timestamp"});

  if (m_resultModel->rowCount() == 0)
    return;

  // Track the sum, count, and last seen time for each decoded signal
  struct SignalStats {
    double sum = 0.0;
    int count = 0;
    QString lastSeen;
  };
  QHash<QString, SignalStats> signalStats;

  QSet<QString> signalsWithData;
  for (int r = 0; r < m_resultModel->rowCount(); ++r) {
    QString sigName = m_resultModel->item(r, 2)->text();
    QString timeStr = m_resultModel->item(r, 0)->text();
    double val = m_resultModel->item(r, 4)->text().toDouble();

    signalsWithData.insert(sigName);

    // Accumulate sum and overwrite with latest time (assuming chronological
    // order)
    signalStats[sigName].sum += val;
    signalStats[sigName].count += 1;
    signalStats[sigName].lastSeen = timeStr;
  }

  QSet<QString> addedSignals;

  // Group by DBC message
  for (const DBCMessage &msg : m_dbcParser.messages()) {
    QList<QList<QStandardItem *>> sigRows;
    for (const DBCSignal &sig : msg.sigs) {
      if (!signalsWithData.contains(sig.name))
        continue;

      QList<QStandardItem *> rowItems;
      auto *si = new QStandardItem(sig.name);
      si->setData(sig.name, Qt::UserRole);
      si->setEditable(false);
      rowItems << si;

      const SignalStats &stats = signalStats[sig.name];
      double avgValue = stats.count > 0 ? (stats.sum / stats.count) : 0.0;

      auto *valItem = new QStandardItem(QString::number(avgValue, 'f', 4));
      valItem->setEditable(false);
      valItem->setTextAlignment(Qt::AlignCenter);
      rowItems << valItem;

      auto *timeItem = new QStandardItem(stats.lastSeen);
      timeItem->setEditable(false);
      timeItem->setTextAlignment(Qt::AlignCenter);
      rowItems << timeItem;

      sigRows << rowItems;
      addedSignals.insert(sig.name);
    }
    if (sigRows.isEmpty())
      continue;

    QList<QStandardItem *> messageRow;
    auto *mi =
        new QStandardItem(QString("%1  [%2]").arg(msg.name, msg.hexID()));
    mi->setEditable(false);
    messageRow << mi << new QStandardItem("")
               << new QStandardItem(
                      ""); // Empty value and time for the message parent

    for (const auto &row : sigRows)
      mi->appendRow(row);

    m_signalTreeModel->appendRow(messageRow);
  }

  // Manual decoders not in DBC
  QList<QList<QStandardItem *>> manualRows;
  for (const QString &sig : signalsWithData) {
    if (addedSignals.contains(sig))
      continue;

    QList<QStandardItem *> rowItems;
    auto *si = new QStandardItem(sig);
    si->setData(sig, Qt::UserRole);
    si->setEditable(false);
    rowItems << si;

    const SignalStats &stats = signalStats[sig];
    double avgValue = stats.count > 0 ? (stats.sum / stats.count) : 0.0;

    auto *valItem = new QStandardItem(QString::number(avgValue, 'f', 4));
    valItem->setEditable(false);
    valItem->setTextAlignment(Qt::AlignCenter);
    rowItems << valItem;

    auto *timeItem = new QStandardItem(stats.lastSeen);
    timeItem->setEditable(false);
    timeItem->setTextAlignment(Qt::AlignCenter);
    rowItems << timeItem;

    manualRows << rowItems;
  }

  if (!manualRows.isEmpty()) {
    QList<QStandardItem *> messageRow;
    auto *mi = new QStandardItem("Manual Decoders");
    mi->setEditable(false);
    messageRow << mi << new QStandardItem("") << new QStandardItem("");

    for (const auto &row : manualRows)
      mi->appendRow(row);

    m_signalTreeModel->appendRow(messageRow);
  }

  ui->tbl_result->expandAll();
}

void MainWindow::populateSummaryTable(const QStringList &filterIds) {
  m_summaryModel->blockSignals(true);
  m_summaryModel->clear();
  m_summaryModel->setHorizontalHeaderLabels(
      {"ID", "Count", "Start Timestamp", "End Timestamp"});

  struct GroupInfo {
    int count = 0;
    qint64 minEpoch = -1, maxEpoch = -1;
    QString startTime, endTime;
  };
  QHash<QString, GroupInfo> groups;
  groups.reserve(64);

  const bool hasFilter = !filterIds.isEmpty();
  QSet<QString> filterSet;
  if (hasFilter)
    filterSet = QSet<QString>(filterIds.begin(), filterIds.end());

  m_configWidget->setConfigList(m_savedConfigs);
  calculateAndPopulateResultTable();

  for (const RawData &row : m_allData) {
    if (hasFilter && !filterSet.contains(row.id))
      continue;
    GroupInfo &g = groups[row.id];
    g.count++;
    if (g.minEpoch == -1 || row.timestamp < g.minEpoch) {
      g.minEpoch = row.timestamp;
      g.startTime = row.isoTime;
    }
    if (g.maxEpoch == -1 || row.timestamp > g.maxEpoch) {
      g.maxEpoch = row.timestamp;
      g.endTime = row.isoTime;
    }
  }

  m_summaryModel->setRowCount(groups.size());
  int row = 0;
  for (auto it = groups.begin(); it != groups.end(); ++it, ++row) {
    auto *idItem = new QStandardItem(it.key());
    idItem->setTextAlignment(Qt::AlignCenter);
    m_summaryModel->setItem(row, 0, idItem);

    auto *countItem = new QStandardItem(QString::number(it.value().count));
    countItem->setTextAlignment(Qt::AlignCenter);
    m_summaryModel->setItem(row, 1, countItem);

    auto *startItem = new QStandardItem(it.value().startTime);
    startItem->setTextAlignment(Qt::AlignCenter);
    m_summaryModel->setItem(row, 2, startItem);

    auto *endItem = new QStandardItem(it.value().endTime);
    endItem->setTextAlignment(Qt::AlignCenter);
    m_summaryModel->setItem(row, 3, endItem);
  }
  m_summaryModel->blockSignals(false);
  m_summaryModel->layoutChanged();
  resizeSplitterAndColumns();
}

// ─────────────────────────────────────────────────────────────────────────────
//  extractDbcSignalRaw()
//
//  Extracts a DBC signal value from an 8-byte CAN payload stored as a hex
//  string (e.g. "DEADBEEF01234567", spaces already removed).
//
//  Intel / little-endian (@1):
//    startBit = position of the LSB. Bits are numbered 0..63 as
//    byte0[0..7], byte1[8..15], ...
//
//  Motorola / big-endian (@0):
//    startBit = position of the MSB using the DBC Motorola numbering:
//    within each byte, bit 7 is the MSB.  Conversion to a linear bit
//    position: linear = (startBit / 8) * 8 + (7 - (startBit % 8))
// ─────────────────────────────────────────────────────────────────────────────
static bool extractDbcSignalRaw(const QString &hexPayload, int startBit,
                                int bitLength, bool littleEndian, bool isSigned,
                                double &outValue) {
  // LOW-3: bounds check on bitLength
  if (bitLength <= 0 || bitLength > 64)
    return false;

  // Build a 64-bit value from the hex payload (up to 8 bytes = 16 hex
  // chars)
  QString padded =
      hexPayload.leftJustified(16, '0', true); // pad/trim to 16 chars
  bool ok = false;

  // Load bytes individually so byte order is unambiguous
  quint8 bytes[8] = {};
  for (int i = 0; i < 8; ++i) {
    bytes[i] = padded.mid(i * 2, 2).toUInt(&ok, 16);
    if (!ok)
      return false;
  }

  quint64 rawBits = 0;

  if (littleEndian) {
    // Intel: assemble as little-endian 64-bit word
    for (int i = 0; i < 8; ++i)
      rawBits |= (quint64)bytes[i] << (i * 8);

    quint64 mask = (bitLength < 64) ? ((1ULL << bitLength) - 1) : ~0ULL;
    rawBits = (rawBits >> startBit) & mask;
  } else {
    // Motorola: convert DBC MSB bit number to a linear position
    int byteIdx = startBit / 8;
    int bitIdx = 7 - (startBit % 8); // within-byte MSB position
    int linMSB = byteIdx * 8 + bitIdx;

    // Collect bits from MSB downwards
    rawBits = 0;
    for (int i = 0; i < bitLength; ++i) {
      int lin = linMSB - i;
      int byt = lin / 8;
      int bit = lin % 8; // within-byte, 0=LSB
      if (byt < 0 || byt > 7)
        return false;
      if (bytes[byt] & (1 << bit))
        rawBits |= (1ULL << (bitLength - 1 - i));
    }
  }

  // Sign extension
  if (isSigned && bitLength > 0 && bitLength < 64) {
    quint64 signBit = 1ULL << (bitLength - 1);
    if (rawBits & signBit) {
      // extend sign
      rawBits |= ~((1ULL << bitLength) - 1);
    }
    outValue = (double)(qint64)rawBits;
  } else {
    outValue = (double)rawBits;
  }

  return true;
}

// Returns {factor, offset} parsed from a simple linear formula like "x * 0.1 +
// 5". Falls back to {1, 0} for complex expressions.
static std::pair<double, double> parseLinearFormula(const QString &formula) {
  QString f = formula.trimmed();
  // x * factor + offset  /  x * factor - offset  /  x * factor
  QRegularExpression reMul(
      R"(^x\s*\*\s*([\d.eE+\-]+)\s*(?:([+\-])\s*([\d.eE+\-]+))?$)");
  auto m = reMul.match(f);
  if (m.hasMatch()) {
    double factor = m.captured(1).toDouble();
    double offset = m.captured(3).isEmpty() ? 0.0 : m.captured(3).toDouble();
    if (m.captured(2) == "-")
      offset = -offset;
    return std::make_pair(factor, offset);
  }
  // x + offset  /  x - offset
  QRegularExpression reAdd(R"(^x\s*([+\-])\s*([\d.eE+\-]+)$)");
  m = reAdd.match(f);
  if (m.hasMatch()) {
    double offset = m.captured(2).toDouble();
    if (m.captured(1) == "-")
      offset = -offset;
    return std::make_pair(1.0, offset);
  }
  if (f == "x")
    return std::make_pair(1.0, 0.0);
  return std::make_pair(1.0, 0.0); // fallback for complex formulas
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::calculateAndPopulateResultTable() {
  m_resultModel->blockSignals(true);
  m_resultModel->clear();
  m_resultModel->setHorizontalHeaderLabels(
      {"Timestamp", "ID", "Decoder", "Raw Hex", "Value"});

  if (m_allData.isEmpty() || m_savedConfigs.isEmpty()) {
    m_resultModel->blockSignals(false);
    populateSignalTree();
    resizeSplitterAndColumns();
    return;
  }

  // Pre-normalise config IDs once (avoids re-parsing per row)
  QVector<quint32> confNormIds;
  confNormIds.reserve(m_savedConfigs.size());
  for (const HexConfig &c : m_savedConfigs)
    confNormIds.append(normaliseCanId(c.targetID));

  // Pre-build filter set for O(1) lookup
  const bool hasFilter = !m_activeFilters.isEmpty();
  QSet<QString> filterSet;
  if (hasFilter)
    filterSet = QSet<QString>(m_activeFilters.begin(), m_activeFilters.end());

  // Estimate result size to avoid repeated reallocation
  QVector<QList<QStandardItem *>> rows;
  rows.reserve(m_allData.size()); // upper bound

  for (const RawData &row : m_allData) {
    if (hasFilter && !filterSet.contains(row.id))
      continue;

    quint32 rowCanId = row.numericId;
    const QString &cleanHex = row.cleanHex;

    for (int ci = 0; ci < m_savedConfigs.size(); ++ci) {
      if (confNormIds[ci] != rowCanId)
        continue;

      const HexConfig &conf = m_savedConfigs[ci];
      double rawVal = 0.0;
      QString displayHex;

      if (conf.isDBC) {
        if (!extractDbcSignalRaw(cleanHex, conf.startBit, conf.bitLength,
                                 conf.littleEndian, conf.isSigned, rawVal))
          continue;
        int sb = qBound(0, conf.startBit / 8, 7);
        int eb = qBound(sb, (conf.startBit + conf.bitLength - 1) / 8, 7);
        displayHex = "0x" + cleanHex.mid(sb * 2, (eb - sb + 1) * 2).toUpper();
      } else {
        int startPos = conf.startByte * 2;
        int sliceLen = (conf.endByte - conf.startByte + 1) * 2;
        if (startPos + sliceLen > cleanHex.length())
          continue;
        QString subHex = cleanHex.mid(startPos, sliceLen);
        bool ok = false;
        rawVal = (double)subHex.toLongLong(&ok, 16);
        if (!ok)
          continue;
        displayHex = "0x" + subHex.toUpper();
      }

      double finalVal = evaluateFormula(rawVal, conf.formula);

      QList<QStandardItem *> items;
      auto *tsItem = new QStandardItem(row.isoTime);
      tsItem->setData((qlonglong)row.timestamp, Qt::UserRole);
      items << tsItem << new QStandardItem(row.id)
            << new QStandardItem(conf.name) << new QStandardItem(displayHex)
            << new QStandardItem(QString::number(finalVal, 'f', 4));
      items[4]->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
      rows.append(items);
    }
  }

  // Batch insert all rows at once
  m_resultModel->setRowCount(rows.size());
  for (int r = 0; r < rows.size(); ++r) {
    for (int c = 0; c < rows[r].size(); ++c)
      m_resultModel->setItem(r, c, rows[r][c]);
  }
  m_resultModel->blockSignals(false);
  m_resultModel->layoutChanged();
  populateSignalTree();
  resizeSplitterAndColumns();
}

double MainWindow::evaluateFormula(double rawValue, const QString &formula) {
  if (formula.isEmpty())
    return rawValue;

  // HIGH-1: Use SafeEval (recursive-descent parser) instead of QJSEngine
  // to eliminate code injection risk entirely.
  bool ok = false;
  double result = SafeEval::evaluate(formula, rawValue, rawValue, &ok);
  return ok ? result : rawValue;
}

// ═════════════════════════════════════════════════════════════════════════════
//  DBC support
// ═════════════════════════════════════════════════════════════════════════════

QStringList MainWindow::allKnownIDs() const {
  QSet<QString> idSet;
  for (const RawData &d : m_allData)
    idSet.insert(d.id);
  for (const DBCMessage &msg : m_dbcParser.messages())
    idSet.insert(msg.hexID());
  return idSet.values();
}

void MainWindow::updateDBCStatus() {
  if (m_decoderInfoLabel) {
    m_decoderInfoLabel->setText(
        QString("Active decoders: %1   |   DBC: %2")
            .arg(m_savedConfigs.size())
            .arg(m_loadedDbcFile.isEmpty()
                     ? "Not loaded"
                     : QFileInfo(m_loadedDbcFile).fileName()));
  }

  // Reload table if we are sitting with loaded data
  if (m_allData.size() > 0) {
    int msgCount = m_dbcParser.messages().size();
    int sigCount = 0;
    for (const DBCMessage &m : m_dbcParser.messages())
      sigCount += m.sigs.size();
    statusBar()->showMessage(QString("DBC: %1  —  %2 messages, %3 signals")
                                 .arg(QFileInfo(m_loadedDbcFile).fileName())
                                 .arg(msgCount)
                                 .arg(sigCount));
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  onLoadDBC()  — triggered by toolbar "Load DBC…"
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onLoadDBC() {
  // If DBC already loaded, offer to re-import signals manually
  if (!m_loadedDbcFile.isEmpty()) {
    int choice = QMessageBox::question(
        this, "DBC Already Loaded",
        QString("DBC file already loaded: <b>%1</b><br><br>"
                "What would you like to do?<br><br>"
                "<b>Load New DBC:</b> Replace with a new .dbc file<br>"
                "<b>Manual Import:</b> Open signal selector for current DBC")
            .arg(QFileInfo(m_loadedDbcFile).fileName()),
        QMessageBox::Open | QMessageBox::Apply | QMessageBox::Cancel,
        QMessageBox::Cancel);

    if (choice == QMessageBox::Apply) {
      showDBCImportDialog();
      return;
    } else if (choice == QMessageBox::Cancel) {
      return;
    }
    // else: Open → continue to file picker below
  }

  QString path = QFileDialog::getOpenFileName(
      this, "Open DBC File", "", "DBC Files (*.dbc);;All Files (*)");
  if (path.isEmpty())
    return;

  if (!m_dbcParser.parse(path)) {
    QMessageBox::critical(this, "DBC Load Error", m_dbcParser.errorString());
    return;
  }

  m_loadedDbcFile = path;
  m_actUnloadDBC->setEnabled(true);
  updateDBCStatus();

  // Clear stale DBC configs from previous imports
  int removedOld = 0;
  for (int i = m_savedConfigs.size() - 1; i >= 0; --i) {
    if (m_savedConfigs[i].isDBC) {
      m_savedConfigs.removeAt(i);
      ++removedOld;
    }
  }
  if (removedOld > 0) {
    saveConfigsToFile();
    qDebug() << "[DBC] Cleared" << removedOld << "stale DBC decoder(s).";
  }

  // Show summary - auto-import will happen when CSV is loaded
  int totalSigs = 0;
  for (const auto &m : m_dbcParser.messages())
    totalSigs += m.sigs.size();

  // ── Auto-import if CSV data already loaded ────────────────────────────────
  if (!m_allData.isEmpty()) {
    autoImportMatchingSignals();
  } else if ((m_liveConnected || m_liveSimActive) && !m_liveSeenIds.isEmpty()) {
    // ── Auto-import if live session is active with accumulated CAN IDs ───────
    autoImportLiveSignals();
  } else {
    // ── No CSV, no live session — import all signals from the DBC ────────────
    for (const DBCMessage &msg : m_dbcParser.messages()) {
      for (const DBCSignal &sig : msg.sigs) {
        HexConfig conf;
        conf.targetID = msg.hexID();
        conf.name = sig.name;
        conf.formula = sig.toFormula();
        conf.isDBC = true;
        conf.startBit = sig.startBit;
        conf.bitLength = sig.length;
        conf.littleEndian = sig.littleEndian;
        conf.isSigned = sig.isSigned;
        conf.startByte = sig.startByte();
        conf.endByte = sig.endByte();
        m_savedConfigs.append(conf); // stale configs already cleared above
      }
    }
    saveConfigsToFile();
    if (m_configWidget)
      m_configWidget->setConfigList(m_savedConfigs);
    updateDBCStatus();
  }

  QMessageBox::information(this, "DBC Loaded",
                           QString("<b>DBC file loaded successfully:</b><br>"
                                   "%1<br><br>"
                                   "<b>%2</b> messages<br>"
                                   "<b>%3</b> signals<br><br>"
                                   "Matching signals have been auto-imported.")
                               .arg(QFileInfo(path).fileName())
                               .arg(m_dbcParser.messages().size())
                               .arg(totalSigs));
}

// ─────────────────────────────────────────────────────────────────────────────
//  onUnloadDBC()
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onUnloadDBC() {
  m_loadedDbcFile.clear();
  m_dbcParser = DBCParser(); // reset
  m_actUnloadDBC->setEnabled(false);
  saveSettings();

  // Remove all DBC-sourced decoder configs
  for (int i = m_savedConfigs.size() - 1; i >= 0; --i)
    if (m_savedConfigs[i].isDBC)
      m_savedConfigs.removeAt(i);
  saveConfigsToFile();
  if (m_configWidget)
    m_configWidget->setConfigList(m_savedConfigs);
  calculateAndPopulateResultTable();
  setInterfaceState(!m_allData.isEmpty());
  updateDBCStatus();

  statusBar()->showMessage("DBC database unloaded — DBC decoders removed.");
}

// ─────────────────────────────────────────────────────────────────────────────
//  showDBCImportDialog()
//  Shows a tree of all DBC messages / signals.  The user checks the signals
//  they want; on OK they are converted to HexConfig entries and appended to
//  m_savedConfigs (duplicates by name are skipped).
// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
//  autoImportMatchingSignals()
//  Called after CSV load when a DBC is already loaded.
//  autoImportLiveSignals()
//  Called when a DBC is loaded while a live session (real or simulation) is
//  already running.  Imports all DBC signals whose message IDs have been seen
//  in the live stream so far (m_liveSeenIds), then clears and resets the
//  decoded table so new rows start appearing immediately on the next batch
//  tick.
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::autoImportLiveSignals() {
  if (m_dbcParser.messages().isEmpty() || m_liveSeenIds.isEmpty())
    return;

  // Remove stale DBC configs from previous imports
  for (int i = m_savedConfigs.size() - 1; i >= 0; --i)
    if (m_savedConfigs[i].isDBC)
      m_savedConfigs.removeAt(i);

  int imported = 0;
  for (const DBCMessage &msg : m_dbcParser.messages()) {
    if (!m_liveSeenIds.contains(msg.rawCanId))
      continue;
    for (const DBCSignal &sig : msg.sigs) {
      HexConfig conf;
      conf.targetID = msg.hexID();
      conf.name = sig.name;
      conf.formula = sig.toFormula();
      conf.isDBC = true;
      conf.startBit = sig.startBit;
      conf.bitLength = sig.length;
      conf.littleEndian = sig.littleEndian;
      conf.isSigned = sig.isSigned;
      conf.startByte = sig.startByte();
      conf.endByte = sig.endByte();
      bool dup = false;
      for (const HexConfig &c : m_savedConfigs)
        if (c.name == conf.name &&
            normaliseCanId(c.targetID) == normaliseCanId(conf.targetID)) {
          dup = true;
          break;
        }
      if (!dup) {
        m_savedConfigs.append(conf);
        ++imported;
      }
    }
  }
  saveConfigsToFile();
  if (m_configWidget)
    m_configWidget->setConfigList(m_savedConfigs);
  updateDBCStatus();

  // Reset decoded table so signals start populating from the next batch tick
  if (m_liveDecodedTable)
    m_liveDecodedTable->setRowCount(0);
  m_decodedTableRowMap.clear();

  statusBar()->showMessage(
      QString("DBC loaded — %1 signal(s) imported from live traffic.")
          .arg(imported));
}

// ─────────────────────────────────────────────────────────────────────────────
//  Automatically imports all signals from DBC messages whose IDs appear in
//  CSV.
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::autoImportMatchingSignals() {
  if (m_dbcParser.messages().isEmpty())
    return;

  // Populate ConfigWidget IDs
  if (m_configWidget)
    m_configWidget->setIDList(allKnownIDs());

  if (m_allData.isEmpty()) {
    return;
  }

  // Collect unique normalised CAN IDs from CSV data
  QSet<quint32> csvIds;
  for (const RawData &row : m_allData) {
    csvIds.insert(row.numericId);
  }
  int imported = 0, updated = 0, skippedNoMatch = 0;

  // For each DBC message, check if its ID appears in CSV
  for (const DBCMessage &msg : m_dbcParser.messages()) {
    if (!csvIds.contains(msg.rawCanId)) {
      ++skippedNoMatch;
      continue; // CSV doesn't have this message ID
    }

    // CSV has this ID → import all its signals
    for (const DBCSignal &sig : msg.sigs) {
      HexConfig conf;
      conf.targetID = msg.hexID();
      conf.name = sig.name;
      conf.formula = sig.toFormula();
      conf.isDBC = true;
      conf.startBit = sig.startBit;
      conf.bitLength = sig.length;
      conf.littleEndian = sig.littleEndian;
      conf.isSigned = sig.isSigned;
      conf.startByte = sig.startByte();
      conf.endByte = sig.endByte();

      // Update if exists, otherwise append
      bool found = false;
      for (int k = 0; k < m_savedConfigs.size(); ++k) {
        if (m_savedConfigs[k].name == conf.name) {
          m_savedConfigs[k] = conf;
          found = true;
          ++updated;
          break;
        }
      }
      if (!found) {
        m_savedConfigs.append(conf);
        ++imported;
      }
    }
  }

  if (imported > 0 || updated > 0) {
    if (m_configWidget) {
      m_configWidget->setConfigList(m_savedConfigs);
    }
    saveConfigsToFile();
    calculateAndPopulateResultTable();
    updateDBCStatus();
    setInterfaceState(true); // forces visibility updates for the guide
  }

  qDebug() << "[Auto-import]" << imported << "new," << updated << "updated,"
           << skippedNoMatch << "DBC messages skipped (ID not in CSV)";
}

void MainWindow::showDBCImportDialog() {
  if (m_loadedDbcFile.isEmpty() || m_dbcParser.messages().isEmpty()) {
    QMessageBox::warning(this, "DBC Import",
                         "No DBC file loaded.<br><br>"
                         "Click <b>Load DBC</b> first to load a .dbc file.");
    return;
  }

  QDialog dlg(this);
  dlg.setWindowTitle("Import DBC Signals as Decoders");
  dlg.resize(680, 520);

  QVBoxLayout *root = new QVBoxLayout(&dlg);
  root->setSpacing(8);
  root->setContentsMargins(10, 10, 10, 10);

  // ── Info label
  // ────────────────────────────────────────────────────────────
  QLabel *info =
      new QLabel("Check the signals you want to import as byte decoders.\n"
                 "Each signal will be converted to a HexConfig entry using its "
                 "DBC start/end byte and scale formula.",
                 &dlg);
  info->setWordWrap(true);
  root->addWidget(info);

  // ── Tree: Message → Signals
  // ───────────────────────────────────────────────
  QTreeWidget *tree = new QTreeWidget(&dlg);
  tree->setHeaderLabels(
      {"Signal / Message", "ID", "Bits", "Factor", "Offset", "Unit"});
  tree->setAlternatingRowColors(true);
  tree->setColumnWidth(0, 200);
  tree->setColumnWidth(1, 80);
  tree->setColumnWidth(2, 60);
  tree->setColumnWidth(3, 60);
  tree->setColumnWidth(4, 60);

  for (const DBCMessage &msg : m_dbcParser.messages()) {
    QTreeWidgetItem *msgItem = new QTreeWidgetItem(tree);
    msgItem->setText(0, QString("%1").arg(msg.name));
    msgItem->setText(1, msg.hexID());
    msgItem->setText(2, QString("%1 B").arg(msg.dlc));
    msgItem->setFlags(msgItem->flags() | Qt::ItemIsUserCheckable |
                      Qt::ItemIsAutoTristate);
    msgItem->setCheckState(0, Qt::Unchecked);
    msgItem->setExpanded(true);

    for (const DBCSignal &sig : msg.sigs) {
      QTreeWidgetItem *sigItem = new QTreeWidgetItem(msgItem);
      sigItem->setFlags(sigItem->flags() | Qt::ItemIsUserCheckable);
      sigItem->setCheckState(0, Qt::Unchecked);

      // Name + optional unit suffix
      QString label = sig.name;
      if (!sig.unit.isEmpty())
        label += QString("  [%1]").arg(sig.unit);
      sigItem->setText(0, label);
      sigItem->setText(1, msg.hexID());
      sigItem->setText(2, QString("%1|%2").arg(sig.startBit).arg(sig.length));
      sigItem->setText(3, QString::number(sig.factor, 'g', 6));
      sigItem->setText(4, QString::number(sig.offset, 'g', 6));
      sigItem->setText(5, sig.unit);

      // Attach signal data as item data for later retrieval
      sigItem->setData(0, Qt::UserRole + 0, msg.hexID());
      sigItem->setData(0, Qt::UserRole + 1, sig.name);
      sigItem->setData(0, Qt::UserRole + 2, sig.toFormula());
      sigItem->setData(0, Qt::UserRole + 3, sig.startBit); // DBC startBit
      sigItem->setData(0, Qt::UserRole + 4, sig.length);   // DBC bitLength
      sigItem->setData(0, Qt::UserRole + 5,
                       sig.littleEndian);                  // DBC byteOrder
      sigItem->setData(0, Qt::UserRole + 6, sig.isSigned); // DBC signed
      sigItem->setData(0, Qt::UserRole + 7, sig.comment);
      sigItem->setData(0, Qt::UserRole + 8,
                       sig.startByte()); // approx byte (for display)
      sigItem->setData(0, Qt::UserRole + 9, sig.endByte());

      // Show comment as tooltip
      if (!sig.comment.isEmpty())
        sigItem->setToolTip(0, sig.comment);
    }

    if (msg.sigs.isEmpty()) {
      QTreeWidgetItem *empty = new QTreeWidgetItem(msgItem);
      empty->setText(0, "(no signals)");
      empty->setFlags(Qt::ItemIsEnabled);
    }
  }

  root->addWidget(tree);

  // ── Select-all / Select-none row
  // ──────────────────────────────────────────
  QHBoxLayout *selRow = new QHBoxLayout();
  QPushButton *bAll = new QPushButton("Check All", &dlg);
  QPushButton *bNone = new QPushButton("Uncheck All", &dlg);
  QPushButton *bExpand = new QPushButton("Expand All", &dlg);
  bAll->setMaximumHeight(24);
  bNone->setMaximumHeight(24);
  bExpand->setMaximumHeight(24);
  selRow->addWidget(bAll);
  selRow->addWidget(bNone);
  selRow->addWidget(bExpand);
  selRow->addStretch();
  root->addLayout(selRow);

  auto setAllChecked = [tree](Qt::CheckState state) {
    for (int i = 0; i < tree->topLevelItemCount(); ++i) {
      auto *msg = tree->topLevelItem(i);
      for (int j = 0; j < msg->childCount(); ++j)
        if (msg->child(j)->flags() & Qt::ItemIsUserCheckable)
          msg->child(j)->setCheckState(0, state);
    }
  };

  connect(bAll, &QPushButton::clicked, [&] { setAllChecked(Qt::Checked); });
  connect(bNone, &QPushButton::clicked, [&] { setAllChecked(Qt::Unchecked); });
  connect(bExpand, &QPushButton::clicked, [tree] { tree->expandAll(); });

  // ── Dialog buttons
  // ────────────────────────────────────────────────────────
  QDialogButtonBox *bb = new QDialogButtonBox(
      QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
  root->addWidget(bb);
  connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
  connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

  if (dlg.exec() != QDialog::Accepted)
    return;

  // ── Collect checked signals
  // ─────────────────────────────────────────────── Strategy: UPDATE
  // existing entries with the same name (so re-importing after a code fix
  // always overwrites stale configs.json entries), ADD new ones.
  int imported = 0, updated = 0;

  for (int i = 0; i < tree->topLevelItemCount(); ++i) {
    auto *msgItem = tree->topLevelItem(i);
    for (int j = 0; j < msgItem->childCount(); ++j) {
      auto *sigItem = msgItem->child(j);
      if (!(sigItem->flags() & Qt::ItemIsUserCheckable))
        continue;
      if (sigItem->checkState(0) != Qt::Checked)
        continue;

      HexConfig conf;
      conf.targetID = sigItem->data(0, Qt::UserRole + 0).toString();
      conf.name = sigItem->data(0, Qt::UserRole + 1).toString();
      conf.formula = sigItem->data(0, Qt::UserRole + 2).toString();
      conf.isDBC = true;
      conf.startBit = sigItem->data(0, Qt::UserRole + 3).toInt();
      conf.bitLength = sigItem->data(0, Qt::UserRole + 4).toInt();
      conf.littleEndian = sigItem->data(0, Qt::UserRole + 5).toBool();
      conf.isSigned = sigItem->data(0, Qt::UserRole + 6).toBool();
      conf.startByte = sigItem->data(0, Qt::UserRole + 8).toInt();
      conf.endByte = sigItem->data(0, Qt::UserRole + 9).toInt();

      // Find existing entry with same name and UPDATE it rather than skip
      bool found = false;
      for (int k = 0; k < m_savedConfigs.size(); ++k) {
        if (m_savedConfigs[k].name == conf.name) {
          m_savedConfigs[k] = conf; // overwrite with correct DBC data
          found = true;
          ++updated;
          break;
        }
      }
      if (!found) {
        m_savedConfigs.append(conf);
        ++imported;
      }
    }
  }

  if (imported == 0 && updated == 0) {
    statusBar()->showMessage("No signals selected.");
    return;
  }

  saveConfigsToFile();
  calculateAndPopulateResultTable();

  // ── Post-import feedback
  // ──────────────────────────────────────────────────
  QString msg =
      QString("DBC import: %1 added, %2 updated.").arg(imported).arg(updated);
  if (m_allData.isEmpty()) {
    msg += "  [!] No CSV data loaded -- open a CSV file to see decoded "
           "values.";
  } else {
    int rows = m_resultModel->rowCount();
    msg += QString("  ->  %1 decoded row(s) in result table.").arg(rows);
    if (rows == 0) {
      // Show sample CSV IDs vs DBC IDs so user can diagnose
      QStringList csvIdSamples;
      QSet<QString> seenCsv;
      for (const RawData &d : m_allData) {
        if (!seenCsv.contains(d.id)) {
          csvIdSamples << d.id;
          seenCsv.insert(d.id);
        }
        if (csvIdSamples.size() >= 4) {
          csvIdSamples << "…";
          break;
        }
      }
      QStringList dbcIdSamples;
      int dbcShown = 0;
      for (const HexConfig &c : m_savedConfigs) {
        if (!dbcIdSamples.contains(c.targetID)) {
          dbcIdSamples << c.targetID;
          if (++dbcShown >= 4) {
            dbcIdSamples << "…";
            break;
          }
        }
      }
      msg += QString("  [!] 0 matches! CSV IDs: [%1]  Decoder IDs: [%2]")
                 .arg(csvIdSamples.join(", "))
                 .arg(dbcIdSamples.join(", "));
    }
  }
  statusBar()->showMessage(msg);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Standard slots
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::on_btn_load_clicked() {
  QString fileName = QFileDialog::getOpenFileName(
      this, "Open CSV File", "", "CSV Files (*.csv);;All Files (*)");
  if (fileName.isEmpty())
    return;

  QFile file(fileName);
  if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
    // LOW-4: use basename only to avoid leaking full path
    QMessageBox::critical(
        this, "Error", "Cannot open file:\n" + QFileInfo(fileName).fileName());
    return;
  }

  m_allData.clear();
  m_summaryModel->clear();
  m_resultModel->clear();
  m_activeFilters.clear();

  // Pre-allocate based on file size estimate (~80 bytes per CSV line)
  m_allData.reserve(static_cast<int>(file.size() / 80));

  // -- Determine total lines for progress --
  qint64 fileSize = file.size();

  QProgressDialog progress("Loading CSV...", "Cancel", 0,
                           static_cast<int>(fileSize), this);
  progress.setWindowTitle("HEDAP");
  progress.setWindowModality(Qt::WindowModal);
  progress.setMinimumDuration(300); // only show if takes > 300ms
  progress.setValue(0);

  QTextStream in(&file);
  QString csvHeader;
  if (!in.atEnd())
    csvHeader = in.readLine();
  m_csvIsLiveFormat = csvHeader.startsWith("Time,");

  int lineCount = 0;
  while (!in.atEnd()) {
    // MED-1: cap rows to prevent memory exhaustion from huge files
    if (m_allData.size() >= MAX_CSV_ROWS) {
      QMessageBox::warning(this, "Row Limit",
                           QString("Maximum row limit (%1) reached.\n"
                                   "Only the first %1 rows were loaded.")
                               .arg(MAX_CSV_ROWS));
      break;
    }
    if (progress.wasCanceled()) {
      m_allData.clear();
      m_summaryModel->clear();
      m_resultModel->clear();
      statusBar()->showMessage("Loading cancelled.");
      return;
    }
    parseAndStoreLine(in.readLine());
    ++lineCount;
    if (lineCount % 500 == 0) {
      progress.setValue(static_cast<int>(in.pos()));
      QApplication::processEvents();
    }
  }
  file.close();
  progress.setValue(static_cast<int>(fileSize));

  populateSummaryTable();
  calculateAndPopulateResultTable();
  setInterfaceState(true);
  if (m_configWidget)
    m_configWidget->setIDList(allKnownIDs());

  // ── Auto-import from DBC if loaded
  // ───────────────────────────────────────
  if (!m_loadedDbcFile.isEmpty()) {
    autoImportMatchingSignals();
  }

  int rows = m_resultModel->rowCount();
  QString msg = QString("%1  —  %2 frames loaded")
                    .arg(QFileInfo(fileName).fileName())
                    .arg(m_allData.size());

  if (!m_loadedDbcFile.isEmpty()) {
    msg += QString("  |  DBC: %1").arg(QFileInfo(m_loadedDbcFile).fileName());
  }

  if (m_savedConfigs.isEmpty()) {
    msg += "  |  No decoders -- load a DBC file first";
  } else if (rows == 0) {
    QStringList sampleIds;
    QSet<QString> seen;
    for (const RawData &d : m_allData) {
      if (!seen.contains(d.id)) {
        sampleIds << d.id;
        seen.insert(d.id);
      }
      if (sampleIds.size() >= 3)
        break;
    }
    msg += QString("  |  0 matches -- CSV IDs [%1] not in DBC")
               .arg(sampleIds.join(", "));
  } else {
    msg += QString("  |  %1 decoded rows").arg(rows);
  }
  statusBar()->showMessage(msg);
}

void MainWindow::on_btn_unload_clicked() {
  m_allData.clear();
  m_summaryModel->clear();
  m_resultModel->clear();
  m_signalTreeModel->clear();
  m_activeFilters.clear();
  setInterfaceState(false);
  statusBar()->showMessage("File closed.");
}

void MainWindow::on_btn_filter_clicked() {
  QSet<QString> idSet;
  idSet.reserve(256);
  for (const RawData &d : m_allData)
    idSet.insert(d.id);
  QStringList uniqueIDs = idSet.values();
  uniqueIDs.sort();

  QDialog dlg(this);
  dlg.setWindowTitle("Filter by ID");
  dlg.resize(280, 380);

  QVBoxLayout *lay = new QVBoxLayout(&dlg);
  lay->setSpacing(4);
  lay->setContentsMargins(8, 8, 8, 8);

  QListWidget *lw = new QListWidget(&dlg);
  lw->setSpacing(0);
  for (const QString &id : uniqueIDs) {
    auto *item = new QListWidgetItem(id, lw);
    item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
    item->setCheckState(
        (m_activeFilters.isEmpty() || m_activeFilters.contains(id))
            ? Qt::Checked
            : Qt::Unchecked);
  }
  lay->addWidget(lw);

  QHBoxLayout *btnRow = new QHBoxLayout();
  auto *bAll = new QPushButton("All", &dlg);
  auto *bNone = new QPushButton("None", &dlg);
  bAll->setMaximumHeight(22);
  bNone->setMaximumHeight(22);
  btnRow->addWidget(bAll);
  btnRow->addWidget(bNone);
  lay->addLayout(btnRow);
  connect(bAll, &QPushButton::clicked, [lw] {
    for (int i = 0; i < lw->count(); i++)
      lw->item(i)->setCheckState(Qt::Checked);
  });
  connect(bNone, &QPushButton::clicked, [lw] {
    for (int i = 0; i < lw->count(); i++)
      lw->item(i)->setCheckState(Qt::Unchecked);
  });

  auto *bb = new QDialogButtonBox(
      QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
  lay->addWidget(bb);
  connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
  connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

  if (dlg.exec() == QDialog::Accepted) {
    QStringList sel;
    for (int i = 0; i < lw->count(); i++)
      if (lw->item(i)->checkState() == Qt::Checked)
        sel << lw->item(i)->text();
    if (sel.isEmpty()) {
      QMessageBox::warning(this, "Filter", "Select at least one ID.");
      return;
    }
    m_activeFilters = sel;
    populateSummaryTable(m_activeFilters);
    calculateAndPopulateResultTable();
    statusBar()->showMessage(
        QString("Filter: %1 ID(s) active").arg(sel.size()));
  }
}

void MainWindow::on_btn_reset_clicked() {
  m_activeFilters.clear();
  populateSummaryTable();
  calculateAndPopulateResultTable();
  statusBar()->showMessage("Filter cleared.");
}

void MainWindow::on_btn_conf_clicked() { switchPage(PAGE_DECODERS); }

void MainWindow::on_btn_export_clicked() {
  auto escapeCsv = [](const QString &field) -> QString {
    if (field.contains(',') || field.contains('"') || field.contains('\n')) {
      QString escaped = field;
      escaped.replace("\"", "\"\"");
      return "\"" + escaped + "\"";
    }
    return field;
  };

  // ── Live Monitor: export raw frames table ─────────────────────────────────
  if (m_pages->currentIndex() == PAGE_LIVE) {
    if (!m_liveRawTable || m_liveRawTable->rowCount() == 0) {
      QMessageBox::warning(this, "Export", "No raw frames captured yet.");
      return;
    }
    QString path = QFileDialog::getSaveFileName(this, "Export Raw Frames", "",
                                                "CSV Files (*.csv)");
    if (path.isEmpty())
      return;
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
      QMessageBox::critical(this, "Error", "Cannot write file.");
      return;
    }
    QTextStream out(&f);
    out.setEncoding(QStringConverter::Utf8);
    out.setGenerateByteOrderMark(true);
    out << "Time,ID,DLC,Data\n";
    for (int i = 0; i < m_liveRawTable->rowCount(); i++) {
      QStringList row;
      for (int j = 0; j < m_liveRawTable->columnCount(); j++) {
        auto *item = m_liveRawTable->item(i, j);
        row << escapeCsv(item ? item->text() : "");
      }
      out << row.join(",") << "\n";
    }
    f.close();
    statusBar()->showMessage("Exported: " + QFileInfo(path).fileName());
    return;
  }

  // ── CSV Analysis: export from m_allData ───────────────────────────────────
  if (m_allData.isEmpty()) {
    QMessageBox::warning(this, "Export", "No data loaded.");
    return;
  }

  QMessageBox msgBox(this);
  msgBox.setWindowTitle("Export");
  msgBox.setText("Select export scope:");
  msgBox.setIcon(QMessageBox::Question);
  auto *bSummary = msgBox.addButton("Summary Table", QMessageBox::ActionRole);
  auto *bSelected = msgBox.addButton("Selected ID", QMessageBox::ActionRole);
  auto *bAll = msgBox.addButton("All Raw Data", QMessageBox::ActionRole);
  msgBox.addButton(QMessageBox::Cancel);
  msgBox.exec();

  auto *clicked = msgBox.clickedButton();
  if (!clicked || clicked == msgBox.button(QMessageBox::Cancel))
    return;

  QString idFilter;
  if (clicked == bSelected) {
    auto idx = ui->tbl_summary->currentIndex();
    if (!idx.isValid()) {
      QMessageBox::warning(this, "Export", "Select a row first.");
      return;
    }
    idFilter = ui->tbl_summary->model()->index(idx.row(), 0).data().toString();
  }

  QString path =
      QFileDialog::getSaveFileName(this, "Export CSV", "", "CSV Files (*.csv)");
  if (path.isEmpty())
    return;
  QFile f(path);
  if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
    QMessageBox::critical(this, "Error", "Cannot write file.");
    return;
  }
  QTextStream out(&f);
  out.setEncoding(QStringConverter::Utf8);
  out.setGenerateByteOrderMark(true);

  if (clicked == bSummary) {
    out << "ID,Count,Start Timestamp,End Timestamp\n";
    for (int i = 0; i < m_summaryModel->rowCount(); i++)
      out << escapeCsv(m_summaryModel->item(i, 0)->text()) << ","
          << escapeCsv(m_summaryModel->item(i, 1)->text()) << ","
          << escapeCsv(m_summaryModel->item(i, 2)->text()) << ","
          << escapeCsv(m_summaryModel->item(i, 3)->text()) << "\n";
  } else {
    out << "ISO Time,Epoch,ID,Data Hex\n";
    for (const RawData &d : m_allData) {
      if (clicked == bSelected && d.id != idFilter)
        continue;
      out << escapeCsv(d.isoTime) << "," << d.timestamp << ","
          << escapeCsv(d.id) << "," << escapeCsv(d.dataHex) << "\n";
    }
  }
  f.close();
  statusBar()->showMessage("Exported: " + QFileInfo(path).fileName());
}

void MainWindow::on_btn_exportdata_clicked() {
  auto escapeCsv = [](const QString &field) -> QString {
    if (field.contains(',') || field.contains('"') || field.contains('\n')) {
      QString escaped = field;
      escaped.replace("\"", "\"\"");
      return "\"" + escaped + "\"";
    }
    return field;
  };

  // ── Live Monitor: export decoded signals table ────────────────────────────
  if (m_pages->currentIndex() == PAGE_LIVE) {
    if (!m_liveDecodedTable || m_liveDecodedTable->rowCount() == 0) {
      QMessageBox::warning(this, "Export", "No decoded signals yet.");
      return;
    }
    QString path = QFileDialog::getSaveFileName(this, "Export Decoded Signals",
                                                "", "CSV Files (*.csv)");
    if (path.isEmpty())
      return;
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
      QMessageBox::critical(this, "Error", "Cannot write file.");
      return;
    }
    QTextStream out(&f);
    out.setEncoding(QStringConverter::Utf8);
    out.setGenerateByteOrderMark(true);
    out << "Time,ID,Signal,Value\n";
    for (int i = 0; i < m_liveDecodedTable->rowCount(); i++) {
      QStringList row;
      for (int j = 0; j < m_liveDecodedTable->columnCount(); j++) {
        auto *item = m_liveDecodedTable->item(i, j);
        row << escapeCsv(item ? item->text() : "");
      }
      out << row.join(",") << "\n";
    }
    f.close();
    statusBar()->showMessage("Exported: " + QFileInfo(path).fileName());
    return;
  }

  // ── CSV Analysis: export from m_resultModel ───────────────────────────────
  if (m_resultModel->rowCount() == 0) {
    QMessageBox::warning(this, "Export", "No decoded data to export.");
    return;
  }
  QString path = QFileDialog::getSaveFileName(this, "Export Decoded Data", "",
                                              "CSV Files (*.csv)");
  if (path.isEmpty())
    return;
  QFile f(path);
  if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
    QMessageBox::critical(this, "Error", "Cannot write file.");
    return;
  }
  QTextStream out(&f);
  out.setEncoding(QStringConverter::Utf8);
  out.setGenerateByteOrderMark(true);

  QStringList hdr;
  for (int i = 0; i < m_resultModel->columnCount(); i++)
    hdr << escapeCsv(m_resultModel->headerData(i, Qt::Horizontal).toString());
  out << hdr.join(",") << "\n";
  for (int i = 0; i < m_resultModel->rowCount(); i++) {
    QStringList row;
    for (int j = 0; j < m_resultModel->columnCount(); j++)
      row << escapeCsv(m_resultModel->item(i, j)->text());
    out << row.join(",") << "\n";
  }
  f.close();
  statusBar()->showMessage("Exported: " + QFileInfo(path).fileName());
}

void MainWindow::exportManualDecodersToDBC() {
  int mode = m_configWidget ? m_configWidget->filterMode() : 0;

  QVector<HexConfig> toExport;
  for (const HexConfig &c : m_savedConfigs) {
    if (mode == 1 && !c.isDBC) continue; // DBC filter: skip custom
    if (mode == 2 &&  c.isDBC) continue; // Custom filter: skip DBC
    toExport.append(c);
  }

  if (toExport.isEmpty()) {
    QMessageBox::information(this, "Export as DBC",
                             "No decoder configurations to export.");
    return;
  }

  QString path = QFileDialog::getSaveFileName(this, "Export as DBC", "",
                                              "DBC Files (*.dbc)");
  if (path.isEmpty())
    return;

  // Group configs by CAN ID
  QMap<quint32, QVector<const HexConfig *>> groups;
  for (const HexConfig &c : toExport)
    groups[normaliseCanId(c.targetID)].append(&c);

  QFile f(path);
  if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
    QMessageBox::critical(this, "Error", "Cannot write file.");
    return;
  }
  QTextStream out(&f);
  out << "VERSION \"\"\n\nNS_ :\n\nBS_:\n\nBU_:\n\n";

  for (auto it = groups.begin(); it != groups.end(); ++it) {
    quint32 id = it.key();
    out << QString("BO_ %1 MSG_%1: 8 Vector__XXX\n").arg(id);
    for (const HexConfig *c : it.value()) {
      int startBit = c->isDBC ? c->startBit : c->startByte * 8;
      int bitLen   = c->isDBC ? c->bitLength : (c->endByte - c->startByte + 1) * 8;
      QString byteOrder = (c->isDBC && !c->littleEndian) ? "0" : "1";
      QString sign      = (c->isDBC && c->isSigned)      ? "-" : "+";
      auto fo = parseLinearFormula(c->formula);
      out << QString(" SG_ %1 : %2|%3@%4%5 (%6,%7) [0|0] \"\" Vector__XXX\n")
                 .arg(c->name)
                 .arg(startBit)
                 .arg(bitLen)
                 .arg(byteOrder)
                 .arg(sign)
                 .arg(fo.first)
                 .arg(fo.second);
    }
    out << "\n";
  }

  statusBar()->showMessage(QString("Exported %1 decoder(s) to %2")
                               .arg(toExport.size())
                               .arg(QFileInfo(path).fileName()));
}

// ─────────────────────────────────────────────────────────────────────────────
//  Evenly subsample pts down to at most maxCount points.
// ─────────────────────────────────────────────────────────────────────────────
QVector<QPair<qint64, double>> MainWindow::downsamplePoints(
    const QVector<QPair<qint64, double>> &pts, int maxCount) {
  if (pts.size() <= maxCount)
    return pts;
  QVector<QPair<qint64, double>> out;
  out.reserve(maxCount + 1);
  double step = static_cast<double>(pts.size()) / maxCount;
  for (int i = 0; i < maxCount; ++i)
    out.append(pts[static_cast<int>(i * step)]);
  out.append(pts.last());
  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Plot the Graph page from m_liveHistory (Live Session mode).
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::plotGraphFromLiveHistory() {
  if (m_liveHistory.isEmpty()) {
    QMessageBox::warning(this, tr("Plot"),
                         tr("No live session data yet. Connect and receive "
                            "some data first."));
    return;
  }

  QHash<QString, GraphSeriesConfig> cfgHash;
  for (const GraphSeriesConfig &c : m_graphSeriesConfigs)
    cfgHash[c.name] = c;

  auto *chart = new QChart();
  chart->setTitle("Live Session — Decoded Values");
  chart->setAnimationOptions(QChart::NoAnimation);
  chart->legend()->setVisible(true);

  const int MAX_PTS = m_settings.graphMaxPts;
  double xMinD = std::numeric_limits<double>::max();
  double xMaxD = std::numeric_limits<double>::lowest();
  double yMinD = std::numeric_limits<double>::max();
  double yMaxD = std::numeric_limits<double>::lowest();
  int seriesCount = 0;
  int totalPoints = 0;

  for (auto it = m_liveHistory.cbegin(); it != m_liveHistory.cend(); ++it) {
    const QString &sigName = it.key();
    const std::deque<QPair<qint64, double>> &deq = it.value();
    if (deq.empty())
      continue;

    // Default appearance
    bool enabled = true;
    QColor color = Qt::blue;
    int style = 0;
    if (cfgHash.contains(sigName)) {
      enabled = cfgHash[sigName].enabled;
      color   = cfgHash[sigName].color;
      style   = cfgHash[sigName].style;
    }
    if (!enabled)
      continue;

    // Copy deque → vector, then downsample
    QVector<QPair<qint64, double>> allPts(deq.begin(), deq.end());
    QVector<QPair<qint64, double>> pts = downsamplePoints(allPts, MAX_PTS);

    QVector<QPointF> ptF;
    ptF.reserve(pts.size());
    for (const auto &p : pts) {
      ptF.append(QPointF(p.first, p.second));
      xMinD = std::min(xMinD, (double)p.first);
      xMaxD = std::max(xMaxD, (double)p.first);
      if (!std::isnan(p.second)) {
        yMinD = std::min(yMinD, p.second);
        yMaxD = std::max(yMaxD, p.second);
      }
    }
    totalPoints += pts.size();

    if (style == 2) {
      auto *scatter = new QScatterSeries();
      scatter->setName(sigName);
      scatter->setColor(color);
      scatter->setMarkerSize(6);
      scatter->setUseOpenGL(false);
      scatter->replace(ptF);
      chart->addSeries(scatter);
    } else {
      auto *line = new QLineSeries();
      line->setName(sigName);
      line->setColor(color);
      line->setUseOpenGL(false);
      if (style == 1) {
        QPen pen(color, 2, Qt::DashLine);
        line->setPen(pen);
      }
      line->replace(ptF);
      chart->addSeries(line);
    }
    ++seriesCount;
  }

  if (chart->series().isEmpty()) {
    delete chart;
    QMessageBox::information(this, tr("Plot"),
                             tr("No enabled signals with live data."));
    return;
  }

  // Guard against degenerate axis ranges
  if (xMinD >= xMaxD) xMaxD = xMinD + 1000;
  if (yMinD >= yMaxD) { yMinD = 0; yMaxD = 1; }

  auto *axX = new QDateTimeAxis();
  axX->setFormat("HH:mm:ss.zzz");
  axX->setTitleText("Time");
  axX->setRange(QDateTime::fromMSecsSinceEpoch((qint64)xMinD),
                QDateTime::fromMSecsSinceEpoch((qint64)xMaxD));
  chart->addAxis(axX, Qt::AlignBottom);

  double pad = (yMaxD - yMinD) * 0.08 + 0.001;
  auto *axY = new QValueAxis();
  axY->setTitleText("Value");
  axY->setRange(yMinD - pad, yMaxD + pad);
  chart->addAxis(axY, Qt::AlignLeft);

  for (auto *s : chart->series()) {
    s->attachAxis(axX);
    s->attachAxis(axY);
  }

  QChart *oldChart = m_chartView->chart();
  m_chartView->setChart(chart);
  delete oldChart;
  m_chartView->freezeForInspection((qint64)xMinD, (qint64)xMaxD);
  switchPage(PAGE_GRAPH);
  statusBar()->showMessage(
      tr("Live plot: %1 series, %2 data points.").arg(seriesCount).arg(totalPoints));
}

void MainWindow::on_btn_graph_clicked() {
  if (m_graphDataMode == GraphDataMode::Live) {
    plotGraphFromLiveHistory();
    return;
  }

  if (m_allData.isEmpty() || m_savedConfigs.isEmpty()) {
    QMessageBox::warning(this, "Plot",
                         "No decoded data. Configure decoders first.");
    return;
  }

  // ── Build fast lookup structures ──────────────────────────────────────────
  // Hash: signal name -> graph config (enabled, color, style)
  QHash<QString, GraphSeriesConfig> cfgHash;
  cfgHash.reserve(m_graphSeriesConfigs.size());
  for (const GraphSeriesConfig &c : m_graphSeriesConfigs)
    cfgHash[c.name] = c;

  // Pre-normalise config IDs and build enabled flags
  struct ConfigInfo {
    quint32 normId;
    bool enabled;
    QString name;
    // Config fields needed for value extraction
    const HexConfig *cfg;
  };
  QVector<ConfigInfo> enabledConfigs;
  enabledConfigs.reserve(m_savedConfigs.size());
  for (int ci = 0; ci < m_savedConfigs.size(); ++ci) {
    const HexConfig &conf = m_savedConfigs[ci];
    bool en = true;
    if (cfgHash.contains(conf.name))
      en = cfgHash[conf.name].enabled;
    if (!en)
      continue; // skip disabled signals entirely
    ConfigInfo info;
    info.normId = normaliseCanId(conf.targetID);
    info.enabled = true;
    info.name = conf.name;
    info.cfg = &m_savedConfigs[ci];
    enabledConfigs.append(info);
  }

  if (enabledConfigs.isEmpty()) {
    QMessageBox::information(this, "Plot", "No signals enabled for plotting.");
    return;
  }

  // Pre-build filter set for O(1) lookup (same as
  // calculateAndPopulateResultTable)
  const bool hasFilter = !m_activeFilters.isEmpty();
  QSet<QString> filterSet;
  if (hasFilter)
    filterSet = QSet<QString>(m_activeFilters.begin(), m_activeFilters.end());

  // ── Collect points directly from raw data (bypass QStandardItemModel) ─────
  QHash<QString, QVector<QPointF>> pointsMap;
  pointsMap.reserve(enabledConfigs.size());
  qint64 minX = std::numeric_limits<qint64>::max(),
         maxX = std::numeric_limits<qint64>::min();
  double minY = std::numeric_limits<double>::max(),
         maxY = std::numeric_limits<double>::lowest();
  int totalPoints = 0;

  for (const RawData &row : m_allData) {
    if (hasFilter && !filterSet.contains(row.id))
      continue;

    const quint32 rowCanId = row.numericId;
    const qint64 xv = row.timestamp; // epoch ms — no string parsing needed

    for (const ConfigInfo &ci : enabledConfigs) {
      if (ci.normId != rowCanId)
        continue;

      const HexConfig &conf = *ci.cfg;
      double rawVal = 0.0;

      if (conf.isDBC) {
        if (!extractDbcSignalRaw(row.cleanHex, conf.startBit, conf.bitLength,
                                 conf.littleEndian, conf.isSigned, rawVal))
          continue;
      } else {
        int startPos = conf.startByte * 2;
        int sliceLen = (conf.endByte - conf.startByte + 1) * 2;
        if (startPos + sliceLen > row.cleanHex.length())
          continue;
        bool ok = false;
        rawVal =
            (double)row.cleanHex.mid(startPos, sliceLen).toLongLong(&ok, 16);
        if (!ok)
          continue;
      }

      double finalVal = evaluateFormula(rawVal, conf.formula);

      pointsMap[ci.name].append(QPointF(xv, finalVal));
      minX = qMin(minX, xv);
      maxX = qMax(maxX, xv);
      minY = qMin(minY, finalVal);
      maxY = qMax(maxY, finalVal);
      ++totalPoints;
    }
  }

  if (pointsMap.isEmpty()) {
    QMessageBox::information(this, "Plot", "No signals enabled for plotting.");
    return;
  }

  // ── Build chart ───────────────────────────────────────────────────────────
  auto *chart = new QChart();
  chart->setTitle("Decoded Values -- Time Series");
  chart->setAnimationOptions(QChart::NoAnimation);

  const int MAX_POINTS_PER_SERIES = m_settings.graphMaxPts;
  int seriesCount = 0;

  for (auto it = pointsMap.begin(); it != pointsMap.end(); ++it) {
    const QString &name = it.key();
    QColor seriesColor = Qt::blue;
    int seriesStyle = 0;

    if (cfgHash.contains(name)) {
      seriesColor = cfgHash[name].color;
      seriesStyle = cfgHash[name].style;
    }

    QVector<QPointF> &pts = it.value();

    // Downsample if too many points
    QVector<QPointF> finalPts;
    if (pts.size() > MAX_POINTS_PER_SERIES) {
      finalPts.reserve(MAX_POINTS_PER_SERIES + 1);
      double step = static_cast<double>(pts.size()) / MAX_POINTS_PER_SERIES;
      for (int i = 0; i < MAX_POINTS_PER_SERIES; ++i)
        finalPts.append(pts[static_cast<int>(i * step)]);
      finalPts.append(pts.last());
    } else {
      finalPts = std::move(pts); // move instead of copy
    }

    if (seriesStyle == 2) {
      auto *scatter = new QScatterSeries();
      scatter->setName(name);
      scatter->setColor(seriesColor);
      scatter->setMarkerSize(6);
      scatter->setUseOpenGL(false);
      scatter->replace(finalPts);
      chart->addSeries(scatter);
    } else {
      auto *line = new QLineSeries();
      line->setName(name);
      line->setColor(seriesColor);
      line->setUseOpenGL(false);
      if (seriesStyle == 1) {
        QPen pen(seriesColor, 2, Qt::DashLine);
        line->setPen(pen);
      }
      line->replace(finalPts);
      chart->addSeries(line);
    }
    ++seriesCount;
  }

  auto *axX = new QDateTimeAxis;
  axX->setFormat("HH:mm:ss.zzz");
  axX->setTitleText("Time");
  axX->setRange(QDateTime::fromMSecsSinceEpoch(minX),
                QDateTime::fromMSecsSinceEpoch(maxX));
  chart->addAxis(axX, Qt::AlignBottom);

  double pad = (maxY - minY) * 0.08 + 0.001;
  auto *axY = new QValueAxis;
  axY->setTitleText("Value");
  axY->setRange(minY - pad, maxY + pad);
  chart->addAxis(axY, Qt::AlignLeft);
  for (auto *s : chart->series()) {
    s->attachAxis(axX);
    s->attachAxis(axY);
  }

  QChart *oldChart = m_chartView->chart();
  m_chartView->setChart(chart);
  delete oldChart;
  m_chartView->freezeForInspection(minX, maxX);
  switchPage(PAGE_GRAPH);
  statusBar()->showMessage(QString("Plot: %1 series, %2 data points.")
                               .arg(seriesCount)
                               .arg(totalPoints));
}

void MainWindow::onThemeLight() {
  applyTheme(false);
  saveSettings();
  statusBar()->showMessage("Light theme.");
}
void MainWindow::onThemeDark() {
  applyTheme(true);
  saveSettings();
  statusBar()->showMessage("Dark theme.");
}

void MainWindow::onUserGuide() {
  QFile src(":/docs/HEDAP_Kullanim_Kilavuzu.pdf");
  if (!src.open(QIODevice::ReadOnly)) {
    QMessageBox::warning(this, "User Guide", "User guide could not be opened.");
    return;
  }
  QTemporaryFile tmp;
  tmp.setFileTemplate(QDir::tempPath() + "/HEDAP_Kullanim_Kilavuzu_XXXXXX.pdf");
  tmp.setAutoRemove(false);
  if (!tmp.open()) {
    QMessageBox::warning(this, "User Guide", "Temporary file could not be created.");
    return;
  }
  tmp.write(src.readAll());
  tmp.close();
  QDesktopServices::openUrl(QUrl::fromLocalFile(tmp.fileName()));
}

void MainWindow::onAbout() {
  QMessageBox::about(this, "About HEDAP",
                     "<b>HEDAP</b>  –  Hex Data Analysis Platform<br>"
                     "Version 1.0<br><br>"
                     "CSV import · DBC decoding · Formula decoding · "
                     "Time-series plotting<br><br>"
                     "Developed by: Ali Dereyurt<br>"
                     "GitHub: github.com/dereyurtali");
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::applySettings() {
  if (m_settings.darkTheme != m_isDark)
    applyTheme(m_settings.darkTheme);
  if (m_reconnectTimer)
    m_reconnectTimer->setInterval(m_settings.reconnectIntervalSec * 1000);
  if (m_liveSimTimer)
    m_liveSimTimer->setInterval(1000 / std::max(1, m_settings.simFps));

  auto applyToChart = [&](DroppableChartView *cv) {
    cv->setWindowMs(m_settings.liveWindowSec * 1000);
    cv->setDecimalPlaces(m_settings.signalDecimalPlaces);
    cv->setThresholds(m_settings.thresholds);
    cv->setDeltaModeEnabled(m_settings.deltaModeEnabled);
    cv->setStatsOverlayEnabled(m_settings.statsOverlayEnabled);
    cv->setFixedYAxis(m_settings.fixedYAxis, m_settings.fixedYMin, m_settings.fixedYMax);
    cv->setRectZoomEnabled(m_settings.rectZoomEnabled);
  };
  for (DroppableChartView *cv : m_liveCharts) applyToChart(cv);
  if (m_chartView) applyToChart(m_chartView);

  // Apply keyboard shortcuts to QActions
  const QList<QPair<QString, QAction*>> actionMap = {
      {"action_load",       ui->action_load},
      {"action_load_dbc",   ui->action_load_dbc},
      {"action_export_csv", ui->action_export_csv},
      {"action_filter",     ui->action_filter},
      {"action_conf",       ui->action_conf},
      {"action_graph",      ui->action_graph},
      {"action_settings",   ui->action_settings},
  };
  for (const auto &pair : actionMap) {
      if (m_settings.shortcuts.contains(pair.first))
          pair.second->setShortcut(m_settings.shortcuts[pair.first]);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::openSettings() {
  QDialog dlg(this);
  dlg.setWindowTitle(tr("Settings"));
  dlg.setMinimumWidth(700);
  dlg.setModal(true);

  QTabWidget *tabs = new QTabWidget(&dlg);
  tabs->tabBar()->setExpanding(false);  // tabs stay compact; don't stretch to fill width
  tabs->tabBar()->setUsesScrollButtons(true); // scroll arrows appear if tabs still overflow

  // ── Tab 1: Live Monitor ──────────────────────────────────────────────────
  {
    QWidget *tab = new QWidget;
    QFormLayout *form = new QFormLayout(tab);
    form->setContentsMargins(16, 16, 16, 16);
    form->setSpacing(10);

    auto *liveWindowSpin = new QSpinBox;
    liveWindowSpin->setRange(5, 300);
    liveWindowSpin->setSingleStep(5);
    liveWindowSpin->setSuffix(" s");
    liveWindowSpin->setValue(m_settings.liveWindowSec);
    form->addRow(tr("Chart window:"), liveWindowSpin);

    auto *autoReconnectCb = new QCheckBox;
    autoReconnectCb->setChecked(m_settings.autoReconnect);
    form->addRow(tr("Auto-reconnect on disconnect:"), autoReconnectCb);

    auto *reconnectSpin = new QSpinBox;
    reconnectSpin->setRange(1, 60);
    reconnectSpin->setSuffix(" s");
    reconnectSpin->setValue(m_settings.reconnectIntervalSec);
    reconnectSpin->setEnabled(m_settings.autoReconnect);
    form->addRow(tr("Reconnect interval:"), reconnectSpin);

    connect(autoReconnectCb, &QCheckBox::toggled, reconnectSpin,
            &QSpinBox::setEnabled);

    tabs->addTab(tab, tr("Live Monitor"));

    // Store pointers for OK handler (via lambda captures)
    connect(&dlg, &QDialog::accepted, this,
            [this, liveWindowSpin, autoReconnectCb, reconnectSpin] {
              m_settings.liveWindowSec        = liveWindowSpin->value();
              m_settings.autoReconnect        = autoReconnectCb->isChecked();
              m_settings.reconnectIntervalSec = reconnectSpin->value();
            });
  }

  // ── Tab 2: Graph & Display ───────────────────────────────────────────────
  {
    QWidget *tab = new QWidget;
    QFormLayout *form = new QFormLayout(tab);
    form->setContentsMargins(16, 16, 16, 16);
    form->setSpacing(10);

    auto *graphMaxPtsSpin = new QSpinBox;
    graphMaxPtsSpin->setRange(100, 50000);
    graphMaxPtsSpin->setSingleStep(100);
    graphMaxPtsSpin->setSuffix(" pts");
    graphMaxPtsSpin->setValue(m_settings.graphMaxPts);
    form->addRow(tr("Max points per series (Graph):"), graphMaxPtsSpin);

    auto *decimalSpin = new QSpinBox;
    decimalSpin->setRange(0, 6);
    decimalSpin->setValue(m_settings.signalDecimalPlaces);
    form->addRow(tr("Signal decimal places:"), decimalSpin);

    auto *exportWSpin = new QSpinBox;
    exportWSpin->setRange(320, 7680);
    exportWSpin->setSingleStep(80);
    exportWSpin->setSuffix(" px");
    exportWSpin->setValue(m_settings.exportWidth);
    form->addRow(tr("PNG export width:"), exportWSpin);

    auto *exportHSpin = new QSpinBox;
    exportHSpin->setRange(240, 4320);
    exportHSpin->setSingleStep(45);
    exportHSpin->setSuffix(" px");
    exportHSpin->setValue(m_settings.exportHeight);
    form->addRow(tr("PNG export height:"), exportHSpin);

    tabs->addTab(tab, tr("Graph & Display"));

    connect(&dlg, &QDialog::accepted, this,
            [this, graphMaxPtsSpin, decimalSpin, exportWSpin, exportHSpin] {
              m_settings.graphMaxPts         = graphMaxPtsSpin->value();
              m_settings.signalDecimalPlaces = decimalSpin->value();
              m_settings.exportWidth         = exportWSpin->value();
              m_settings.exportHeight        = exportHSpin->value();
            });
  }

  // ── Tab 3: Recording ─────────────────────────────────────────────────────
  {
    QWidget *tab = new QWidget;
    QFormLayout *form = new QFormLayout(tab);
    form->setContentsMargins(16, 16, 16, 16);
    form->setSpacing(10);

    auto *autoLogCb = new QCheckBox;
    autoLogCb->setChecked(m_settings.autoLogOnConnect);
    form->addRow(tr("Auto-log on connect:"), autoLogCb);

    auto *logDirEdit = new QLineEdit;
    logDirEdit->setReadOnly(true);
    logDirEdit->setPlaceholderText(defaultLogBase());
    logDirEdit->setText(m_settings.logDirectory);

    auto *browseBtn = new QPushButton(tr("Browse…"));
    connect(browseBtn, &QPushButton::clicked, this, [&dlg, logDirEdit] {
      QString dir = QFileDialog::getExistingDirectory(
          &dlg, tr("Choose log directory"), logDirEdit->text());
      if (!dir.isEmpty())
        logDirEdit->setText(dir);
    });

    QHBoxLayout *dirRow = new QHBoxLayout;
    dirRow->addWidget(logDirEdit);
    dirRow->addWidget(browseBtn);
    form->addRow(tr("Log directory:"), dirRow);

    // DBC Session group
    auto *dbcGroup = new QGroupBox(tr("DBC Session"));
    QVBoxLayout *dbcLayout = new QVBoxLayout(dbcGroup);
    auto *rememberDbcCb = new QCheckBox(tr("Remember last DBC file on close"));
    auto *restoreDbcCb  = new QCheckBox(tr("Restore last DBC on startup"));
    rememberDbcCb->setChecked(m_settings.rememberLastDbc);
    restoreDbcCb->setChecked(m_settings.restoreLastDbc);
    restoreDbcCb->setEnabled(m_settings.rememberLastDbc);
    connect(rememberDbcCb, &QCheckBox::toggled, restoreDbcCb, &QWidget::setEnabled);
    dbcLayout->addWidget(rememberDbcCb);
    dbcLayout->addWidget(restoreDbcCb);
    form->addRow(dbcGroup);

    tabs->addTab(tab, tr("Recording"));

    connect(&dlg, &QDialog::accepted, this,
            [this, autoLogCb, logDirEdit, rememberDbcCb, restoreDbcCb] {
              m_settings.autoLogOnConnect = autoLogCb->isChecked();
              m_settings.logDirectory    = logDirEdit->text();
              m_settings.rememberLastDbc = rememberDbcCb->isChecked();
              m_settings.restoreLastDbc  = restoreDbcCb->isChecked();
            });
  }

  // ── Tab 4: Interface ─────────────────────────────────────────────────────
  {
    QWidget *tab = new QWidget;
    QFormLayout *form = new QFormLayout(tab);
    form->setContentsMargins(16, 16, 16, 16);
    form->setSpacing(10);

    auto *themeLight = new QRadioButton(tr("Light"));
    auto *themeDark  = new QRadioButton(tr("Dark"));
    if (m_settings.darkTheme) themeDark->setChecked(true);
    else                      themeLight->setChecked(true);

    QHBoxLayout *themeRow = new QHBoxLayout;
    themeRow->addWidget(themeLight);
    themeRow->addWidget(themeDark);
    themeRow->addStretch();
    form->addRow(tr("Theme:"), themeRow);

    auto *simFpsSpin = new QSpinBox;
    simFpsSpin->setRange(1, 60);
    simFpsSpin->setSuffix(" fps");
    simFpsSpin->setValue(m_settings.simFps);
    form->addRow(tr("CSV simulation speed:"), simFpsSpin);

    tabs->addTab(tab, tr("Interface"));

    connect(&dlg, &QDialog::accepted, this,
            [this, themeDark, simFpsSpin] {
              m_settings.darkTheme = themeDark->isChecked();
              m_settings.simFps    = simFpsSpin->value();
            });
  }

  // ── Tab 5: Chart Tools ───────────────────────────────────────────────────
  {
    QWidget *tab = new QWidget;
    QFormLayout *form = new QFormLayout(tab);
    form->setContentsMargins(16, 16, 16, 16);
    form->setSpacing(10);

    auto *deltaCb = new QCheckBox;
    deltaCb->setChecked(m_settings.deltaModeEnabled);
    form->addRow(tr("Delta cursor (click A, click B → shows ΔT / ΔY):"), deltaCb);

    auto *statsCb = new QCheckBox;
    statsCb->setChecked(m_settings.statsOverlayEnabled);
    form->addRow(tr("Statistics overlay (min / max / avg for visible window):"), statsCb);

    auto *fixedYCb = new QCheckBox;
    fixedYCb->setChecked(m_settings.fixedYAxis);
    form->addRow(tr("Fixed Y-axis range:"), fixedYCb);

    auto *yMinSpin = new QDoubleSpinBox;
    yMinSpin->setRange(-1e9, 1e9);
    yMinSpin->setDecimals(3);
    yMinSpin->setValue(m_settings.fixedYMin);
    yMinSpin->setEnabled(m_settings.fixedYAxis);
    form->addRow(tr("  Y min:"), yMinSpin);

    auto *yMaxSpin = new QDoubleSpinBox;
    yMaxSpin->setRange(-1e9, 1e9);
    yMaxSpin->setDecimals(3);
    yMaxSpin->setValue(m_settings.fixedYMax);
    yMaxSpin->setEnabled(m_settings.fixedYAxis);
    form->addRow(tr("  Y max:"), yMaxSpin);

    connect(fixedYCb, &QCheckBox::toggled, yMinSpin, &QDoubleSpinBox::setEnabled);
    connect(fixedYCb, &QCheckBox::toggled, yMaxSpin, &QDoubleSpinBox::setEnabled);

    auto *rectZoomCb = new QCheckBox;
    rectZoomCb->setChecked(m_settings.rectZoomEnabled);
    form->addRow(tr("Rectangle zoom (drag to zoom, Ctrl+drag to pan):"), rectZoomCb);

    tabs->addTab(tab, tr("Chart Tools"));

    connect(&dlg, &QDialog::accepted, this,
            [this, deltaCb, statsCb, fixedYCb, yMinSpin, yMaxSpin, rectZoomCb] {
              m_settings.deltaModeEnabled    = deltaCb->isChecked();
              m_settings.statsOverlayEnabled = statsCb->isChecked();
              m_settings.fixedYAxis          = fixedYCb->isChecked();
              m_settings.fixedYMin           = yMinSpin->value();
              m_settings.fixedYMax           = yMaxSpin->value();
              m_settings.rectZoomEnabled     = rectZoomCb->isChecked();
            });
  }

  // ── Tab 6: Thresholds ────────────────────────────────────────────────────
  {
    QWidget *tab = new QWidget;
    QVBoxLayout *vbox = new QVBoxLayout(tab);
    vbox->setContentsMargins(12, 12, 12, 12);
    vbox->setSpacing(8);

    // Toolbar row
    QHBoxLayout *toolbar = new QHBoxLayout;
    auto *addBtn = new QPushButton(tr("+ Add"));
    auto *delBtn = new QPushButton(tr("Delete"));
    toolbar->addWidget(addBtn);
    toolbar->addWidget(delBtn);
    toolbar->addStretch();
    vbox->addLayout(toolbar);

    // Table: Signal | Value | Color | Enabled
    auto *tbl = new QTableWidget(0, 4);
    tbl->setHorizontalHeaderLabels({tr("Signal"), tr("Value"), tr("Color"), tr("Enabled")});
    tbl->horizontalHeader()->setStretchLastSection(false);
    tbl->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    tbl->horizontalHeader()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    tbl->horizontalHeader()->setSectionResizeMode(2, QHeaderView::ResizeToContents);
    tbl->horizontalHeader()->setSectionResizeMode(3, QHeaderView::ResizeToContents);
    tbl->setSelectionBehavior(QAbstractItemView::SelectRows);
    tbl->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);
    vbox->addWidget(tbl);

    // Collect known signal names for the dropdown
    QStringList knownSignals;
    for (const HexConfig &cfg : m_savedConfigs)
      if (!cfg.name.isEmpty()) knownSignals << cfg.name;
    for (const QString &k : m_liveHistory.keys())
      if (!knownSignals.contains(k)) knownSignals << k;
    knownSignals.sort(Qt::CaseInsensitive);
    knownSignals.prepend(QString()); // empty = applies to all signals

    // Populate from existing thresholds
    auto addRow = [tbl, knownSignals](const ThresholdConfig &th) {
      int row = tbl->rowCount();
      tbl->insertRow(row);

      auto *combo = new QComboBox;
      combo->setEditable(true);
      combo->addItems(knownSignals);
      combo->setCurrentText(th.signalName);
      tbl->setCellWidget(row, 0, combo);

      auto *valItem = new QTableWidgetItem(QString::number(th.value, 'f', 4));
      tbl->setItem(row, 1, valItem);

      auto *colorItem = new QTableWidgetItem;
      colorItem->setBackground(th.color);
      colorItem->setFlags(colorItem->flags() & ~Qt::ItemIsEditable);
      colorItem->setData(Qt::UserRole, th.color);
      tbl->setItem(row, 2, colorItem);

      auto *enabledItem = new QTableWidgetItem;
      enabledItem->setCheckState(th.enabled ? Qt::Checked : Qt::Unchecked);
      enabledItem->setFlags(enabledItem->flags() | Qt::ItemIsUserCheckable);
      tbl->setItem(row, 3, enabledItem);
    };

    for (const ThresholdConfig &th : m_settings.thresholds)
      addRow(th);

    // + Add button
    connect(addBtn, &QPushButton::clicked, tbl, [addRow] {
      ThresholdConfig th;
      addRow(th);
    });

    // Delete button
    connect(delBtn, &QPushButton::clicked, tbl, [tbl] {
      QList<int> rows;
      for (QTableWidgetItem *it : tbl->selectedItems())
        if (!rows.contains(it->row())) rows << it->row();
      std::sort(rows.rbegin(), rows.rend());
      for (int r : rows) tbl->removeRow(r);
    });

    // Double-click on Color column → color picker
    connect(tbl, &QTableWidget::cellDoubleClicked, &dlg,
            [tbl, &dlg](int row, int col) {
              if (col != 2) return;
              QTableWidgetItem *it = tbl->item(row, 2);
              if (!it) return;
              QColor current = it->data(Qt::UserRole).value<QColor>();
              QColor picked = QColorDialog::getColor(current, &dlg, tr("Choose threshold color"));
              if (picked.isValid()) {
                it->setBackground(picked);
                it->setData(Qt::UserRole, picked);
              }
            });

    tabs->addTab(tab, tr("Thresholds"));

    // Harvest rows on OK
    connect(&dlg, &QDialog::accepted, this, [this, tbl] {
      m_settings.thresholds.clear();
      for (int row = 0; row < tbl->rowCount(); ++row) {
        ThresholdConfig th;
        if (auto *cb = qobject_cast<QComboBox*>(tbl->cellWidget(row, 0)))
          th.signalName = cb->currentText().trimmed();
        if (tbl->item(row, 1)) th.value = tbl->item(row, 1)->text().toDouble();
        if (tbl->item(row, 2)) th.color = tbl->item(row, 2)->data(Qt::UserRole).value<QColor>();
        if (tbl->item(row, 3)) th.enabled = tbl->item(row, 3)->checkState() == Qt::Checked;
        if (!th.color.isValid()) th.color = QColor(255, 140, 0);
        m_settings.thresholds.append(th);
      }
    });
  }

  // ── Tab 7: Shortcuts ─────────────────────────────────────────────────────
  {
    QWidget *tab = new QWidget;
    QFormLayout *form = new QFormLayout(tab);
    form->setContentsMargins(16, 16, 16, 16);
    form->setSpacing(10);

    const QList<QPair<QString, QString>> rows = {
        {tr("Open CSV"),           "action_load"},
        {tr("Load DBC"),           "action_load_dbc"},
        {tr("Export Raw CSV"),     "action_export_csv"},
        {tr("Filter by ID"),       "action_filter"},
        {tr("Configure Decoders"), "action_conf"},
        {tr("Plot Graph"),         "action_graph"},
        {tr("Settings"),           "action_settings"},
    };

    QList<QPair<QString, QKeySequenceEdit*>> editors;
    for (const auto &row : rows) {
        auto *edit = new QKeySequenceEdit;
        edit->setKeySequence(m_settings.shortcuts.value(row.second));
        form->addRow(row.first + ":", edit);
        editors.append({row.second, edit});
    }

    auto *resetBtn = new QPushButton(tr("Reset to Defaults"));
    form->addRow(resetBtn);
    connect(resetBtn, &QPushButton::clicked, this, [editors] {
        const QMap<QString, QKeySequence> defs = {
            {"action_load",       QKeySequence("Ctrl+O")},
            {"action_load_dbc",   QKeySequence("Ctrl+D")},
            {"action_export_csv", QKeySequence("Ctrl+E")},
            {"action_filter",     QKeySequence("Ctrl+F")},
            {"action_conf",       QKeySequence("Ctrl+K")},
            {"action_graph",      QKeySequence("Ctrl+G")},
            {"action_settings",   QKeySequence("Ctrl+,")},
        };
        for (const auto &e : editors)
            e.second->setKeySequence(defs.value(e.first));
    });

    tabs->addTab(tab, tr("Shortcuts"));

    connect(&dlg, &QDialog::accepted, this, [this, editors] {
        for (const auto &e : editors)
            m_settings.shortcuts[e.first] = e.second->keySequence();
    });
  }

  // ── Layout + buttons ─────────────────────────────────────────────────────
  auto *buttons = new QDialogButtonBox(
      QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
  connect(buttons, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
  connect(buttons, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

  auto *mainLayout = new QVBoxLayout(&dlg);
  mainLayout->addWidget(tabs);
  mainLayout->addWidget(buttons);

  if (dlg.exec() == QDialog::Accepted) {
    applySettings();
    saveSettings();
  }
}

void MainWindow::saveConfigsToFile() {
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QDir().mkpath(dir);
  QFile f(dir + "/configs.json");
  if (!f.open(QIODevice::WriteOnly))
    return;
  QJsonArray arr;
  for (const HexConfig &c : m_savedConfigs) {
    if (c.isDBC)
      continue; // DBC configs are transient; re-imported each session
    QJsonObject o;
    c.write(o);
    arr.append(o);
  }
  f.write(QJsonDocument(arr).toJson());
}

void MainWindow::loadConfigsFromFile() {
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QFile f(dir + "/configs.json");
  if (!f.open(QIODevice::ReadOnly))
    return;
  m_savedConfigs.clear();
  QJsonParseError err;
  QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &err);
  if (err.error == QJsonParseError::NoError && doc.isArray()) {
    for (const QJsonValue &v : doc.array()) {
      HexConfig c;
      c.read(v.toObject());

      // MED-3: validate fields loaded from disk to prevent exploitation
      c.startByte = qBound(0, c.startByte, 7);
      c.endByte = qBound(c.startByte, c.endByte, 7);
      c.startBit = qBound(0, c.startBit, 63);
      c.bitLength = qBound(1, c.bitLength, 64);

      // Validate formula: SafeEval will reject bad formulas at runtime,
      // but truncate obviously suspicious strings from tampered files.
      if (c.formula.length() > 512)
        c.formula.clear();

      m_savedConfigs.append(c);
    }
  }
}

void MainWindow::saveSettings() {
  QJsonObject obj;
  obj["lastDbcPath"]         = m_settings.rememberLastDbc ? m_loadedDbcFile : QString();
  obj["rememberLastDbc"]     = m_settings.rememberLastDbc;
  obj["restoreLastDbc"]      = m_settings.restoreLastDbc;
  // AppSettings fields
  obj["darkTheme"]           = m_settings.darkTheme;
  obj["liveWindowSec"]       = m_settings.liveWindowSec;
  obj["autoReconnect"]       = m_settings.autoReconnect;
  obj["reconnectIntervalSec"]= m_settings.reconnectIntervalSec;
  obj["graphMaxPts"]         = m_settings.graphMaxPts;
  obj["signalDecimalPlaces"] = m_settings.signalDecimalPlaces;
  obj["autoLogOnConnect"]    = m_settings.autoLogOnConnect;
  obj["logDirectory"]        = m_settings.logDirectory;
  obj["simFps"]              = m_settings.simFps;
  // Chart tools
  obj["deltaModeEnabled"]    = m_settings.deltaModeEnabled;
  obj["statsOverlayEnabled"] = m_settings.statsOverlayEnabled;
  obj["fixedYAxis"]          = m_settings.fixedYAxis;
  obj["fixedYMin"]           = m_settings.fixedYMin;
  obj["fixedYMax"]           = m_settings.fixedYMax;
  obj["rectZoomEnabled"]     = m_settings.rectZoomEnabled;
  QJsonArray thArr;
  for (const ThresholdConfig &th : m_settings.thresholds) {
    QJsonObject o; th.write(o); thArr.append(o);
  }
  obj["thresholds"] = thArr;
  obj["exportWidth"]  = m_settings.exportWidth;
  obj["exportHeight"] = m_settings.exportHeight;
  QJsonObject scObj;
  for (auto it = m_settings.shortcuts.cbegin(); it != m_settings.shortcuts.cend(); ++it)
      scObj[it.key()] = it.value().toString();
  obj["shortcuts"] = scObj;

  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QDir().mkpath(dir);
  QFile f(dir + "/settings.json");
  if (!f.open(QIODevice::WriteOnly))
    return;
  f.write(QJsonDocument(obj).toJson());
}

void MainWindow::loadSettings() {
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QFile f(dir + "/settings.json");
  if (!f.open(QIODevice::ReadOnly))
    return;
  QJsonParseError err;
  QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &err);
  if (err.error != QJsonParseError::NoError || !doc.isObject())
    return;
  QJsonObject obj = doc.object();

  if (obj.contains("darkTheme"))
    m_settings.darkTheme = obj["darkTheme"].toBool();
  if (obj.contains("liveWindowSec"))
    m_settings.liveWindowSec = qBound(5, obj["liveWindowSec"].toInt(30), 300);
  if (obj.contains("autoReconnect"))
    m_settings.autoReconnect = obj["autoReconnect"].toBool();
  if (obj.contains("reconnectIntervalSec"))
    m_settings.reconnectIntervalSec = qBound(1, obj["reconnectIntervalSec"].toInt(2), 60);
  if (obj.contains("graphMaxPts"))
    m_settings.graphMaxPts = qBound(100, obj["graphMaxPts"].toInt(2000), 50000);
  if (obj.contains("signalDecimalPlaces"))
    m_settings.signalDecimalPlaces = qBound(0, obj["signalDecimalPlaces"].toInt(3), 6);
  if (obj.contains("autoLogOnConnect"))
    m_settings.autoLogOnConnect = obj["autoLogOnConnect"].toBool();
  if (obj.contains("logDirectory"))
    m_settings.logDirectory = obj["logDirectory"].toString();
  if (obj.contains("simFps"))
    m_settings.simFps = qBound(1, obj["simFps"].toInt(10), 60);
  // Chart tools
  if (obj.contains("deltaModeEnabled"))    m_settings.deltaModeEnabled    = obj["deltaModeEnabled"].toBool();
  if (obj.contains("statsOverlayEnabled")) m_settings.statsOverlayEnabled = obj["statsOverlayEnabled"].toBool();
  if (obj.contains("fixedYAxis"))          m_settings.fixedYAxis          = obj["fixedYAxis"].toBool();
  if (obj.contains("fixedYMin"))           m_settings.fixedYMin           = obj["fixedYMin"].toDouble(0.0);
  if (obj.contains("fixedYMax"))           m_settings.fixedYMax           = obj["fixedYMax"].toDouble(100.0);
  if (obj.contains("rectZoomEnabled"))     m_settings.rectZoomEnabled     = obj["rectZoomEnabled"].toBool();
  if (obj.contains("thresholds") && obj["thresholds"].isArray()) {
    m_settings.thresholds.clear();
    for (const QJsonValue &v : obj["thresholds"].toArray()) {
      ThresholdConfig th; th.read(v.toObject());
      if (th.signalName.length() > 256) th.signalName.clear();
      m_settings.thresholds.append(th);
    }
  }

  if (obj.contains("exportWidth"))
      m_settings.exportWidth  = qBound(320,  obj["exportWidth"].toInt(1280),  7680);
  if (obj.contains("exportHeight"))
      m_settings.exportHeight = qBound(240,  obj["exportHeight"].toInt(720),  4320);
  if (obj.contains("shortcuts") && obj["shortcuts"].isObject()) {
      const QJsonObject scObj = obj["shortcuts"].toObject();
      for (const QString &key : scObj.keys()) {
          const QString val = scObj[key].toString();
          if (!val.isEmpty())
              m_settings.shortcuts[key] = QKeySequence(val);
      }
  }

  if (obj.contains("rememberLastDbc")) m_settings.rememberLastDbc = obj["rememberLastDbc"].toBool(true);
  if (obj.contains("restoreLastDbc"))  m_settings.restoreLastDbc  = obj["restoreLastDbc"].toBool(true);

  // Keep m_isDark in sync so applyTheme() calls use the right value
  m_isDark = m_settings.darkTheme;
}

void MainWindow::restoreLastDBC() {
  if (!m_settings.restoreLastDbc)
    return;
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QFile f(dir + "/settings.json");
  if (!f.open(QIODevice::ReadOnly))
    return;
  QJsonParseError err;
  QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &err);
  if (err.error != QJsonParseError::NoError || !doc.isObject())
    return;
  QString path = doc.object()["lastDbcPath"].toString();
  if (path.isEmpty() || !QFile::exists(path))
    return;

  // Silently re-parse — no auto-import yet (waits for CSV/live to trigger)
  if (!m_dbcParser.parse(path))
    return;
  m_loadedDbcFile = path;
  m_actUnloadDBC->setEnabled(true);
  updateDBCStatus();
}
