#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QJsonArray>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QMap>
#include <QDialog>
#include <QVBoxLayout>
#include <QListWidget>
#include <QDialogButtonBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_summaryModel(new QStandardItemModel(this))
    , m_resultModel(new QStandardItemModel(this))
{
    ui->setupUi(this);
    setWindowTitle("HEDAP - Hex Data Analysis Platform");

    // --- TABLO AYARLARI ---
    ui->tbl_summary->setModel(m_summaryModel);
    ui->tbl_summary->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tbl_summary->setSelectionBehavior(QAbstractItemView::SelectRows);

    ui->tbl_result->setModel(m_resultModel);
    ui->tbl_result->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tbl_result->setSelectionBehavior(QAbstractItemView::SelectRows);

    setInterfaceState(false);

    loadConfigsFromFile();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// --- ARAYÜZ YÖNETİMİ ---

void MainWindow::setInterfaceState(bool hasData)
{
    ui->btn_unload->setEnabled(hasData);
    ui->btn_filter->setEnabled(hasData);
    ui->btn_reset->setEnabled(hasData);
    ui->btn_conf->setEnabled(hasData);
    ui->btn_export->setEnabled(hasData);
    ui->btn_exportdata->setEnabled(hasData);
    ui->btn_graph->setEnabled(hasData);
}

// --- VERİ İŞLEME ---

void MainWindow::parseAndStoreLine(const QString &line)
{
    QStringList parts = line.split(',');
    if (parts.size() < 8) return;

    RawData data;
    data.isoTime   = parts[0].trimmed();
    data.timestamp = parts[1].trimmed().toLongLong();
    data.id        = parts[4].trimmed();
    data.dataHex   = parts[7].trimmed();

    m_allData.append(data);
}

void MainWindow::populateSummaryTable(const QStringList &filterIds)
{
    m_summaryModel->clear();
    QStringList headers;
    headers << "ID" << "Count" << "Start Time" << "End Time";
    m_summaryModel->setHorizontalHeaderLabels(headers);

    struct GroupInfo {
        int count = 0;
        qint64 minEpoch = -1;
        qint64 maxEpoch = -1;
        QString startTime;
        QString endTime;
    };

    QMap<QString, GroupInfo> groups;

    for (const RawData &row : m_allData) {
        if (!filterIds.isEmpty() && !filterIds.contains(row.id)) {
            continue;
        }

        GroupInfo &info = groups[row.id];
        info.count++;

        if (info.minEpoch == -1 || row.timestamp < info.minEpoch) {
            info.minEpoch = row.timestamp;
            info.startTime = row.isoTime;
        }

        if (info.maxEpoch == -1 || row.timestamp > info.maxEpoch) {
            info.maxEpoch = row.timestamp;
            info.endTime = row.isoTime;
        }
    }

    for (auto it = groups.begin(); it != groups.end(); ++it) {
        QString id = it.key();
        GroupInfo info = it.value();

        QList<QStandardItem *> items;
        items.append(new QStandardItem(id));
        items.append(new QStandardItem(QString::number(info.count)));
        items.append(new QStandardItem(info.startTime));
        items.append(new QStandardItem(info.endTime));

        m_summaryModel->appendRow(items);
    }
    ui->tbl_summary->resizeColumnsToContents();
}

// --- HESAPLAMA MOTORU ---

void MainWindow::calculateAndPopulateResultTable()
{
    m_resultModel->clear();

    QStringList headers;
    headers << "Time" << "ID" << "Config Name" << "Raw Hex" << "Calculated Value";
    m_resultModel->setHorizontalHeaderLabels(headers);

    for (const RawData &row : m_allData) {

        // Filtre kontrolü
        if (!m_activeFilters.isEmpty() && !m_activeFilters.contains(row.id)) {
            continue;
        }

        // Konfigürasyon eşleşmesi kontrolü
        for (const HexConfig &conf : m_savedConfigs) {
            if (conf.targetID == row.id) {
                // A. Hex Parçalama
                QString cleanHex = row.dataHex.simplified().replace(" ", "");
                int startPos = conf.startByte * 2;
                int length = (conf.endByte - conf.startByte + 1) * 2;

                if (startPos + length > cleanHex.length()) continue;

                QString subHex = cleanHex.mid(startPos, length);

                // B. Hex -> Decimal
                bool ok;
                qint64 rawVal = subHex.toLongLong(&ok, 16);
                if (!ok) continue;

                // C. Formül Uygulama
                double finalVal = evaluateFormula((double)rawVal, conf.formula);

                // D. Tabloya Yazma
                QList<QStandardItem *> items;
                items.append(new QStandardItem(row.isoTime));
                items.append(new QStandardItem(row.id));
                items.append(new QStandardItem(conf.name));
                items.append(new QStandardItem(QString("0x%1").arg(subHex)));
                items.append(new QStandardItem(QString::number(finalVal, 'f', 2)));

                m_resultModel->appendRow(items);
            }
        }
    }
    ui->tbl_result->resizeColumnsToContents();
}

double MainWindow::evaluateFormula(double rawValue, const QString &formula)
{
    if (formula.isEmpty()) return rawValue;

    QJSEngine engine;
    engine.globalObject().setProperty("x", rawValue);

    QJSValue result = engine.evaluate(formula);

    if (result.isError()) {
        qDebug() << "Formula Error:" << result.toString();
        return rawValue;
    }

    return result.toNumber();
}

// --- BUTON SLOTLARI ---

void MainWindow::on_btn_load_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this,
                                                    tr("Open CSV File"), "", tr("CSV Files (*.csv);;All Files (*)"));

    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot open file");
        return;
    }

    m_allData.clear();
    m_summaryModel->clear();
    m_resultModel->clear();
    m_activeFilters.clear(); // Filtreleri temizle

    QTextStream in(&file);
    if (!in.atEnd()) in.readLine();

    while (!in.atEnd()) {
        parseAndStoreLine(in.readLine());
    }
    file.close();

    populateSummaryTable();
    setInterfaceState(true);

    QMessageBox::information(this, "Success",
                             QString("Loaded %1 records.").arg(m_allData.size()));
}

void MainWindow::on_btn_unload_clicked()
{
    m_allData.clear();
    m_summaryModel->clear();
    m_resultModel->clear();
    m_activeFilters.clear();

    setInterfaceState(false);

    QMessageBox::information(this, "Info", "System unloaded.");
}

void MainWindow::on_btn_filter_clicked()
{
    QStringList uniqueIDs;
    for(const RawData &data : m_allData) {
        if(!uniqueIDs.contains(data.id)) uniqueIDs.append(data.id);
    }
    uniqueIDs.sort();

    QDialog filterDialog(this);
    filterDialog.setWindowTitle("Filter by ID");
    filterDialog.resize(300, 400);

    QVBoxLayout *layout = new QVBoxLayout(&filterDialog);
    QListWidget *listWidget = new QListWidget(&filterDialog);

    for(const QString &id : uniqueIDs) {
        QListWidgetItem *item = new QListWidgetItem(id, listWidget);
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);

        if (m_activeFilters.isEmpty() || m_activeFilters.contains(id)) {
            item->setCheckState(Qt::Checked);
        } else {
            item->setCheckState(Qt::Unchecked);
        }
    }
    layout->addWidget(listWidget);

    QDialogButtonBox *buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &filterDialog);
    layout->addWidget(buttonBox);

    connect(buttonBox, &QDialogButtonBox::accepted, &filterDialog, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, &filterDialog, &QDialog::reject);

    if(filterDialog.exec() == QDialog::Accepted) {
        QStringList selectedIds;
        for(int i = 0; i < listWidget->count(); ++i) {
            QListWidgetItem *item = listWidget->item(i);
            if(item->checkState() == Qt::Checked) {
                selectedIds.append(item->text());
            }
        }

        if(selectedIds.isEmpty()) {
            QMessageBox::warning(this, "Warning", "No ID selected!");
            return;
        }

        m_activeFilters = selectedIds;

        // Hem sol tabloyu hem sağ tabloyu güncelle
        populateSummaryTable(m_activeFilters);
        calculateAndPopulateResultTable();
    }
}

void MainWindow::on_btn_reset_clicked()
{
    m_resultModel->clear();
    m_activeFilters.clear();
    populateSummaryTable();

    // Sağ tabloyu da sıfırlamak veya tüm sonuçları göstermek isterseniz:
    calculateAndPopulateResultTable();
}

void MainWindow::on_btn_conf_clicked()
{
    QStringList uniqueIDs;
    for(const RawData &data : m_allData) {
        if(!uniqueIDs.contains(data.id)) uniqueIDs.append(data.id);
    }
    uniqueIDs.sort();

    ConfigDialog dlg(this);
    dlg.setIDList(uniqueIDs);
    dlg.setConfigList(m_savedConfigs);

    if (dlg.exec() == QDialog::Accepted) {
        m_savedConfigs = dlg.getConfigList();

        // Konfigürasyon değiştiğinde dosyaya kaydet!
        saveConfigsToFile();

        calculateAndPopulateResultTable();
        QMessageBox::information(this, "Success", "Configurations applied and saved!");
    }
}

void MainWindow::on_btn_export_clicked()
{
    // 1. Veri kontrolü
    if (m_allData.isEmpty()) {
        QMessageBox::warning(this, "Warning", "No data to export!");
        return;
    }

    // 2. Seçim Penceresini Oluştur (3 Butonlu)
    QMessageBox msgBox(this);
    msgBox.setWindowTitle("Export Options");
    msgBox.setText("Please select an export method:");
    msgBox.setIcon(QMessageBox::Question);

    // Butonları ekliyoruz
    QAbstractButton *btnGrouped = msgBox.addButton("Export Grouped (Summary)", QMessageBox::ActionRole);
    QAbstractButton *btnSelected = msgBox.addButton("Export Selected ID", QMessageBox::ActionRole);
    QAbstractButton *btnAll = msgBox.addButton("Export All Data", QMessageBox::ActionRole);
    QAbstractButton *btnCancel = msgBox.addButton(QMessageBox::Cancel);

    msgBox.exec(); // Pencereyi göster ve bekle

    // Kullanıcı iptal ettiyse veya pencereyi kapattıysa çık
    if (msgBox.clickedButton() == btnCancel || msgBox.clickedButton() == nullptr) {
        return;
    }

    // --- "Export Selected" İçin Özel Kontrol ---
    QString selectedIdFilter = "";
    if (msgBox.clickedButton() == btnSelected) {
        QModelIndex currentIndex = ui->tbl_summary->currentIndex();
        if (!currentIndex.isValid()) {
            QMessageBox::warning(this, "Warning", "Please select a row in the summary table first!");
            return;
        }
        // Seçili satırın 0. sütunundaki (ID sütunu) veriyi al
        selectedIdFilter = ui->tbl_summary->model()->index(currentIndex.row(), 0).data().toString();
    }
    // -------------------------------------------

    // 3. Dosya kaydetme penceresini aç
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    tr("Export CSV"), "", tr("CSV Files (*.csv);;All Files (*)"));

    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot save file");
        return;
    }

    QTextStream out(&file);
    // Excel dostu ayarlar (UTF-8 BOM)
    out.setEncoding(QStringConverter::Utf8);
    out.setGenerateByteOrderMark(true);


    // 4. SEÇİME GÖRE İŞLEMLER

    // A) EXPORT GROUPED (Soldaki Özet Tabloyu Olduğu Gibi Yaz)
    if (msgBox.clickedButton() == btnGrouped) {
        // Başlıklar
        out << "ID,Count,Start Time,End Time\n";

        // Tablodaki satırları dön
        for (int i = 0; i < m_summaryModel->rowCount(); ++i) {
            QString id = m_summaryModel->item(i, 0)->text();
            QString count = m_summaryModel->item(i, 1)->text();
            QString start = m_summaryModel->item(i, 2)->text();
            QString end = m_summaryModel->item(i, 3)->text();

            out << id << "," << count << "," << start << "," << end << "\n";
        }
    }

    // B) EXPORT SELECTED (Sadece seçili ID'nin ham verilerini yaz)
    else if (msgBox.clickedButton() == btnSelected) {
        // Başlıklar (Ham veri formatı)
        out << "ISO Time,Epoch Timestamp,Message ID,Data (Hex)\n";

        for (const RawData &data : m_allData) {
            if (data.id == selectedIdFilter) {
                out << data.isoTime << ","
                    << data.timestamp << ","
                    << data.id << ","
                    << data.dataHex << "\n";
            }
        }
    }

    // C) EXPORT ALL (Tüm ham veriyi yaz)
    else if (msgBox.clickedButton() == btnAll) {
        // Başlıklar
        out << "ISO Time,Epoch Timestamp,Message ID,Data (Hex)\n";

        for (const RawData &data : m_allData) {
            out << data.isoTime << ","
                << data.timestamp << ","
                << data.id << ","
                << data.dataHex << "\n";
        }
    }

    file.close();
    QMessageBox::information(this, "Success", "Export completed successfully!");
}

void MainWindow::on_btn_exportdata_clicked()
{
    // 1. Veri var mı?
    if (m_resultModel->rowCount() == 0) {
        QMessageBox::warning(this, "Warning", "No calculated data to export!");
        return;
    }

    // 2. Dosya kaydetme penceresi
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    tr("Export Result Data"), "", tr("CSV Files (*.csv);;All Files (*)"));

    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot save file");
        return;
    }

    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    out.setGenerateByteOrderMark(true); // Excel için BOM

    // 3. Başlıkları Yaz (Modelden alıyoruz)
    QStringList headers;
    for (int i = 0; i < m_resultModel->columnCount(); ++i) {
        headers << m_resultModel->headerData(i, Qt::Horizontal).toString();
    }
    out << headers.join(",") << "\n";

    // 4. Satırları Yaz
    for (int i = 0; i < m_resultModel->rowCount(); ++i) {
        QStringList rowData;
        for (int j = 0; j < m_resultModel->columnCount(); ++j) {
            // Veriyi al ve CSV formatına uygun hale getir (virgül varsa tırnak içine al vb.)
            QString text = m_resultModel->item(i, j)->text();
            rowData << text;
        }
        out << rowData.join(",") << "\n";
    }

    file.close();
    QMessageBox::information(this, "Success", "Calculated data exported successfully!");
}

void MainWindow::on_btn_graph_clicked()
{
    if (m_resultModel->rowCount() == 0) {
        QMessageBox::warning(this, "Warning", "No data to graph! Please Configure first.");
        return;
    }

    // 1. Serileri Oluştur (Her Konfigürasyon İsmi için ayrı bir çizgi)
    // Map yapısı: "Voltage" -> Seri1, "Current" -> Seri2
    QMap<QString, QLineSeries*> seriesMap;

    // Tabloyu tara
    for (int i = 0; i < m_resultModel->rowCount(); ++i) {
        // Sütunlar: 0:Time, 1:ID, 2:ConfigName, 3:Raw, 4:Value
        QString timeStr = m_resultModel->item(i, 0)->text();
        QString name = m_resultModel->item(i, 2)->text();
        double value = m_resultModel->item(i, 4)->text().toDouble();

        // Zamanı QDateTime'a çevir (Grafik X ekseni için ms cinsinden)
        QDateTime dt = QDateTime::fromString(timeStr, "yyyy-MM-dd HH:mm:ss.zzz");
        if (!dt.isValid()) dt = QDateTime::fromString(timeStr, Qt::ISODate); // Yedek format

        qint64 xValue = dt.toMSecsSinceEpoch();

        // Eğer bu isimde bir seri yoksa oluştur
        if (!seriesMap.contains(name)) {
            QLineSeries *series = new QLineSeries();
            series->setName(name);
            seriesMap.insert(name, series);
        }

        // Veriyi seriye ekle
        seriesMap[name]->append(xValue, value);
    }

    // 2. Grafiği Oluştur
    QChart *chart = new QChart();

    // Min/Max değerleri bulmak için (Eksenleri ayarlamak adına)
    qint64 minTime = std::numeric_limits<qint64>::max();
    qint64 maxTime = std::numeric_limits<qint64>::min();
    double minY = std::numeric_limits<double>::max();
    double maxY = std::numeric_limits<double>::min();

    for (auto series : seriesMap) {
        chart->addSeries(series);

        // Bu serideki min/max'ı bul
        for(const QPointF &p : series->points()) {
            if(p.x() < minTime) minTime = p.x();
            if(p.x() > maxTime) maxTime = p.x();
            if(p.y() < minY) minY = p.y();
            if(p.y() > maxY) maxY = p.y();
        }
    }

    chart->setTitle("Hex Data Analysis Graph");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    // 3. Eksenleri Oluştur
    // X Ekseni (Zaman)
    QDateTimeAxis *axisX = new QDateTimeAxis;
    axisX->setTickCount(10);
    axisX->setFormat("HH:mm:ss");
    axisX->setTitleText("Time");
    axisX->setRange(QDateTime::fromMSecsSinceEpoch(minTime), QDateTime::fromMSecsSinceEpoch(maxTime));
    chart->addAxis(axisX, Qt::AlignBottom);

    // Y Ekseni (Değer)
    QValueAxis *axisY = new QValueAxis;
    axisY->setTitleText("Value");
    axisY->setRange(minY - (minY*0.1), maxY + (maxY*0.1)); // Biraz boşluk bırak
    chart->addAxis(axisY, Qt::AlignLeft);

    // Serileri eksenlere bağla
    for (auto series : seriesMap) {
        series->attachAxis(axisX);
        series->attachAxis(axisY);
    }

    // 4. Grafiği Göster (Yeni bir Dialog içinde)
    QDialog *chartDialog = new QDialog(this);
    chartDialog->setWindowTitle("Data Visualization");
    chartDialog->resize(800, 600);

    QVBoxLayout *layout = new QVBoxLayout(chartDialog);
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing); // Çizgileri yumuşat

    layout->addWidget(chartView);

    // Grafiği resim olarak kaydet butonu da ekleyelim mi?
    QPushButton *btnSaveImg = new QPushButton("Save Graph as Image", chartDialog);
    layout->addWidget(btnSaveImg);

    connect(btnSaveImg, &QPushButton::clicked, [chartView, this](){
        QString path = QFileDialog::getSaveFileName(this, "Save Image", "", "PNG Image (*.png);;JPEG Image (*.jpg)");
        if(!path.isEmpty()) {
            QPixmap p = chartView->grab();
            p.save(path);
            QMessageBox::information(this, "Saved", "Graph saved successfully!");
        }
    });

    chartDialog->exec(); // Pencereyi aç
}

void MainWindow::saveConfigsToFile()
{
#include <QFileInfo>
#include <QDebug>
    QFile saveFile("configs.json"); // Uygulama klasörüne kaydeder
    if (!saveFile.open(QIODevice::WriteOnly)) {
        qWarning("Couldn't open save file.");
        return;
    }

    QJsonArray configArray;
    for (const HexConfig &conf : m_savedConfigs) {
        QJsonObject configObject;
        conf.write(configObject); // Struct içindeki fonksiyonu kullan
        configArray.append(configObject);
    }

    QJsonDocument saveDoc(configArray);
    saveFile.write(saveDoc.toJson());
    qDebug() << "Dosya Yolu:" << QFileInfo("configs.json").absoluteFilePath();
}

void MainWindow::loadConfigsFromFile()
{
    QFile loadFile("configs.json");
    if (!loadFile.open(QIODevice::ReadOnly)) {
        return; // Dosya yoksa sorun yok, ilk açılıştır
    }

    QByteArray saveData = loadFile.readAll();
    QJsonDocument loadDoc(QJsonDocument::fromJson(saveData));

    m_savedConfigs.clear();
    QJsonArray configArray = loadDoc.array();

    for (int i = 0; i < configArray.size(); ++i) {
        QJsonObject configObject = configArray[i].toObject();
        HexConfig conf;
        conf.read(configObject); // JSON'dan struct'a oku
        m_savedConfigs.append(conf);
    }
}
