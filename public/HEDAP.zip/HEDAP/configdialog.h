#ifndef CONFIGDIALOG_H
#define CONFIGDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QSpinBox>
#include <QLabel>
#include <QListWidget>
#include <QPushButton>
#include <QComboBox>

// JSON Kütüphaneleri (Verileri kaydetmek için)
#include <QJsonObject>
#include <QJsonDocument>

struct HexConfig {
    QString name;
    QString targetID;
    QString formula;
    int startByte;
    int endByte;

    // JSON'a Çevirme Fonksiyonları
    void read(const QJsonObject &json) {
        name = json["name"].toString();
        targetID = json["targetID"].toString();
        formula = json["formula"].toString();
        startByte = json["startByte"].toInt();
        endByte = json["endByte"].toInt();
    }

    void write(QJsonObject &json) const {
        json["name"] = name;
        json["targetID"] = targetID;
        json["formula"] = formula;
        json["startByte"] = startByte;
        json["endByte"] = endByte;
    }
};

class ConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ConfigDialog(QWidget *parent = nullptr);
    void setConfigList(const QVector<HexConfig>& configs);
    QVector<HexConfig> getConfigList() const;
    void setIDList(const QStringList &ids);

private slots:
    void updateVisualPreview();
    void onNewClicked();
    void onDeleteClicked();
    void onSaveClicked();
    void onItemClicked(QListWidgetItem *item);

private:
    QListWidget *m_listWidget;

    QLineEdit *m_nameEdit;
    QComboBox *m_idCombo;
    QLineEdit *m_formulaEdit;
    QSpinBox *m_startSpin;
    QSpinBox *m_endSpin;
    QLabel *m_previewLabel;

    QVector<HexConfig> m_configs;
    bool m_isEditMode; // Düzenleme modunda mıyız?

    void setupUI();
    void clearForm();
};

#endif // CONFIGDIALOG_H
