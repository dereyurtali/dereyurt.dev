#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtCharts>
#include <QChartView>
#include <QLineSeries>
#include <QDateTimeAxis>
#include <QValueAxis>
#include <QMainWindow>
#include <QVector>
#include <QStandardItemModel>
#include <QJSEngine>

// Config yapısını dahil ediyoruz
#include "configdialog.h"

// Veri Yapısı
struct RawData {
    qint64 timestamp;
    QString isoTime;
    QString id;
    QString dataHex;
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // --- Buton Slotları  ---
    void on_btn_load_clicked();
    void on_btn_unload_clicked();
    void on_btn_filter_clicked();
    void on_btn_reset_clicked();
    void on_btn_conf_clicked();
    void on_btn_export_clicked();
    void on_btn_exportdata_clicked();
    void on_btn_graph_clicked();

private:
    Ui::MainWindow *ui;

    // Veri Modelleri
    QVector<RawData> m_allData;
    QStandardItemModel *m_summaryModel; // Sol Tablo
    QStandardItemModel *m_resultModel;  // Sağ Tablo

    // Durum Değişkenleri
    QStringList m_activeFilters;        // Filtre Hafızası
    QVector<HexConfig> m_savedConfigs;  // Konfigürasyon Hafızası

    // --- Yardımcı Fonksiyonlar  ---
    void parseAndStoreLine(const QString &line);
    void populateSummaryTable(const QStringList &filterIds = QStringList());
    void setInterfaceState(bool hasData);

    // Hesaplama Fonksiyonları
    void calculateAndPopulateResultTable();
    double evaluateFormula(double rawValue, const QString &formula);

    // --- Konfigürasyon Dosya Yönetimi  ---
    void loadConfigsFromFile();
    void saveConfigsToFile();
};

#endif // MAINWINDOW_H
