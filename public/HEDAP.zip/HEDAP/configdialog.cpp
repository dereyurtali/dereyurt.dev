#include "configdialog.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGroupBox>
#include <QMessageBox>
#include <QDialogButtonBox>

ConfigDialog::ConfigDialog(QWidget *parent) : QDialog(parent)
{
    m_isEditMode = false; // Başlangıçta yeni kayıt modu
    setupUI();
    setWindowTitle("Configuration Manager");
    resize(750, 500);
}

void ConfigDialog::setupUI()
{
    QVBoxLayout *rootLayout = new QVBoxLayout(this);
    QHBoxLayout *panelsLayout = new QHBoxLayout();

    // --- SOL PANEL ---
    QVBoxLayout *leftLayout = new QVBoxLayout();
    QGroupBox *listGroup = new QGroupBox("Configurations Library", this);
    QVBoxLayout *listGroupLayout = new QVBoxLayout(listGroup);

    m_listWidget = new QListWidget(this);
    listGroupLayout->addWidget(m_listWidget);

    QHBoxLayout *listBtnLayout = new QHBoxLayout();
    QPushButton *btnNew = new QPushButton("New Config", this);
    QPushButton *btnDelete = new QPushButton("Delete", this);
    listBtnLayout->addWidget(btnNew);
    listBtnLayout->addWidget(btnDelete);
    listGroupLayout->addLayout(listBtnLayout);
    leftLayout->addWidget(listGroup);

    // --- SAĞ PANEL ---
    QVBoxLayout *rightLayout = new QVBoxLayout();
    QGroupBox *formGroup = new QGroupBox("Config Details", this);
    QVBoxLayout *formLayoutWrapper = new QVBoxLayout(formGroup);
    QFormLayout *formLayout = new QFormLayout();

    m_nameEdit = new QLineEdit(this);
    m_nameEdit->setPlaceholderText("Template Name (e.g. Voltage)");

    m_idCombo = new QComboBox(this);
    m_idCombo->setEditable(true);
    m_idCombo->setPlaceholderText("(Optional) Select ID to Map");
    // İpucu: Boş bırakırsa sadece şablon olur

    m_formulaEdit = new QLineEdit(this);
    m_formulaEdit->setPlaceholderText("x * 1.0");

    formLayout->addRow("Config Name:", m_nameEdit);
    formLayout->addRow("Map to ID:", m_idCombo);
    formLayout->addRow("Formula:", m_formulaEdit);
    formLayoutWrapper->addLayout(formLayout);

    QHBoxLayout *spinLayout = new QHBoxLayout();
    m_startSpin = new QSpinBox(this);
    m_startSpin->setRange(0, 7);
    m_startSpin->setPrefix("Start: ");

    m_endSpin = new QSpinBox(this);
    m_endSpin->setRange(0, 7);
    m_endSpin->setPrefix("End: ");
    m_endSpin->setValue(1);

    spinLayout->addWidget(m_startSpin);
    spinLayout->addWidget(m_endSpin);
    formLayoutWrapper->addLayout(spinLayout);

    m_previewLabel = new QLabel(this);
    m_previewLabel->setAlignment(Qt::AlignCenter);
    m_previewLabel->setStyleSheet("font-weight: bold; font-size: 14px; border: 1px solid #ccc; background: #fff; padding: 10px;");
    m_previewLabel->setFixedHeight(50);
    formLayoutWrapper->addWidget(m_previewLabel);

    QPushButton *btnSave = new QPushButton("Save Config", this);
    btnSave->setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 6px;");
    formLayoutWrapper->addWidget(btnSave);

    formLayoutWrapper->addStretch();
    rightLayout->addWidget(formGroup);

    panelsLayout->addLayout(leftLayout, 1);
    panelsLayout->addLayout(rightLayout, 2);
    rootLayout->addLayout(panelsLayout);

    QDialogButtonBox *mainButtonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(mainButtonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(mainButtonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
    rootLayout->addWidget(mainButtonBox);

    connect(btnNew, &QPushButton::clicked, this, &ConfigDialog::onNewClicked);
    connect(btnDelete, &QPushButton::clicked, this, &ConfigDialog::onDeleteClicked);
    connect(btnSave, &QPushButton::clicked, this, &ConfigDialog::onSaveClicked);
    connect(m_listWidget, &QListWidget::itemClicked, this, &ConfigDialog::onItemClicked);
    connect(m_startSpin, QOverload<int>::of(&QSpinBox::valueChanged), this, &ConfigDialog::updateVisualPreview);
    connect(m_endSpin, QOverload<int>::of(&QSpinBox::valueChanged), this, &ConfigDialog::updateVisualPreview);

    updateVisualPreview();
}

void ConfigDialog::setIDList(const QStringList &ids)
{
    m_idCombo->clear();
    m_idCombo->addItem(""); // Boş seçenek (ID'siz kayıt için)
    m_idCombo->addItems(ids);
}

void ConfigDialog::setConfigList(const QVector<HexConfig>& configs)
{
    m_configs = configs;
    m_listWidget->clear();
    for(const auto &conf : m_configs) {
        // Listede hem ismi hem de (varsa) ID'sini gösterelim
        QString label = conf.name;
        if (!conf.targetID.isEmpty()) {
            label += QString(" [ID: %1]").arg(conf.targetID);
        }
        m_listWidget->addItem(label);
    }
    clearForm();
}

QVector<HexConfig> ConfigDialog::getConfigList() const
{
    return m_configs;
}

void ConfigDialog::onNewClicked()
{
    // DÜZELTME: Seçimi tamamen kaldır ve Edit Modu kapat
    m_listWidget->clearSelection();
    m_listWidget->setCurrentItem(nullptr);
    m_isEditMode = false;
    clearForm();
    m_nameEdit->setFocus();
}

void ConfigDialog::onDeleteClicked()
{
    QListWidgetItem *current = m_listWidget->currentItem();
    if (!current) return;
    int row = m_listWidget->row(current);
    delete m_listWidget->takeItem(row);
    if(row < m_configs.size()) m_configs.removeAt(row);
    clearForm();
}

void ConfigDialog::onSaveClicked()
{
    QString name = m_nameEdit->text().trimmed();
    QString id = m_idCombo->currentText().trimmed();

    if (name.isEmpty()) {
        QMessageBox::warning(this, "Error", "Config Name cannot be empty!");
        return;
    }

    HexConfig conf;
    conf.name = name;
    conf.targetID = id;
    conf.formula = m_formulaEdit->text();
    conf.startByte = m_startSpin->value();
    conf.endByte = m_endSpin->value();

    // Liste Görünümü (İsim + ID)
    QString listLabel = name;
    if (!id.isEmpty()) listLabel += QString(" [ID: %1]").arg(id);

    if (m_isEditMode && m_listWidget->currentItem()) {
        // GÜNCELLEME
        int row = m_listWidget->row(m_listWidget->currentItem());
        m_configs[row] = conf;
        m_listWidget->currentItem()->setText(listLabel);
        QMessageBox::information(this, "Info", "Configuration Updated!");
    } else {
        // YENİ EKLEME
        m_configs.append(conf);
        m_listWidget->addItem(listLabel);
        m_listWidget->setCurrentRow(m_listWidget->count() - 1); // Yeni ekleneni seç

        // Kaydettikten sonra edit moduna geç ki tekrar basarsa güncelleme yapsın
        m_isEditMode = true;
    }
}

void ConfigDialog::onItemClicked(QListWidgetItem *item)
{
    int row = m_listWidget->row(item);
    if (row < 0 || row >= m_configs.size()) return;

    // Listeden bir şeye tıklandıysa Edit Modunu aç
    m_isEditMode = true;

    const HexConfig &conf = m_configs[row];
    m_nameEdit->setText(conf.name);
    m_idCombo->setCurrentText(conf.targetID);
    m_formulaEdit->setText(conf.formula);
    m_startSpin->setValue(conf.startByte);
    m_endSpin->setValue(conf.endByte);
    updateVisualPreview();
}

void ConfigDialog::clearForm()
{
    m_nameEdit->clear();
    m_idCombo->setCurrentIndex(0); // Boş seç
    m_formulaEdit->clear();
    m_startSpin->setValue(0);
    m_endSpin->setValue(1);
    updateVisualPreview();
}

void ConfigDialog::updateVisualPreview()
{
    int start = m_startSpin->value();
    int end = m_endSpin->value();
    if (start > end) { m_endSpin->setValue(start); end = start; }

    QString html = "<html><body>";
    QStringList dummyHex = {"00", "A1", "B2", "C3", "D4", "E5", "F6", "77"};
    for (int i = 0; i < 8; ++i) {
        if (i >= start && i <= end) html += QString("<span style='color:red; font-size:16px;'>[%1]</span> ").arg(dummyHex[i]);
        else html += QString("<span style='color:gray;'>%1</span> ").arg(dummyHex[i]);
    }
    html += "</body></html>";
    m_previewLabel->setText(html);
}
