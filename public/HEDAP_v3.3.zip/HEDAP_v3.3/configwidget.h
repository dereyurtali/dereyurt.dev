#ifndef CONFIGWIDGET_H
#define CONFIGWIDGET_H

#include <QComboBox>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QPushButton>
#include <QSpinBox>
#include <QWidget>

// ─────────────────────────────────────────────────────────────────────────────
//  HexConfig: A single parsing/formula configuration for one CAN/UART message
//  ID.
// ─────────────────────────────────────────────────────────────────────────────
struct HexConfig {
  QString name;      // Display name (e.g., "Voltage")
  QString targetID;  // CAN ID or UART identifier (e.g., "0x123")
  QString formula;   // JavaScript expression, 'x' = raw decimal value
  int startByte = 0; // First byte index in data field (0-based)
  int endByte = 1;   // Last byte index (inclusive)

  // ── DBC bit-level fields (only used when isDBC == true) ──────────────────
  // When isDBC is true the decoder uses proper CAN bit extraction instead of
  // the coarse byte-slice approach, giving correct values for sub-byte and
  // cross-byte signals.
  bool isDBC = false;       // true -> use DBC bit extraction
  int startBit = 0;         // LSB position (Intel) or MSB position (Motorola)
  int bitLength = 8;        // number of bits to extract
  bool littleEndian = true; // true = Intel (@1), false = Motorola (@0)
  bool isSigned = false;    // true = treat extracted value as two's-complement

  void read(const QJsonObject &json) {
    name = json["name"].toString();
    targetID = json["targetID"].toString();
    formula = json["formula"].toString();
    startByte = json["startByte"].toInt();
    endByte = json["endByte"].toInt();
    isDBC = json["isDBC"].toBool(false);
    startBit = json["startBit"].toInt(0);
    bitLength = json["bitLength"].toInt(8);
    littleEndian = json["littleEndian"].toBool(true);
    isSigned = json["isSigned"].toBool(false);
  }
  void write(QJsonObject &json) const {
    json["name"] = name;
    json["targetID"] = targetID;
    json["formula"] = formula;
    json["startByte"] = startByte;
    json["endByte"] = endByte;
    json["isDBC"] = isDBC;
    json["startBit"] = startBit;
    json["bitLength"] = bitLength;
    json["littleEndian"] = littleEndian;
    json["isSigned"] = isSigned;
  }
};

// ─────────────────────────────────────────────────────────────────────────────
//  ConfigWidget: Manage a list of HexConfig entries (add / edit / delete).
// ─────────────────────────────────────────────────────────────────────────────
class ConfigWidget : public QWidget {
  Q_OBJECT

public:
  explicit ConfigWidget(QWidget *parent = nullptr);

  void setConfigList(const QVector<HexConfig> &configs);
  QVector<HexConfig> getConfigList() const;
  void setIDList(const QStringList &ids);

signals:
  void configsUpdated(const QVector<HexConfig> &configs);
  void exportAsDbcClicked();

private slots:
  void updateVisualPreview();
  void onNewClicked();
  void onDeleteClicked();
  void onDeleteAllClicked();
  void onSaveClicked();
  void onItemClicked(QListWidgetItem *item);

private:
  QListWidget *m_listWidget;
  QLineEdit *m_nameEdit;
  QComboBox *m_idCombo;
  QLineEdit *m_formulaEdit;
  QSpinBox *m_startSpin;
  QSpinBox *m_endSpin;
  QLabel *m_previewLabel;
  QLabel *m_modeLabel;
  QPushButton *m_btnSave;

  QVector<HexConfig> m_configs;
  bool m_isEditMode;
  int m_lastClickedRow = -1;

  void setupUI();
  void clearForm();
};

#endif // CONFIGWIDGET_H
