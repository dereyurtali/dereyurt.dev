#ifndef DROPPABLECHARTVIEW_H
#define DROPPABLECHARTVIEW_H

#include <QChartView>
#include <QColor>
#include <QDateTimeAxis>
#include <QGestureEvent>
#include <QHash>
#include <QJsonObject>
#include <QLineSeries>
#include <QMouseEvent>
#include <QPoint>
#include <QString>
#include <QValueAxis>
#include <QtGlobal>

// ─────────────────────────────────────────────────────────────────────────────
//  ThresholdConfig — a horizontal reference line drawn on every chart that
//  tracks the named signal (or all signals when signalName is empty).
// ─────────────────────────────────────────────────────────────────────────────
struct ThresholdConfig {
  QString signalName;                      // empty = applies to all signals
  double  value   = 0.0;
  QColor  color   = QColor(255, 140, 0);  // orange default
  bool    enabled = true;
  void write(QJsonObject &obj) const;
  void read(const QJsonObject &obj);
};

// ─────────────────────────────────────────────────────────────────────────────
//  DroppableChartView
//  A QChartView that accepts drag-and-drop of signal names via the MIME type
//  "application/x-hedap-signal".  Displays a rolling 30-second time window.
//
//  Usage:
//    chart->addSignal("Voltage");          // manual add
//    chart->appendData("Voltage", ts, v);  // push a live data point
//    // or just drag a row from the decoded-signals table onto the widget
// ─────────────────────────────────────────────────────────────────────────────
class DroppableChartView : public QChartView {
  Q_OBJECT

public:
  explicit DroppableChartView(QWidget *parent = nullptr);

  // Add a signal series (no-op if already present)
  void addSignal(const QString &name);
  // Remove a signal series
  void removeSignal(const QString &name);
  // Remove all series
  void clearAll();
  // Append a live data point; adds the signal automatically if not present
  void appendData(const QString &name, qint64 timestampMs, double value);
  // Bulk-load historical data (does not turn off live mode)
  void bulkLoadHistory(const QString &name,
                       const QVector<QPair<qint64, double>> &pts);
  // Bulk-load static (CSV) data; bypasses live-mode trimming, sets full X range
  void loadStaticData(const QString &name,
                      const QVector<QPair<qint64, double>> &pts);
  // Appends a NaN value to create a visual break in the line
  void addGap(qint64 timestampMs);
  QStringList trackedSignals() const;
  // Resets zoom level to encapsulate all historic data
  void fitToScreen();
  // Hide hover overlay (call before grab/render for clean export)
  void clearHover();

  // Live mode: auto-scrolls X axis to show the last 30s.
  // When the user scrolls with the mouse wheel, live mode is paused so
  // they can inspect historical data. Call setLiveMode(true) to resume.
  void setLiveMode(bool live);
  bool isLiveMode() const { return m_liveMode; }
  // After an external setChart() call: disables live mode and initialises the
  // manual X range so clamping and pin-crosshair work immediately.
  void freezeForInspection(qint64 xMin, qint64 xMax);
  // Runtime-configurable display parameters (set from Settings dialog)
  void setWindowMs(int ms)      { m_windowMs = ms; }
  void setDecimalPlaces(int n)  { m_decimalPlaces = n; }
  // Chart tool setters (broadcast from applySettings)
  void setThresholds(const QVector<ThresholdConfig> &t) { m_thresholds = t; viewport()->update(); }
  void setDeltaModeEnabled(bool en);
  void setStatsOverlayEnabled(bool en) { m_statsOverlayEnabled = en; viewport()->update(); }
  void setFixedYAxis(bool en, double yMin = 0.0, double yMax = 100.0);
  void setRectZoomEnabled(bool en)     { m_rectZoomEnabled = en; }
  // Double click: resume live mode. Click (non-live): pin/unpin hover crosshair.
  void mouseDoubleClickEvent(QMouseEvent *event) override;

protected:
  void dragEnterEvent(QDragEnterEvent *event) override;
  void dragMoveEvent(QDragMoveEvent *event) override;
  void dropEvent(QDropEvent *event) override;
  void paintEvent(QPaintEvent *event) override;
  void wheelEvent(QWheelEvent *event) override;
  void mousePressEvent(QMouseEvent *event) override;
  void mouseMoveEvent(QMouseEvent *event) override;
  void mouseReleaseEvent(QMouseEvent *event) override;
  bool event(QEvent *event) override;

private:
  void refreshAxes();
  void updateChartTitle();
  void zoomAroundCenter(double factor);
  bool gestureEvent(QGestureEvent *event);
  // Clamp m_manualXMin/Max so data never scrolls fully off-screen
  void clampPanRange();

  // Returns the QDateTimeAxis on the current chart (m_axisX if owned,
  // otherwise the first QDateTimeAxis found on chart()->axes()).
  QDateTimeAxis *effectiveXAxis() const;
  QValueAxis *effectiveYAxis() const;
  // All QLineSeries on this chart: m_series values, or chart()->series() for
  // Graph page.
  QList<QLineSeries *> allLineSeries() const;

  QHash<QString, QList<QLineSeries *>> m_seriesSegments;
  QHash<QString, QList<QLineSeries *>> m_gapSegments; // one series per gap event
  QHash<QString, bool> m_expectingGapEnd;
  QHash<QString, bool> m_hasLastValid;
  QHash<QString, QPointF> m_lastValidPoint;
  QDateTimeAxis *m_axisX = nullptr;
  QValueAxis *m_axisY = nullptr;
  int m_nextColorIdx = 0;

  bool m_liveMode = true;      // false = user is panning/inspecting history
  bool m_isStaticChart = false; // true = loaded via loadStaticData; disables live-mode gestures
  bool m_isDragging = false;    // true while left-button drag is in progress
  bool m_inDoubleClick = false; // suppresses release-pause on double-click
  QPoint m_dragStartPos;        // position when mouse was first pressed
  QPoint m_dragLastPos;         // previous mouse position during drag
  bool m_dragMoved = false;     // true once mouse moved beyond threshold

  // Manual zoom range (used when not in live mode)
  qint64 m_manualXMin = 0;
  qint64 m_manualXMax = 0;

  // Hover crosshair state
  struct HoverPoint {
    QPointF chartPos; // (x_ms, y_value) in chart coordinates
    QColor  color;
    QString signalName; // used for delta ΔY matching
  };
  QVector<HoverPoint> m_hoverPoints;
  bool m_hoverVisible = false;
  qreal m_hoverX = 0.0;   // pixel X of crosshair within viewport
  QString m_hoverTip;     // cached tooltip text for current hover position

  // Pinned crosshair (click-to-freeze, only active when !m_liveMode)
  bool             m_pinned       = false;
  qreal            m_pinnedX      = 0.0;
  QVector<HoverPoint> m_pinnedPoints;
  QString          m_pinnedTip;

  // Display window shown in live mode (runtime-configurable via setWindowMs)
  int m_windowMs = 30'000;
  // Decimal places for signal values in hover tooltip (via setDecimalPlaces)
  int m_decimalPlaces = 3;

  // Feature 1: Threshold lines
  QVector<ThresholdConfig> m_thresholds;

  // Feature 2: Delta cursor
  bool m_deltaModeEnabled = false;
  enum class DeltaState { None, ASet, BSet } m_deltaState = DeltaState::None;
  // Cursor A reuses m_pinned / m_pinnedX / m_pinnedPoints / m_pinnedTip
  bool             m_deltaB      = false;
  qreal            m_deltaBX     = 0.0;
  QVector<HoverPoint> m_deltaBPoints;
  QString          m_deltaBTip;

  // Feature 3: Statistics overlay
  bool m_statsOverlayEnabled = false;
  struct StatEntry { double min, max, mean; };
  QHash<QString, StatEntry> m_statsCache; // rebuilt in refreshAxes()

  // Feature 4: Fixed Y-axis
  bool   m_fixedYAxis = false;
  double m_fixedYMin  = 0.0;
  double m_fixedYMax  = 100.0;

  // Feature 5: Rectangle zoom
  bool   m_rectZoomEnabled  = false;
  bool   m_rectZooming      = false;
  QPoint m_rectZoomOrigin;
  QPoint m_rectZoomCurrent;

  // How much history to retain in memory (5 minutes)
  static constexpr int STORE_MS = 300'000;
  // Max points per series to keep rendering fast
  static constexpr int MAX_PTS = 10'000;
  // Minimum mouse movement (px) before a press becomes a drag
  static constexpr int DRAG_THRESHOLD = 5;

  static const QColor kColors[10];
};

#endif // DROPPABLECHARTVIEW_H
