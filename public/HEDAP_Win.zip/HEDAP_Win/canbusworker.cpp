#include "canbusworker.h"
#include <QDateTime>
#include <QDebug>

CanBusWorker::CanBusWorker(QObject *parent)
    : QObject(parent), m_statsTimer(new QTimer(this)) {
  m_statsTimer->setInterval(1000);
  connect(m_statsTimer, &QTimer::timeout, this, &CanBusWorker::onStatsTimer);
}

CanBusWorker::~CanBusWorker() { disconnectDevice(); }

// ─────────────────────────────────────────────────────────────────────────────
//  Static helpers
// ─────────────────────────────────────────────────────────────────────────────

bool CanBusWorker::isAvailable() {
#if HEDAP_HAS_CANBUS
  return true;
#else
  return false;
#endif
}

QStringList CanBusWorker::availablePlugins() {
#if HEDAP_HAS_CANBUS
  return QCanBus::instance()->plugins();
#else
  return {};
#endif
}

QStringList CanBusWorker::availableInterfaces(const QString &plugin) {
#if HEDAP_HAS_CANBUS
  QString errorString;
  QStringList result;
  const auto devices =
      QCanBus::instance()->availableDevices(plugin, &errorString);
  for (const QCanBusDeviceInfo &info : devices)
    result << info.name();
  if (result.isEmpty() && !errorString.isEmpty())
    qWarning() << "[CanBusWorker] availableDevices error:" << errorString;
  return result;
#else
  Q_UNUSED(plugin)
  return {};
#endif
}

// ─────────────────────────────────────────────────────────────────────────────
//  Connection management
// ─────────────────────────────────────────────────────────────────────────────

bool CanBusWorker::isConnected() const {
#if HEDAP_HAS_CANBUS
  return m_device && m_device->state() == QCanBusDevice::ConnectedState;
#else
  return false;
#endif
}

void CanBusWorker::connectDevice(const QString &plugin,
                                 const QString &interface, int bitrate) {
#if HEDAP_HAS_CANBUS
  disconnectDevice();

  // Guard against Qt PCAN plugin crash: verify the interface actually exists
  // before calling createDevice(). Passing a non-existent interface can return
  // a corrupt device object whose connectDevice() causes a SIGSEGV inside Qt.
  {
    QString discoverError;
    const auto devices = QCanBus::instance()->availableDevices(plugin, &discoverError);
    bool found = false;
    for (const QCanBusDeviceInfo &info : devices) {
      if (info.name() == interface) { found = true; break; }
    }
    if (!found) {
      emit errorOccurred(tr("CAN interface '%1' not found on plugin '%2'. "
                            "Connect the device and refresh.").arg(interface, plugin));
      return;
    }
  }

  QString errorString;
  m_device = QCanBus::instance()->createDevice(plugin, interface, &errorString);
  if (!m_device) {
    emit errorOccurred(tr("Cannot create CAN device: %1").arg(errorString));
    return;
  }

  // Configure bitrate
  m_device->setConfigurationParameter(QCanBusDevice::BitRateKey, bitrate);

  connect(m_device, &QCanBusDevice::framesReceived, this,
          &CanBusWorker::onFramesReceived);
  connect(m_device, &QCanBusDevice::errorOccurred, this,
          &CanBusWorker::onDeviceError);

  if (!m_device->connectDevice()) {
    emit errorOccurred(tr("Cannot connect to %1/%2: %3")
                           .arg(plugin, interface, m_device->errorString()));
    delete m_device;
    m_device = nullptr;
    return;
  }

  m_frameCounter = 0;
  m_statsTimer->start();
  emit connectionChanged(true);
  qDebug() << "[CanBusWorker] Connected to" << plugin << "/" << interface << "@"
           << bitrate << "bps";
#else
  Q_UNUSED(plugin)
  Q_UNUSED(interface)
  Q_UNUSED(bitrate)
  emit errorOccurred(tr("CAN bus support is not available. "
                        "Install Qt6 SerialBus module and rebuild."));
#endif
}

void CanBusWorker::disconnectDevice() {
#if HEDAP_HAS_CANBUS
  if (m_disconnecting)
    return;
  m_disconnecting = true;

  m_statsTimer->stop();
  if (m_device) {
    m_device->disconnectDevice();
    delete m_device;
    m_device = nullptr;
    emit connectionChanged(false);
    qDebug() << "[CanBusWorker] Disconnected.";
  }

  m_disconnecting = false;
#endif
}

// ─────────────────────────────────────────────────────────────────────────────
//  Frame reception
// ─────────────────────────────────────────────────────────────────────────────

void CanBusWorker::onFramesReceived() {
#if HEDAP_HAS_CANBUS
  if (!m_device)
    return;

  while (m_device->framesAvailable()) {
    const QCanBusFrame frame = m_device->readFrame();
    if (frame.frameType() != QCanBusFrame::DataFrame)
      continue;

    // Format CAN ID as hex (pad to 3 or 8 chars)
    quint32 rawId = frame.frameId();
    bool ext = frame.hasExtendedFrameFormat();
    QString idStr = QString::number(rawId, 16).toUpper();
    if (ext)
      idStr = idStr.rightJustified(8, '0');
    else
      idStr = idStr.rightJustified(3, '0');

    // Format data bytes as "XX XX XX ..."
    QByteArray data = frame.payload();
    QString prettyHex;
    for (int i = 0; i < data.size(); ++i) {
      if (i > 0)
        prettyHex += ' ';
      prettyHex += QString::number((unsigned char)data[i], 16)
                       .toUpper()
                       .rightJustified(2, '0');
    }

    QString csvLine = frameToCsv(idStr, prettyHex);
    m_frameCounter++;
    emit lineReceived(csvLine);
  }
#endif
}

void CanBusWorker::onDeviceError() {
#if HEDAP_HAS_CANBUS
  if (m_device) {
    emit errorOccurred(m_device->errorString());

    QCanBusDevice::CanBusError err = m_device->error();
    if (m_device->state() == QCanBusDevice::UnconnectedState ||
        err == QCanBusDevice::ReadError || err == QCanBusDevice::WriteError ||
        err == QCanBusDevice::ConnectionError) {
      disconnectDevice();
    }
  }
#endif
}

void CanBusWorker::onStatsTimer() {
  emit statsUpdated(m_frameCounter);
  m_frameCounter = 0;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Convert to HEDAP CSV format (same as SerialWorker::slcanToCSV)
//  Format: "isoTime,epoch,,,0xID,,,  dataHex"
// ─────────────────────────────────────────────────────────────────────────────
QString CanBusWorker::frameToCsv(const QString &id, const QString &dataHex) {
  QDateTime now = QDateTime::currentDateTime();
  QString isoTime = now.toString("yyyy-MM-dd HH:mm:ss.zzz");
  QString epoch = QString::number(now.toMSecsSinceEpoch());
  return QString("%1,%2,,,0x%3,,,  %4").arg(isoTime, epoch, id, dataHex);
}
