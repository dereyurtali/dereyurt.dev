#include "droppablechartview.h"

#include <QAbstractAxis>
#include <QAbstractSeries>
#include <QChart>
#include <QDateTime>
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>
#include <QJsonObject>
#include <QLegendMarker>
#include <QMimeData>
#include <QMouseEvent>
#include <QPainter>
#include <QToolTip>
#include <QWheelEvent>

// Same 10-color palette as mainwindow.cpp
const QColor DroppableChartView::kColors[10] = {
    QColor("#0078D4"), QColor("#E81123"), QColor("#107C10"), QColor("#FF8C00"),
    QColor("#5C2D91"), QColor("#008272"), QColor("#D13438"), QColor("#0063B1"),
    QColor("#767676"), QColor("#C239B3"),
};

// ─────────────────────────────────────────────────────────────────────────────
DroppableChartView::DroppableChartView(QWidget *parent)
    : QChartView(new QChart(), parent) {
  setAcceptDrops(true);
  setRenderHint(QPainter::Antialiasing);

  // Enable pinch gesture for touchpad zoom
  grabGesture(Qt::PinchGesture);

  QChart *ch = chart();
  ch->setTitle("");
  ch->legend()->setVisible(true);
  ch->legend()->setAlignment(Qt::AlignBottom);
  ch->setAnimationOptions(QChart::NoAnimation);
  ch->setMargins(QMargins(4, 4, 4, 4));

  // X axis: datetime
  m_axisX = new QDateTimeAxis(ch);
  m_axisX->setFormat("HH:mm:ss");
  m_axisX->setTitleText("Time");
  qint64 now = QDateTime::currentMSecsSinceEpoch();
  m_axisX->setRange(QDateTime::fromMSecsSinceEpoch(now - m_windowMs),
                    QDateTime::fromMSecsSinceEpoch(now));
  ch->addAxis(m_axisX, Qt::AlignBottom);

  // Y axis: value
  m_axisY = new QValueAxis(ch);
  m_axisY->setTitleText("Value");
  m_axisY->setRange(0.0, 1.0);
  ch->addAxis(m_axisY, Qt::AlignLeft);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ThresholdConfig persistence
// ─────────────────────────────────────────────────────────────────────────────
void ThresholdConfig::write(QJsonObject &obj) const {
  obj["signalName"] = signalName;
  obj["value"]      = value;
  obj["color"]      = color.name();
  obj["enabled"]    = enabled;
}

void ThresholdConfig::read(const QJsonObject &obj) {
  signalName = obj["signalName"].toString();
  value      = obj["value"].toDouble(0.0);
  color      = QColor(obj["color"].toString("#FF8C00"));
  enabled    = obj["enabled"].toBool(true);
}

// ─────────────────────────────────────────────────────────────────────────────
//  New chart tool setters
// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::setDeltaModeEnabled(bool en) {
  m_deltaModeEnabled = en;
  if (!en) {
    m_pinned = false; m_pinnedPoints.clear(); m_pinnedTip.clear();
    m_deltaB = false; m_deltaBPoints.clear(); m_deltaBTip.clear();
    m_deltaState = DeltaState::None;
  }
  viewport()->update();
}

void DroppableChartView::setFixedYAxis(bool en, double yMin, double yMax) {
  m_fixedYAxis = en; m_fixedYMin = yMin; m_fixedYMax = yMax;
  refreshAxes();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::addSignal(const QString &name) {
  if (m_seriesSegments.contains(name))
    return;

  QColor color = kColors[m_nextColorIdx % 10];
  ++m_nextColorIdx;

  m_seriesSegments.insert(name, QList<QLineSeries *>());
  
  // Create initial segment
  QLineSeries *series = new QLineSeries(chart());
  series->setName(name);
  series->setColor(color);
  series->setUseOpenGL(false);
  chart()->addSeries(series);
  series->attachAxis(m_axisX);
  series->attachAxis(m_axisY);
  m_seriesSegments[name].append(series);

  // Gap series are created on-demand when a reconnect occurs (one per gap event).
  m_gapSegments.insert(name, {});
  m_expectingGapEnd.insert(name, false);
  m_hasLastValid.insert(name, false);

  updateChartTitle();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::removeSignal(const QString &name) {
  if (m_seriesSegments.contains(name)) {
    for (QLineSeries *series : m_seriesSegments.take(name)) {
      chart()->removeSeries(series);
      delete series;
    }
  }

  for (QLineSeries *g : m_gapSegments.take(name)) {
    chart()->removeSeries(g);
    delete g;
  }

  m_expectingGapEnd.remove(name);
  m_hasLastValid.remove(name);
  m_lastValidPoint.remove(name);
  updateChartTitle();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::clearAll() {
  for (const QList<QLineSeries *> &list : m_seriesSegments) {
    for (QLineSeries *s : list) {
      chart()->removeSeries(s);
      delete s;
    }
  }
  m_seriesSegments.clear();

  for (const QList<QLineSeries *> &gaps : m_gapSegments) {
    for (QLineSeries *g : gaps) {
      chart()->removeSeries(g);
      delete g;
    }
  }
  m_gapSegments.clear();

  m_expectingGapEnd.clear();
  m_hasLastValid.clear();
  m_lastValidPoint.clear();

  m_nextColorIdx = 0;
  updateChartTitle();
  refreshAxes();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::appendData(const QString &name, qint64 timestampMs,
                                    double value) {
  if (!m_seriesSegments.contains(name))
    addSignal(name);

  if (std::isnan(value)) {
    if (!m_expectingGapEnd[name]) {
      m_expectingGapEnd[name] = true;
    }
    return; // Don't append NaN to any series in segment approach
  }

  QList<QLineSeries *> &segments = m_seriesSegments[name];

  if (m_expectingGapEnd[name]) {
    if (m_hasLastValid[name]) {
      // Create a dedicated series for this specific gap (two points only, no NaN).
      // Using a fresh series per gap avoids the Qt Charts bug where NaN mid-series
      // fails to break a dashed QLineSeries when more points are appended later.
      QLineSeries *gap = new QLineSeries(chart());
      gap->setName(name + "_gap");
      QPen gapPen(Qt::red);
      gapPen.setWidth(2);
      gapPen.setStyle(Qt::DashLine);
      gap->setPen(gapPen);
      gap->setUseOpenGL(false);
      gap->append(m_lastValidPoint[name]);
      gap->append(timestampMs, value);
      chart()->addSeries(gap);
      gap->attachAxis(m_axisX);
      gap->attachAxis(m_axisY);
      for (QLegendMarker *marker : chart()->legend()->markers(gap))
        marker->setVisible(false);
      m_gapSegments[name].append(gap);
    }
    
    // Create NEW segment to break the blue line
    QLineSeries *newSeries = new QLineSeries(chart());
    newSeries->setName(name);
    // Use same color as first segment
    if (!segments.isEmpty()) newSeries->setColor(segments.first()->color());
    newSeries->setUseOpenGL(false);
    chart()->addSeries(newSeries);
    newSeries->attachAxis(m_axisX);
    newSeries->attachAxis(m_axisY);
    
    // Hide from legend if it's not the first segment
    for (QLegendMarker *marker : chart()->legend()->markers(newSeries)) {
        marker->setVisible(false);
    }
    
    segments.append(newSeries);
    m_expectingGapEnd[name] = false;
  }

  QLineSeries *series = segments.last();
  m_hasLastValid[name] = true;
  m_lastValidPoint[name] = QPointF(timestampMs, value);
  series->append(timestampMs, value);

  // Trim old segments: remove those where ALL points are older than STORE_MS
  while (segments.size() > 1) {
    QLineSeries *first = segments.first();
    if (!first->points().isEmpty() && first->points().last().x() < (double)(timestampMs - STORE_MS)) {
      chart()->removeSeries(first);
      delete first;
      segments.removeFirst();
    } else {
      break;
    }
  }
  
  // Trim points within the oldest remaining segment if needed
  QLineSeries *active = segments.first();
  while (active->count() > 1 &&
         active->at(0).x() < (double)(timestampMs - STORE_MS)) {
    active->remove(0);
  }
  // Trim gap segments that have fully scrolled out of the history window.
  // Each gap series has exactly two points; remove entire series once both
  // endpoints are older than STORE_MS.
  QList<QLineSeries *> &gapList = m_gapSegments[name];
  while (gapList.size() > 0) {
    QLineSeries *oldest = gapList.first();
    if (!oldest->points().isEmpty() &&
        oldest->points().last().x() < (double)(timestampMs - STORE_MS)) {
      chart()->removeSeries(oldest);
      delete oldest;
      gapList.removeFirst();
    } else {
      break;
    }
  }

  // Hard cap to avoid unbounded growth
  while (series->count() > MAX_PTS)
    series->remove(0);

  refreshAxes();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::bulkLoadHistory(
    const QString &name, const QVector<QPair<qint64, double>> &pts) {
  if (pts.isEmpty())
    return;
  if (!m_seriesSegments.contains(name))
    addSignal(name);

  for (const auto &pair : pts) {
    appendData(name, pair.first, pair.second);
  }
}

void DroppableChartView::loadStaticData(
    const QString &name, const QVector<QPair<qint64, double>> &pts) {
  if (pts.isEmpty())
    return;
  
  clearAll();
  if (!m_seriesSegments.contains(name))
    addSignal(name);

  // We loop and append so the segmenting logic works naturally
  for (const auto &pair : pts) {
    appendData(name, pair.first, pair.second);
  }

  m_liveMode = false;
  m_isStaticChart = true;
  m_manualXMin = pts.first().first;
  m_manualXMax = pts.last().first;
  refreshAxes();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::addGap(qint64 timestampMs) {
  for (const QString &n : m_seriesSegments.keys()) {
    appendData(n, timestampMs, qQNaN());
  }
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::fitToScreen() {
  m_liveMode = false;
  // Clear delta cursors and hover so they don't reference stale positions
  m_pinned = false; m_pinnedPoints.clear();
  m_deltaB = false; m_deltaBPoints.clear();
  m_deltaState = DeltaState::None;
  m_hoverVisible = false;

  if (m_seriesSegments.isEmpty())
    return;

  double absoluteMin = std::numeric_limits<double>::max();
  double absoluteMax = std::numeric_limits<double>::lowest();

  bool hasData = false;
  for (const QList<QLineSeries *> &segments : m_seriesSegments.values()) {
    for (QLineSeries *s : segments) {
      if (!s->points().isEmpty()) {
        hasData = true;
        absoluteMin = std::min(absoluteMin, s->points().first().x());
        absoluteMax = std::max(absoluteMax, s->points().last().x());
      }
    }
  }

  if (hasData) {
    m_manualXMin = absoluteMin;
    m_manualXMax = absoluteMax;
    refreshAxes();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
QStringList DroppableChartView::trackedSignals() const {
  return m_seriesSegments.keys();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::clearHover() {
  m_hoverVisible = false;
  m_hoverPoints.clear();
  m_pinned = false;
  m_pinnedPoints.clear();
  m_deltaB = false; m_deltaBPoints.clear();
  m_deltaState = DeltaState::None;
  m_rectZooming = false;
  viewport()->update();
}

// ─────────────────────────────────────────────────────────────────────────────
//  Return the QDateTimeAxis on the *current* chart.
//  m_axisX is owned by the initial chart created in the constructor.
//  After setChart() is called externally (Graph page re-plot), m_axisX is no
//  longer on the current chart, so fall back to searching chart()->axes().
// ─────────────────────────────────────────────────────────────────────────────
QDateTimeAxis *DroppableChartView::effectiveXAxis() const {
  if (m_axisX && chart()->axes(Qt::Horizontal).contains(m_axisX))
    return m_axisX;
  for (QAbstractAxis *ax : chart()->axes(Qt::Horizontal)) {
    if (auto *dtAx = qobject_cast<QDateTimeAxis *>(ax))
      return dtAx;
  }
  return nullptr;
}

QValueAxis *DroppableChartView::effectiveYAxis() const {
  if (m_axisY && chart()->axes(Qt::Vertical).contains(m_axisY))
    return m_axisY;
  for (QAbstractAxis *ax : chart()->axes(Qt::Vertical)) {
    if (auto *va = qobject_cast<QValueAxis *>(ax))
      return va;
  }
  return nullptr;
}

QList<QLineSeries *> DroppableChartView::allLineSeries() const {
  if (!m_seriesSegments.isEmpty()) {
    QList<QLineSeries *> result;
    for (const QList<QLineSeries *> &list : m_seriesSegments.values()) {
      result.append(list);
    }
    return result;
  }
  QList<QLineSeries *> result;
  for (QAbstractSeries *abs : chart()->series())
    if (auto *ls = qobject_cast<QLineSeries *>(abs))
      result.append(ls);
  return result;
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::refreshAxes() {
  QDateTimeAxis *effX = effectiveXAxis();
  QValueAxis *effY = effectiveYAxis();
  if (!effX || !effY)
    return;

  if (m_liveMode && effX == m_axisX) {
    // Live mode: advance the rolling window only for our owned axis
    qint64 now = QDateTime::currentMSecsSinceEpoch();
    effX->setRange(QDateTime::fromMSecsSinceEpoch(now - m_windowMs),
                   QDateTime::fromMSecsSinceEpoch(now));
  } else if (m_manualXMin != 0 && m_manualXMax != 0) {
    // Respect the manually set zoom/pan range
    effX->setRange(QDateTime::fromMSecsSinceEpoch(m_manualXMin),
                   QDateTime::fromMSecsSinceEpoch(m_manualXMax));
  }

  const QList<QLineSeries *> series = allLineSeries();
  if (series.isEmpty()) {
    effY->setRange(0.0, 1.0);
    return;
  }

  // Compute Y range from visible data only
  qint64 visMin = effX->min().toMSecsSinceEpoch();
  qint64 visMax = effX->max().toMSecsSinceEpoch();

  double yMin = std::numeric_limits<double>::max();
  double yMax = std::numeric_limits<double>::lowest();
  for (const QLineSeries *s : series) {
    if (s->name().endsWith("_gap")) continue; // Don't scale Y based on gap lines
    for (const QPointF &pt : s->points()) {
      qint64 t = (qint64)pt.x();
      if (t < visMin || t > visMax)
        continue;
      if (std::isnan(pt.y()))
        continue;
      if (pt.y() < yMin)
        yMin = pt.y();
      if (pt.y() > yMax)
        yMax = pt.y();
    }
  }
  // Feature 3: rebuild statistics cache for visible window
  if (m_statsOverlayEnabled) {
    m_statsCache.clear();
    QHash<QString, QList<QLineSeries *>> sigMap;
    if (!m_seriesSegments.isEmpty()) {
      sigMap = m_seriesSegments;
    } else {
      for (QLineSeries *s : allLineSeries())
        if (!s->name().isEmpty() && !s->name().endsWith("_gap"))
          sigMap[s->name()] << s;
    }
    for (const QString &sig : sigMap.keys()) {
      double sMin = std::numeric_limits<double>::max();
      double sMax = std::numeric_limits<double>::lowest();
      double sum = 0.0; int cnt = 0;
      for (QLineSeries *s : sigMap[sig]) {
        for (const QPointF &pt : s->points()) {
          qint64 t = (qint64)pt.x();
          if (t < visMin || t > visMax || std::isnan(pt.y())) continue;
          sMin = std::min(sMin, pt.y()); sMax = std::max(sMax, pt.y());
          sum += pt.y(); ++cnt;
        }
      }
      if (cnt > 0) m_statsCache[sig] = { sMin, sMax, sum / cnt };
    }
  }

  // Feature 4: fixed Y-axis overrides auto-scale
  if (m_fixedYAxis) {
    effY->setRange(m_fixedYMin, m_fixedYMax);
  } else {
    if (yMin > yMax) { yMin = 0.0; yMax = 1.0; }
    double pad = (yMax - yMin) * 0.08 + 0.001;
    effY->setRange(yMin - pad, yMax + pad);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::updateChartTitle() {
  chart()->setTitle(""); // placeholder is drawn by paintEvent only
  viewport()->update();  // force immediate repaint to clear/show placeholder
}

// ─────────────────────────────────────────────────────────────────────────────
//  Clamp m_manualXMin/Max so panning can't push all data off-screen.
//  Guarantees the data X range always overlaps the visible window by at least
//  one sample — i.e. the chart can never be panned into blank space.
// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::clampPanRange() {
  double dMin = std::numeric_limits<double>::max();
  double dMax = std::numeric_limits<double>::lowest();
  // allLineSeries() covers both m_seriesSegments (live/CSV charts) and
  // chart()->series() (Graph page, where m_seriesSegments is empty).
  for (const QLineSeries *s : allLineSeries()) {
    if (s->name().endsWith("_gap"))
      continue;
    const auto &pts = s->points();
    if (!pts.isEmpty()) {
      dMin = std::min(dMin, pts.first().x());
      dMax = std::max(dMax, pts.last().x());
    }
  }
  if (dMin > dMax)
    return; // no data — nothing to clamp

  const qint64 dataMin = (qint64)dMin;
  const qint64 dataMax = (qint64)dMax;
  const qint64 viewWidth = m_manualXMax - m_manualXMin;
  if (viewWidth <= 0)
    return;

  // Panned so far forward (left) that all data is to the right of the view
  if (m_manualXMax < dataMin) {
    m_manualXMax = dataMin;
    m_manualXMin = dataMin - viewWidth;
  }
  // Panned so far backward (right) that all data is to the left of the view
  if (m_manualXMin > dataMax) {
    m_manualXMin = dataMax;
    m_manualXMax = dataMax + viewWidth;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::setLiveMode(bool live) {
  m_liveMode = live;
  if (live) {
    m_manualXMin = 0;
    m_manualXMax = 0;
    m_pinned = false; m_pinnedPoints.clear();
    m_deltaB = false; m_deltaBPoints.clear();
    m_deltaState = DeltaState::None;
    refreshAxes(); // snap X axis back to the live window immediately
  }
}

void DroppableChartView::freezeForInspection(qint64 xMin, qint64 xMax) {
  m_liveMode     = false;
  m_manualXMin   = xMin;
  m_manualXMax   = xMax;
  m_pinned       = false;
  m_hoverVisible = false;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Shared zoom helper: scale X axis by `factor` centered on the current view.
// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::zoomAroundCenter(double factor) {
  QDateTimeAxis *effX = effectiveXAxis();
  if (!effX)
    return;

  qint64 xMin = effX->min().toMSecsSinceEpoch();
  qint64 xMax = effX->max().toMSecsSinceEpoch();
  qint64 range = xMax - xMin;
  qint64 newRange = qMax((qint64)(range * factor), (qint64)1000);
  qint64 center = (xMin + xMax) / 2;

  m_manualXMin = center - newRange / 2;
  m_manualXMax = center + newRange / 2;

  effX->setRange(QDateTime::fromMSecsSinceEpoch(m_manualXMin),
                 QDateTime::fromMSecsSinceEpoch(m_manualXMax));
  refreshAxes();
}

// ─────────────────────────────────────────────────────────────────────────────
//  Scroll wheel / trackpad two-finger scroll:
//    Plain scroll  = PAN left/right through time
//    Ctrl+scroll   = ZOOM in/out (smooth, proportional to delta)
// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::wheelEvent(QWheelEvent *event) {
  QDateTimeAxis *effX = effectiveXAxis();
  if (!effX) {
    event->ignore();
    return;
  }

  m_liveMode = false;

  if (event->modifiers() & Qt::ControlModifier) {
    // Ctrl+scroll → ZOOM (smooth proportional factor)
    int delta = event->angleDelta().y();
    if (delta == 0) {
      event->accept();
      return;
    }
    // Smooth: scale proportionally to scroll amount
    double factor = 1.0 - (delta / 600.0); // ~0.8 for +120, ~1.2 for -120
    factor = qBound(0.5, factor, 2.0);
    zoomAroundCenter(factor);
  } else {
    // Plain scroll → PAN left/right
    // Use pixelDelta for trackpad (smooth), angleDelta for mouse wheel
    int dx;
    if (!event->pixelDelta().isNull())
      dx = event->pixelDelta().x(); // trackpad: smooth pixel pan
    else
      dx = event->angleDelta().y(); // mouse wheel: use y as horizontal scroll

    if (dx == 0) {
      event->accept();
      return;
    }

    qint64 xMin = effX->min().toMSecsSinceEpoch();
    qint64 xMax = effX->max().toMSecsSinceEpoch();
    double msPerPixel = (double)(xMax - xMin) / chart()->plotArea().width();
    qint64 deltaMs = (qint64)(dx * msPerPixel * 2.0);

    m_manualXMin = xMin - deltaMs;
    m_manualXMax = xMax - deltaMs;
    clampPanRange();

    effX->setRange(QDateTime::fromMSecsSinceEpoch(m_manualXMin),
                   QDateTime::fromMSecsSinceEpoch(m_manualXMax));
    refreshAxes();
  }
  event->accept();
}

// ─────────────────────────────────────────────────────────────────────────────
//  Pinch gesture: zoom the chart with two-finger pinch on touchpad
// ─────────────────────────────────────────────────────────────────────────────
bool DroppableChartView::event(QEvent *event) {
  if (event->type() == QEvent::Gesture)
    return gestureEvent(static_cast<QGestureEvent *>(event));
  if (event->type() == QEvent::Leave && m_hoverVisible) {
    m_hoverVisible = false;
    QToolTip::hideText();
    viewport()->update();
  }
  return QChartView::event(event);
}

bool DroppableChartView::gestureEvent(QGestureEvent *event) {
  if (QPinchGesture *pinch =
          static_cast<QPinchGesture *>(event->gesture(Qt::PinchGesture))) {
    if (!effectiveXAxis())
      return true;

    m_liveMode = false;

    qreal scaleFactor = pinch->scaleFactor();
    if (scaleFactor > 0.01) {
      // pinch in = scaleFactor<1 = zoom out, pinch out = scaleFactor>1 = zoom
      // in
      double factor = 1.0 / scaleFactor;
      factor = qBound(0.5, factor, 2.0);
      zoomAroundCenter(factor);
    }
    return true;
  }
  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Single click (live mode): pause — chart stops following new data.
//  Single click (paused):    pin/move a red marker at the hovered data point.
//  Single click on pin:      unpin.
//  Double click:             resume live mode; pin stays until it scrolls away.
//  Click-and-drag:           pan the chart left/right (after DRAG_THRESHOLD px).
// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::mousePressEvent(QMouseEvent *event) {
  if (event->button() == Qt::LeftButton && effectiveXAxis()) {
    m_dragStartPos    = event->pos();
    m_dragLastPos     = event->pos();
    m_dragMoved       = false;
    m_isDragging      = false;
    m_rectZoomOrigin  = event->pos();
    m_rectZoomCurrent = event->pos();
    m_rectZooming     = false;
    event->accept();
    return;
  }
  QChartView::mousePressEvent(event);
}

void DroppableChartView::mouseMoveEvent(QMouseEvent *event) {
  QDateTimeAxis *effX = effectiveXAxis(); // computed once, used in both blocks
  if (event->buttons() & Qt::LeftButton && effX) {
    QPoint diff = event->pos() - m_dragStartPos;
    if (!m_dragMoved && diff.manhattanLength() >= DRAG_THRESHOLD) {
      m_dragMoved = true;
      m_liveMode  = false;
      // Rect-zoom mode: drag zooms; Ctrl+drag pans
      const bool wantPan = m_rectZoomEnabled
                               ? (event->modifiers() & Qt::ControlModifier)
                               : true;
      if (wantPan) {
        m_isDragging  = true; m_rectZooming = false;
        setCursor(Qt::ClosedHandCursor);
      } else {
        m_rectZooming = true; m_isDragging  = false;
        setCursor(Qt::CrossCursor);
      }
    }
    if (m_isDragging) {
      const int dx = event->pos().x() - m_dragLastPos.x();
      m_dragLastPos = event->pos();

      // Pan by converting pixel delta to time delta
      qint64 xMin = effX->min().toMSecsSinceEpoch();
      qint64 xMax = effX->max().toMSecsSinceEpoch();
      double msPerPixel = (double)(xMax - xMin) / chart()->plotArea().width();
      qint64 deltaMs = (qint64)(dx * msPerPixel);

      m_manualXMin = xMin - deltaMs;
      m_manualXMax = xMax - deltaMs;
      clampPanRange();

      effX->setRange(QDateTime::fromMSecsSinceEpoch(m_manualXMin),
                     QDateTime::fromMSecsSinceEpoch(m_manualXMax));
      refreshAxes();
    } else if (m_rectZooming) {
      m_rectZoomCurrent = event->pos();
    }
    m_hoverVisible = false;
    viewport()->update();
    event->accept();
    return;
  }

  // Hover tooltip + crosshair (reuse effX from drag block above).
  // In delta mode cursor A (m_pinned) stays visible but hover must still
  // update so the user can see where cursor B will land before clicking.
  if (m_pinned && !m_deltaModeEnabled) {
    viewport()->update();
    return;
  }
  const QList<QLineSeries *> series = allLineSeries();
  if (!series.isEmpty() && effX) {
    QRectF plotArea = chart()->plotArea();
    if (plotArea.contains(event->pos())) {
      QPointF chartPos = chart()->mapToValue(event->pos());
      qint64 xMs = (qint64)chartPos.x();
      QString tip =
          QDateTime::fromMSecsSinceEpoch(xMs).toString("HH:mm:ss.zzz");

      m_hoverVisible = true;
      m_hoverX = event->pos().x();
      m_hoverPoints.clear();

      // Build signal → segments map.
      // Live/CSV charts use m_seriesSegments (multiple QLineSeries per signal
      // for gap support). Graph page bypasses m_seriesSegments entirely —
      // series are added directly to the chart via setChart(), so fall back to
      // allLineSeries() and treat each QLineSeries as its own signal.
      const bool isGraphPage = m_seriesSegments.isEmpty();
      QHash<QString, QList<QLineSeries *>> sigMap;
      if (!isGraphPage) {
        sigMap = m_seriesSegments;
      } else {
        for (QLineSeries *s : series) {
          const QString &n = s->name();
          if (!n.isEmpty() && !n.endsWith("_gap"))
            sigMap[n] << s;
        }
      }

      for (const QString &sigName : sigMap.keys()) {
        const QList<QLineSeries *> &segments = sigMap[sigName];
        if (segments.isEmpty()) continue;

        // Find point in ANY segment of this signal
        bool found = false;
        double nearVal = 0;
        QColor color = segments.first()->color();

        for (QLineSeries *s : segments) {
          const QList<QPointF> &pts = s->points();
          if (pts.isEmpty())
            continue;

          // For live/CSV charts: skip segments clearly out of range.
          // For Graph page: data is downsampled so we always search.
          if (!isGraphPage &&
              (xMs < pts.first().x() - 1000 || xMs > pts.last().x() + 1000))
            continue;

          int lo = 0, hi = (int)pts.size() - 1;
          while (lo < hi) {
            int mid = (lo + hi) / 2;
            if (pts[mid].x() < xMs)
              lo = mid + 1;
            else
              hi = mid;
          }

          double segmentNearVal;
          qint64 dist;
          if (lo <= 0) {
            segmentNearVal = pts.first().y();
            dist = std::abs((qint64)pts.first().x() - xMs);
          } else if (lo >= pts.size()) {
            segmentNearVal = pts.last().y();
            dist = std::abs((qint64)pts.last().x() - xMs);
          } else {
            double d0 = std::abs(pts[lo - 1].x() - xMs);
            double d1 = std::abs(pts[lo].x() - xMs);
            if (d0 <= d1) {
              segmentNearVal = pts[lo - 1].y();
              dist = (qint64)d0;
            } else {
              segmentNearVal = pts[lo].y();
              dist = (qint64)d1;
            }
          }

          // Live/CSV: 500ms gap guard prevents dots across disconnection gaps.
          // Graph page: no gap segments exist, always show nearest point.
          const qint64 maxDist =
              isGraphPage ? std::numeric_limits<qint64>::max() : 500LL;
          if (dist < maxDist) {
            nearVal = segmentNearVal;
            found = true;
            break;
          }
        }

        if (found) {
          tip += QString("\n%1:  %2")
                     .arg(sigName, QString::number(nearVal, 'f', m_decimalPlaces));
          m_hoverPoints.append({QPointF((double)xMs, nearVal), color, sigName});
        }
      }
      m_hoverTip = tip;
      QToolTip::showText(event->globalPosition().toPoint(), tip, this);
    } else {
      m_hoverVisible = false;
      QToolTip::hideText();
    }
    viewport()->update();
  }

  QChartView::mouseMoveEvent(event);
}

void DroppableChartView::mouseReleaseEvent(QMouseEvent *event) {
  if (event->button() == Qt::LeftButton) {
    // Branch 1: finalize rectangle zoom
    if (m_rectZooming) {
      m_rectZooming = false; setCursor(Qt::ArrowCursor);
      QRectF sel = QRectF(m_rectZoomOrigin, m_rectZoomCurrent).normalized();
      if (sel.width() > DRAG_THRESHOLD && sel.height() > DRAG_THRESHOLD) {
        QPointF p1 = chart()->mapToValue(sel.topLeft());
        QPointF p2 = chart()->mapToValue(sel.bottomRight());
        m_manualXMin = (qint64)std::min(p1.x(), p2.x());
        m_manualXMax = (qint64)std::max(p1.x(), p2.x());
        m_liveMode   = false;
        refreshAxes();
        if (!m_fixedYAxis && effectiveYAxis())
          effectiveYAxis()->setRange(std::min(p1.y(), p2.y()), std::max(p1.y(), p2.y()));
      }
      m_dragMoved = false; m_inDoubleClick = false;
      viewport()->update(); event->accept(); return;
    }
    if (m_isDragging) {
      m_isDragging = false;
      setCursor(Qt::ArrowCursor);
    } else if (!m_dragMoved && !m_inDoubleClick) {
      QDateTimeAxis *effX = effectiveXAxis();
      // Branch 2: delta cursor state machine
      if (m_deltaModeEnabled && !m_liveMode && m_hoverVisible && !m_hoverPoints.isEmpty()) {
        if (m_deltaState == DeltaState::None || m_deltaState == DeltaState::BSet) {
          // (re)set cursor A
          m_pinned = true; m_pinnedX = m_hoverX;
          m_pinnedPoints = m_hoverPoints; m_pinnedTip = m_hoverTip;
          m_deltaB = false; m_deltaBPoints.clear();
          m_deltaState = DeltaState::ASet;
        } else { // ASet → place cursor B
          m_deltaB = true; m_deltaBX = m_hoverX;
          m_deltaBPoints = m_hoverPoints; m_deltaBTip = m_hoverTip;
          m_deltaState = DeltaState::BSet;
        }
        m_hoverVisible = false;
        viewport()->update(); event->accept(); return;
      }
      if (m_liveMode) {
        // Single click while live → pause (only on live-owning charts)
        if (effX && m_axisX == effX) {
          m_manualXMin = effX->min().toMSecsSinceEpoch();
          m_manualXMax = effX->max().toMSecsSinceEpoch();
          m_liveMode = false;
        }
      } else {
        // Single click while paused
        if (m_pinned && !m_pinnedPoints.isEmpty()) {
          qreal curPinX = chart()->mapToPosition(m_pinnedPoints.first().chartPos).x();
          if (std::abs(event->pos().x() - (int)curPinX) <= 10) {
            // Clicking on or very near the existing pin → unpin
            m_pinned = false;
            m_pinnedPoints.clear();
            QToolTip::hideText();
          } else if (m_hoverVisible && !m_hoverPoints.isEmpty()) {
            // Clicking elsewhere → move pin to hovered position
            m_pinnedX      = m_hoverX;
            m_pinnedPoints = m_hoverPoints;
            m_pinnedTip    = m_hoverTip;
            m_hoverVisible = false;
            QToolTip::hideText();
          }
        } else if (m_hoverVisible && !m_hoverPoints.isEmpty()) {
          // No pin yet → create pin at hovered position
          m_pinned       = true;
          m_pinnedX      = m_hoverX;
          m_pinnedPoints = m_hoverPoints;
          m_pinnedTip    = m_hoverTip;
          m_hoverVisible = false;
          QToolTip::hideText();
        }
      }
    }
    m_dragMoved = false;
    m_inDoubleClick = false;
    viewport()->update();
    event->accept();
    return;
  }
  QChartView::mouseReleaseEvent(event);
}

void DroppableChartView::mouseDoubleClickEvent(QMouseEvent *event) {
  if (event->button() == Qt::LeftButton && !m_isStaticChart && m_axisX == effectiveXAxis()) {
    // Flag suppresses the upcoming mouseReleaseEvent from pausing again.
    // Then immediately resume live mode.
    // Guard ensures we only resume live mode on charts that own m_axisX
    // (live/CSV charts). Graph page has an external chart; live mode has no
    // meaning there.
    m_inDoubleClick = true;
    setLiveMode(true);
    event->accept();
    return;
  }
  QChartView::mouseDoubleClickEvent(event);
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::dragEnterEvent(QDragEnterEvent *event) {
  if (event->mimeData()->hasFormat("application/x-hedap-signal"))
    event->acceptProposedAction();
  else
    event->ignore();
}

void DroppableChartView::dragMoveEvent(QDragMoveEvent *event) {
  if (event->mimeData()->hasFormat("application/x-hedap-signal"))
    event->acceptProposedAction();
  else
    event->ignore();
}

void DroppableChartView::dropEvent(QDropEvent *event) {
  if (!event->mimeData()->hasFormat("application/x-hedap-signal")) {
    event->ignore();
    return;
  }
  QString payload =
      QString::fromUtf8(event->mimeData()->data("application/x-hedap-signal"));
  const QStringList names = payload.split(',', Qt::SkipEmptyParts);
  for (const QString &name : names)
    addSignal(name.trimmed());
  event->acceptProposedAction();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::paintEvent(QPaintEvent *event) {
  QChartView::paintEvent(event);

  if (m_seriesSegments.isEmpty() && acceptDrops()) {
    // Draw a placeholder message when no series have been added yet
    QPainter p(viewport());
    p.setRenderHint(QPainter::Antialiasing);
    QFont f = p.font();
    f.setPointSize(11);
    p.setFont(f);
    p.setPen(QColor(0x88, 0x88, 0x88));
    QRect r = viewport()->rect();
    p.drawText(r, Qt::AlignCenter,
               "Drop a signal here to start plotting\n"
               "(drag from Decoded Signals or Message Rate tables)");
    return;
  }

  // ── Feature 1: Threshold lines ────────────────────────────────────────────
  if (!m_thresholds.isEmpty()) {
    QStringList chartSignals = trackedSignals();
    if (chartSignals.isEmpty())
      for (QLineSeries *s : allLineSeries())
        if (!s->name().endsWith("_gap")) chartSignals << s->name();
    QPainter p(viewport());
    p.setRenderHint(QPainter::Antialiasing);
    QRectF plotArea = chart()->plotArea();
    for (const ThresholdConfig &th : m_thresholds) {
      if (!th.enabled) continue;
      bool applies = th.signalName.isEmpty() ? !chartSignals.isEmpty()
                                             : chartSignals.contains(th.signalName);
      if (!applies) continue;
      qreal lineY = chart()->mapToPosition(QPointF(0.0, th.value)).y();
      if (lineY < plotArea.top() || lineY > plotArea.bottom()) continue;
      QPen pen(th.color, 1, Qt::DashLine);
      p.setPen(pen);
      p.drawLine(QPointF(plotArea.left(), lineY), QPointF(plotArea.right(), lineY));
      QFont f = p.font(); f.setPointSize(8); p.setFont(f);
      p.setPen(th.color);
      p.drawText(QPointF(plotArea.right() + 4, lineY + 4),
                 QString::number(th.value, 'f', m_decimalPlaces));
    }
  }

  // ── Feature 3: Statistics overlay ─────────────────────────────────────────
  if (m_statsOverlayEnabled && !m_statsCache.isEmpty()) {
    QPainter p(viewport()); p.setRenderHint(QPainter::Antialiasing);
    QFont f = p.font(); f.setPointSize(8); p.setFont(f);
    QFontMetrics fm(f);
    QRectF plotArea = chart()->plotArea();
    QStringList lines;
    for (const QString &sig : m_statsCache.keys()) {
      const StatEntry &e = m_statsCache[sig];
      lines << QString("%1  min:%2  max:%3  avg:%4").arg(sig)
                   .arg(e.min, 0, 'f', m_decimalPlaces)
                   .arg(e.max, 0, 'f', m_decimalPlaces)
                   .arg(e.mean, 0, 'f', m_decimalPlaces);
    }
    const int pad = 6;
    int boxW = 0;
    for (const QString &l : lines) boxW = std::max(boxW, fm.horizontalAdvance(l));
    boxW += pad * 2;
    int boxH = fm.height() * lines.size() + pad * 2;
    int boxX = (int)plotArea.right() - boxW - 6;
    int boxY = (int)plotArea.top() + 6;
    p.setPen(Qt::NoPen); p.setBrush(QColor(20, 20, 20, 180));
    p.drawRoundedRect(QRect(boxX, boxY, boxW, boxH), 4, 4);
    p.setPen(QColor(230, 230, 230));
    for (int i = 0; i < lines.size(); ++i)
      p.drawText(boxX + pad, boxY + pad + fm.ascent() + fm.height() * i, lines[i]);
  }

  // Draw hover crosshair + dots (no axis lookup needed — m_hoverX and
  // m_hoverPoints are pre-computed in pixel/chart coordinates).
  if (m_hoverVisible && !m_hoverPoints.isEmpty()) {
    QPainter p(viewport());
    p.setRenderHint(QPainter::Antialiasing);
    QRectF plotArea = chart()->plotArea();

    // Vertical dashed crosshair line
    p.setPen(QPen(QColor(120, 120, 120, 180), 1, Qt::DashLine));
    p.drawLine(QPointF(m_hoverX, plotArea.top()),
               QPointF(m_hoverX, plotArea.bottom()));

    // Filled dot per series at nearest data point
    for (const HoverPoint &hp : m_hoverPoints) {
      QPointF px = chart()->mapToPosition(hp.chartPos);
      if (!plotArea.contains(px))
        continue;
      p.setPen(QPen(Qt::white, 2));
      p.setBrush(hp.color);
      p.drawEllipse(px, 5.0, 5.0);
    }
  }

  // Draw pinned crosshair (red line + red dots + dark annotation box).
  // The pin position is computed dynamically from the data coordinate so it
  // correctly tracks the point as the live chart scrolls, and auto-clears
  // when the point scrolls past the left edge of the visible window.
  if (m_pinned && !m_pinnedPoints.isEmpty()) {
    QRectF plotArea = chart()->plotArea();

    // Compute current screen X from the pinned data coordinate
    qreal currentX = chart()->mapToPosition(m_pinnedPoints.first().chartPos).x();

    if (currentX < plotArea.left() - 2) {
      // Pinned time has scrolled off the left edge — auto-clear the pin
      m_pinned = false;
      m_pinnedPoints.clear();
    } else if (currentX <= plotArea.right() + 2) {
      QPainter p(viewport());
      p.setRenderHint(QPainter::Antialiasing);

      // Red dashed vertical line
      p.setPen(QPen(QColor(220, 50, 50, 220), 1, Qt::DashLine));
      p.drawLine(QPointF(currentX, plotArea.top()),
                 QPointF(currentX, plotArea.bottom()));

      // Red dots per series (slightly larger than normal hover dots)
      for (const HoverPoint &hp : m_pinnedPoints) {
        QPointF px = chart()->mapToPosition(hp.chartPos);
        if (!plotArea.contains(px)) continue;
        p.setPen(QPen(Qt::white, 2));
        p.setBrush(Qt::red);
        p.drawEllipse(px, 6.0, 6.0);
      }

      // Annotation label box (time + signal values)
      // In delta mode the annotation box is suppressed here — it is drawn
      // by the delta annotation block below (showing ΔT / ΔY instead).
      if (!m_pinnedTip.isEmpty() && !m_deltaModeEnabled) {
        QFont f = p.font();
        f.setPointSize(9);
        p.setFont(f);
        QFontMetrics fm(f);
        QStringList lines = m_pinnedTip.split('\n');
        int textW = 0;
        for (const QString &l : lines)
          textW = std::max(textW, fm.horizontalAdvance(l));
        const int pad = 6;
        int boxW = textW + pad * 2;
        int boxH = fm.height() * lines.size() + pad * 2;
        // Position box to the right of the crosshair; flip left if near right edge
        int boxX = (int)currentX + 10;
        if (boxX + boxW > (int)plotArea.right())
          boxX = (int)currentX - boxW - 10;
        int boxY = (int)plotArea.top() + 10;

        p.setPen(Qt::NoPen);
        p.setBrush(QColor(30, 30, 30, 215));
        p.drawRoundedRect(QRect(boxX, boxY, boxW, boxH), 4, 4);
        p.setPen(Qt::white);
        for (int i = 0; i < lines.size(); ++i)
          p.drawText(boxX + pad,
                     boxY + pad + fm.ascent() + fm.height() * i,
                     lines[i]);
      }
    }
  }

  // ── Feature 2: Cursor B (green dashed line + dots) ────────────────────────
  if (m_deltaModeEnabled && m_deltaB && !m_deltaBPoints.isEmpty()) {
    QRectF plotArea = chart()->plotArea();
    qreal curBX = chart()->mapToPosition(m_deltaBPoints.first().chartPos).x();
    if (curBX >= plotArea.left() - 2 && curBX <= plotArea.right() + 2) {
      QPainter p(viewport()); p.setRenderHint(QPainter::Antialiasing);
      p.setPen(QPen(QColor(50, 200, 80, 220), 1, Qt::DashLine));
      p.drawLine(QPointF(curBX, plotArea.top()), QPointF(curBX, plotArea.bottom()));
      for (const HoverPoint &hp : m_deltaBPoints) {
        QPointF px = chart()->mapToPosition(hp.chartPos);
        if (!plotArea.contains(px)) continue;
        p.setPen(QPen(Qt::white, 2)); p.setBrush(QColor(50, 200, 80));
        p.drawEllipse(px, 6.0, 6.0);
      }
    }
  }

  // ── Feature 2: Delta annotation box (ΔT + ΔY per signal) ─────────────────
  if (m_deltaModeEnabled && m_pinned && !m_pinnedPoints.isEmpty()
      && m_deltaB && !m_deltaBPoints.isEmpty()) {
    QRectF plotArea = chart()->plotArea();
    qreal curAX = chart()->mapToPosition(m_pinnedPoints.first().chartPos).x();
    qreal curBX = chart()->mapToPosition(m_deltaBPoints.first().chartPos).x();
    if (curAX < plotArea.left() - 2) {
      // Cursor A scrolled off → clear both cursors
      m_pinned = false; m_pinnedPoints.clear();
      m_deltaB = false; m_deltaBPoints.clear();
      m_deltaState = DeltaState::None;
    } else {
      qint64 tA = (qint64)m_pinnedPoints.first().chartPos.x();
      qint64 tB = (qint64)m_deltaBPoints.first().chartPos.x();
      double deltaT_s = (tB - tA) / 1000.0;
      QPainter p(viewport()); p.setRenderHint(QPainter::Antialiasing);
      QFont f = p.font(); f.setPointSize(9); p.setFont(f);
      QFontMetrics fm(f);
      QStringList lines;
      lines << QString("ΔT: %1 s").arg(deltaT_s, 0, 'f', 3);
      for (const HoverPoint &hpA : m_pinnedPoints)
        for (const HoverPoint &hpB : m_deltaBPoints)
          if (hpA.signalName == hpB.signalName && !hpA.signalName.isEmpty())
            lines << QString("ΔY (%1): %2").arg(hpA.signalName)
                         .arg(hpB.chartPos.y() - hpA.chartPos.y(), 0, 'f', m_decimalPlaces);
      const int pad = 6;
      int boxW = 0;
      for (const QString &l : lines) boxW = std::max(boxW, fm.horizontalAdvance(l));
      boxW += pad * 2;
      int boxH = fm.height() * lines.size() + pad * 2;
      qreal midX = (curAX + curBX) / 2.0;
      int boxX = qBound((int)plotArea.left(), (int)midX - boxW / 2,
                        (int)plotArea.right() - boxW);
      int boxY = (int)plotArea.top() + 30;
      p.setPen(Qt::NoPen); p.setBrush(QColor(30, 30, 30, 215));
      p.drawRoundedRect(QRect(boxX, boxY, boxW, boxH), 4, 4);
      p.setPen(Qt::white);
      for (int i = 0; i < lines.size(); ++i)
        p.drawText(boxX + pad, boxY + pad + fm.ascent() + fm.height() * i, lines[i]);
    }
  }

  // ── Feature 5: Rubber-band rectangle zoom selection ───────────────────────
  if (m_rectZooming) {
    QPainter p(viewport());
    QRect sel = QRect(m_rectZoomOrigin, m_rectZoomCurrent).normalized()
                    .intersected(chart()->plotArea().toRect());
    p.setPen(QPen(QColor(60, 120, 220, 200), 1));
    p.setBrush(QColor(60, 120, 220, 40));
    p.drawRect(sel);
  }
}
