#ifndef CANBUSWORKER_H
#define CANBUSWORKER_H

#include <QObject>
#include <QTimer>

#if __has_include(<QCanBus>)
#include <QCanBus>
#include <QCanBusDevice>
#include <QCanBusFrame>
#define HEDAP_HAS_CANBUS 1
#else
#define HEDAP_HAS_CANBUS 0
#endif

// ─────────────────────────────────────────────────────────────────────────────
//  CanBusWorker
//  Native CAN adapter support via Qt6 SerialBus (QCanBus / QCanBusDevice).
//  Supports PCAN-USB, Vector, SYSTec, SocketCAN and other Qt CAN plugins.
//
//  Emits the same lineReceived(csvLine) signal as SerialWorker so the rest
//  of the application (live monitor, charts, decoding) works unchanged.
//
//  When Qt6 SerialBus is NOT installed, this class compiles as a stub that
//  reports the module is unavailable.
// ─────────────────────────────────────────────────────────────────────────────
class CanBusWorker : public QObject {
  Q_OBJECT

public:
  explicit CanBusWorker(QObject *parent = nullptr);
  ~CanBusWorker();

  // Returns true if Qt6 SerialBus module is available at compile time
  static bool isAvailable();

  // List available CAN plugins (e.g. "peakcan", "socketcan", "vectorcan")
  static QStringList availablePlugins();

  // List interfaces for a given plugin (e.g. for "peakcan": "usb0", "usb1")
  static QStringList availableInterfaces(const QString &plugin);

  bool isConnected() const;

public slots:
  // Connect to a CAN device
  // plugin:    "peakcan", "socketcan", etc.
  // interface: "usb0", "can0", etc.
  // bitrate:   250000, 500000, 1000000, etc.
  void connectDevice(const QString &plugin, const QString &interface,
                     int bitrate);
  void disconnectDevice();

signals:
  // HEDAP CSV formatted line: "isoTime,epoch,,,0xID,,,  HH HH HH ..."
  void lineReceived(const QString &csvLine);
  void connectionChanged(bool connected);
  void errorOccurred(const QString &errorMessage);
  void statsUpdated(int framesPerSec);

private slots:
  void onFramesReceived();
  void onDeviceError();
  void onStatsTimer();

private:
  QString frameToCsv(const QString &id, const QString &dataHex);

#if HEDAP_HAS_CANBUS
  QCanBusDevice *m_device = nullptr;
#endif
  QTimer *m_statsTimer;
  int m_frameCounter = 0;
};

#endif // CANBUSWORKER_H
