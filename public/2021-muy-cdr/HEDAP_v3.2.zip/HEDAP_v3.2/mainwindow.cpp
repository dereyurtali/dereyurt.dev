#include "mainwindow.h"
#include "safeeval.h"
#include "serialworker.h"
#include "ui_mainwindow.h"
#include <QApplication>
#include <QCheckBox>
#include <QColorDialog>
#include <QComboBox>
#include <QDebug>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDrag>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMap>
#include <QMenu>
#include <QMessageBox>
#include <QMimeData>
#include <QPainter>
#include <QPalette>
#include <QProgressBar>
#include <QProgressDialog>
#include <QRegularExpression>
#include <QResizeEvent>
#include <QScrollArea>
#include <QSet>
#include <QSplitter>
#include <QStandardPaths>
#include <QStyleFactory>
#include <QTableWidget>
#include <QTextStream>
#include <QToolButton>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QVBoxLayout>
#include <functional>
#include <limits>

// Forward declarations for static helpers defined later in this file
static quint32 normaliseCanId(const QString &s);
static bool extractDbcSignalRaw(const QString &hexPayload, int startBit,
                                int bitLength, bool littleEndian, bool isSigned,
                                double &outValue);
static std::pair<double, double> parseLinearFormula(const QString &formula);

// ─────────────────────────────────────────────────────────────────────────────
//  Local drag-enabled table subclasses (used by buildLivePage only)
// ─────────────────────────────────────────────────────────────────────────────
namespace {

// Drags the text from column m_col of the selected row(s) as signal name(s).
class SignalDragTable : public QTableWidget {
  int m_col;

public:
  SignalDragTable(int col, QWidget *p = nullptr) : QTableWidget(p), m_col(col) {
    setDragEnabled(true);
    setSelectionBehavior(QAbstractItemView::SelectRows);
    setSelectionMode(QAbstractItemView::SingleSelection);
  }

protected:
  void startDrag(Qt::DropActions) override {
    QStringList names;
    QSet<int> seen;
    for (QTableWidgetItem *it : selectedItems()) {
      if (seen.contains(it->row()))
        continue;
      seen.insert(it->row());
      if (QTableWidgetItem *si = item(it->row(), m_col))
        if (!si->text().isEmpty())
          names << si->text();
    }
    if (names.isEmpty())
      return;
    QMimeData *mime = new QMimeData;
    mime->setData("application/x-hedap-signal", names.join(',').toUtf8());
    QDrag *drag = new QDrag(this);
    drag->setMimeData(mime);
    drag->exec(Qt::CopyAction);
  }
};

// Drags all decoded-signal names for the CAN ID in column 0 of the selected
// row.
class MsgRateDragTable : public QTableWidget {
  std::function<QStringList(const QString &)> m_resolver;

public:
  MsgRateDragTable(std::function<QStringList(const QString &)> resolver,
                   QWidget *p = nullptr)
      : QTableWidget(p), m_resolver(std::move(resolver)) {
    setDragEnabled(true);
    setSelectionBehavior(QAbstractItemView::SelectRows);
    setSelectionMode(QAbstractItemView::SingleSelection);
  }

protected:
  void startDrag(Qt::DropActions) override {
    int row = currentRow();
    if (row < 0)
      return;
    QTableWidgetItem *idItem = item(row, 0);
    if (!idItem)
      return;
    QStringList sigs = m_resolver(idItem->text());
    if (sigs.isEmpty())
      return;
    QMimeData *mime = new QMimeData;
    mime->setData("application/x-hedap-signal", sigs.join(',').toUtf8());
    QDrag *drag = new QDrag(this);
    drag->setMimeData(mime);
    drag->exec(Qt::CopyAction);
  }
};

// Drop zone widget: accepts "application/x-hedap-signal" drags and emits a
// signal when a signal name is dropped onto it.
class SignalDropZone : public QFrame {
  Q_OBJECT
public:
  explicit SignalDropZone(QWidget *parent = nullptr) : QFrame(parent) {
    setAcceptDrops(true);
    setMinimumHeight(48);
    setFrameShape(QFrame::StyledPanel);
    setLineWidth(2);
    setStyleSheet("SignalDropZone {"
                  "  background: rgba(0,120,212,0.06);"
                  "  border: 2px dashed rgba(0,120,212,0.35);"
                  "  border-radius: 6px;"
                  "  color: #888;"
                  "  font-size: 12px;"
                  "}");
    m_label = new QLabel("Drop a signal here to open its graph", this);
    m_label->setAlignment(Qt::AlignCenter);
    m_label->setStyleSheet("color: #888; font-size: 12px; border: none;");
    QVBoxLayout *lay = new QVBoxLayout(this);
    lay->setContentsMargins(0, 0, 0, 0);
    lay->addWidget(m_label);
  }

signals:
  void signalDropped(const QString &signalName);

protected:
  void dragEnterEvent(QDragEnterEvent *e) override {
    if (e->mimeData()->hasFormat("application/x-hedap-signal")) {
      e->acceptProposedAction();
      setStyleSheet("SignalDropZone {"
                    "  background: rgba(0,120,212,0.15);"
                    "  border: 2px solid #0078D4;"
                    "  border-radius: 6px;"
                    "}");
    }
  }
  void dragLeaveEvent(QDragLeaveEvent *) override {
    setStyleSheet("SignalDropZone {"
                  "  background: rgba(0,120,212,0.06);"
                  "  border: 2px dashed rgba(0,120,212,0.35);"
                  "  border-radius: 6px;"
                  "}");
  }
  void dropEvent(QDropEvent *e) override {
    setStyleSheet("SignalDropZone {"
                  "  background: rgba(0,120,212,0.06);"
                  "  border: 2px dashed rgba(0,120,212,0.35);"
                  "  border-radius: 6px;"
                  "}");
    QByteArray raw = e->mimeData()->data("application/x-hedap-signal");
    QStringList names = QString::fromUtf8(raw).split(',', Qt::SkipEmptyParts);
    for (const QString &n : names)
      emit signalDropped(n.trimmed());
    e->acceptProposedAction();
  }

private:
  QLabel *m_label;
};

} // namespace

// SignalDropZone uses Q_OBJECT inside an anonymous namespace; pull in the
// generated MOC so the meta-object system can find it at link time.
#include "mainwindow.moc"

static const char *QSS_COMMON = R"(

)";

static void buildLightPalette(QApplication *app) {
  QPalette p;
  p.setColor(QPalette::Window, QColor(0xF0, 0xF0, 0xF0));
  p.setColor(QPalette::WindowText, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::Base, QColor(0xFF, 0xFF, 0xFF));
  p.setColor(QPalette::AlternateBase, QColor(0xF5, 0xF5, 0xF5));
  p.setColor(QPalette::Text, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::BrightText, Qt::white);
  p.setColor(QPalette::Button, QColor(0xE1, 0xE1, 0xE1));
  p.setColor(QPalette::ButtonText, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::Highlight, QColor(0x38, 0x75, 0xD7));
  p.setColor(QPalette::HighlightedText, Qt::white);
  p.setColor(QPalette::ToolTipBase, QColor(0xFF, 0xFF, 0xE0));
  p.setColor(QPalette::ToolTipText, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::Link, QColor(0x00, 0x78, 0xD4));
  p.setColor(QPalette::Mid, QColor(0xC0, 0xC0, 0xC0));
  p.setColor(QPalette::Midlight, QColor(0xD8, 0xD8, 0xD8));
  p.setColor(QPalette::Dark, QColor(0xA0, 0xA0, 0xA0));
  p.setColor(QPalette::Shadow, QColor(0x80, 0x80, 0x80));
  p.setColor(QPalette::Disabled, QPalette::WindowText,
             QColor(0xA0, 0xA0, 0xA0));
  p.setColor(QPalette::Disabled, QPalette::Text, QColor(0xA0, 0xA0, 0xA0));
  p.setColor(QPalette::Disabled, QPalette::ButtonText,
             QColor(0xA0, 0xA0, 0xA0));
  p.setColor(QPalette::Disabled, QPalette::Base, QColor(0xF0, 0xF0, 0xF0));
  app->setPalette(p);
}

static void buildDarkPalette(QApplication *app) {
  QPalette p;
  p.setColor(QPalette::Window, QColor(0x2D, 0x2D, 0x2D));
  p.setColor(QPalette::WindowText, QColor(0xD4, 0xD4, 0xD4));
  p.setColor(QPalette::Base, QColor(0x1E, 0x1E, 0x1E));
  p.setColor(QPalette::AlternateBase, QColor(0x25, 0x25, 0x26));
  p.setColor(QPalette::Text, QColor(0xD4, 0xD4, 0xD4));
  p.setColor(QPalette::BrightText, Qt::white);
  p.setColor(QPalette::Button, QColor(0x3C, 0x3C, 0x3C));
  p.setColor(QPalette::ButtonText, QColor(0xD4, 0xD4, 0xD4));
  p.setColor(QPalette::Highlight, QColor(0x26, 0x4F, 0x78));
  p.setColor(QPalette::HighlightedText, Qt::white);
  p.setColor(QPalette::ToolTipBase, QColor(0x45, 0x45, 0x45));
  p.setColor(QPalette::ToolTipText, QColor(0xD4, 0xD4, 0xD4));
  p.setColor(QPalette::Link, QColor(0x4E, 0xC9, 0xB0));
  p.setColor(QPalette::Mid, QColor(0x55, 0x55, 0x55));
  p.setColor(QPalette::Midlight, QColor(0x44, 0x44, 0x44));
  p.setColor(QPalette::Dark, QColor(0x20, 0x20, 0x20));
  p.setColor(QPalette::Shadow, QColor(0x14, 0x14, 0x14));
  p.setColor(QPalette::Disabled, QPalette::WindowText,
             QColor(0x60, 0x60, 0x60));
  p.setColor(QPalette::Disabled, QPalette::Text, QColor(0x60, 0x60, 0x60));
  p.setColor(QPalette::Disabled, QPalette::ButtonText,
             QColor(0x60, 0x60, 0x60));
  p.setColor(QPalette::Disabled, QPalette::Base, QColor(0x28, 0x28, 0x28));
  app->setPalette(p);
}

// ─────────────────────────────────────────────────────────────────────────────
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow), m_toolbar(nullptr),
      m_summaryModel(new QStandardItemModel(this)),
      m_resultModel(new QStandardItemModel(this)), m_sidebar(nullptr),
      m_pages(nullptr), m_actLoadDBC(nullptr), m_actUnloadDBC(nullptr) {
  QApplication::setStyle(QStyleFactory::create("Fusion"));

  ui->setupUi(this);
  setWindowTitle("HEDAP - Hex Data Analysis Platform");

  buildToolbar();
  buildSidebar();
  setupTables();

  // ── Menu bar connections ─────────────────────────────────────────────────
  connect(ui->action_load, &QAction::triggered, this,
          &MainWindow::on_btn_load_clicked);
  connect(ui->action_unload, &QAction::triggered, this,
          &MainWindow::on_btn_unload_clicked);
  connect(ui->action_export_csv, &QAction::triggered, this,
          &MainWindow::on_btn_export_clicked);
  connect(ui->action_export_data, &QAction::triggered, this,
          &MainWindow::on_btn_exportdata_clicked);
  connect(ui->action_filter, &QAction::triggered, this,
          &MainWindow::on_btn_filter_clicked);
  connect(ui->action_reset, &QAction::triggered, this,
          &MainWindow::on_btn_reset_clicked);
  connect(ui->action_conf, &QAction::triggered, this,
          &MainWindow::on_btn_conf_clicked);
  connect(ui->action_graph, &QAction::triggered, this,
          &MainWindow::on_btn_graph_clicked);
  connect(ui->action_theme_light, &QAction::triggered, this,
          &MainWindow::onThemeLight);
  connect(ui->action_theme_dark, &QAction::triggered, this,
          &MainWindow::onThemeDark);
  connect(ui->action_about, &QAction::triggered, this, &MainWindow::onAbout);
  connect(ui->action_exit, &QAction::triggered, this, &QMainWindow::close);

  setInterfaceState(false);

  loadSettings();
  applyTheme(m_isDark);

  loadConfigsFromFile();

  // ── Serial worker ─────────────────────────────────────────────────────────
  m_serialWorker = new SerialWorker(this);
  connect(m_serialWorker, &SerialWorker::lineReceived, this,
          &MainWindow::onSerialLineReceived);
  connect(m_serialWorker, &SerialWorker::connectionChanged, this,
          &MainWindow::onSerialConnChanged);
  connect(m_serialWorker, &SerialWorker::errorOccurred, this,
          &MainWindow::onSerialError);
  connect(m_serialWorker, &SerialWorker::statsUpdated, this,
          &MainWindow::onSerialStats);

  // ── CAN bus worker (PCAN-USB / SocketCAN / etc.) ────────────────────────
  m_canBusWorker = new CanBusWorker(this);
  connect(m_canBusWorker, &CanBusWorker::lineReceived, this,
          &MainWindow::onSerialLineReceived);
  connect(m_canBusWorker, &CanBusWorker::connectionChanged, this,
          &MainWindow::onSerialConnChanged);
  connect(m_canBusWorker, &CanBusWorker::errorOccurred, this,
          &MainWindow::onSerialError);
  connect(m_canBusWorker, &CanBusWorker::statsUpdated, this,
          &MainWindow::onSerialStats);

  m_liveBatchTimer = new QTimer(this);
  m_liveBatchTimer->setInterval(50);
  connect(m_liveBatchTimer, &QTimer::timeout, this,
          &MainWindow::onLiveBatchTimer);
  m_liveBatchTimer->start();

  m_liveMsgRateTimer = new QTimer(this);
  m_liveMsgRateTimer->setInterval(1000);
  connect(m_liveMsgRateTimer, &QTimer::timeout, this,
          &MainWindow::onLiveMsgRateTimer);
  m_liveMsgRateTimer->start();

  m_liveSimTimer = new QTimer(this);
  m_liveSimTimer->setInterval(100); // 10 fps
  connect(m_liveSimTimer, &QTimer::timeout, this, &MainWindow::onSimTick);

  // ── Start on Home page ───────────────────────────────────────────────────
  switchPage(PAGE_WELCOME);
  restoreLastDBC();
  statusBar()->showMessage("Ready.");
}

MainWindow::~MainWindow() { delete ui; }

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::buildToolbar() {
  m_toolbar = addToolBar("Main");
  m_toolbar->setMovable(false);
  m_toolbar->setFloatable(false);
  m_toolbar->setIconSize(QSize(16, 16));
  m_toolbar->setToolButtonStyle(Qt::ToolButtonTextOnly);

  m_actLoad = m_toolbar->addAction("Open CSV");
  m_actLoad->setShortcut(QKeySequence::Open);
  m_actLoad->setToolTip("Open CSV file (Ctrl+O)");
  connect(m_actLoad, &QAction::triggered, this,
          &MainWindow::on_btn_load_clicked);

  m_actUnload = m_toolbar->addAction("Close");
  m_actUnload->setToolTip("Close current file");
  connect(m_actUnload, &QAction::triggered, this,
          &MainWindow::on_btn_unload_clicked);

  m_toolbar->addSeparator();

  // ── DBC actions ───────────────────────────────────────────────────────────
  m_actLoadDBC = m_toolbar->addAction("Load DBC…");
  m_actLoadDBC->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_D));
  m_actLoadDBC->setToolTip("Load a .dbc CAN database file (Ctrl+D)");
  connect(m_actLoadDBC, &QAction::triggered, this, &MainWindow::onLoadDBC);

  m_actUnloadDBC = m_toolbar->addAction("Unload DBC");
  m_actUnloadDBC->setToolTip("Remove the loaded DBC database");
  m_actUnloadDBC->setEnabled(false);
  connect(m_actUnloadDBC, &QAction::triggered, this, &MainWindow::onUnloadDBC);

  m_toolbar->addSeparator();

  m_actFilter = m_toolbar->addAction("Filter…");
  m_actFilter->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_F));
  m_actFilter->setToolTip("Filter by message ID (Ctrl+F)");
  connect(m_actFilter, &QAction::triggered, this,
          &MainWindow::on_btn_filter_clicked);

  m_actReset = m_toolbar->addAction("Reset");
  m_actReset->setToolTip("Clear active filter");
  connect(m_actReset, &QAction::triggered, this,
          &MainWindow::on_btn_reset_clicked);

  m_toolbar->addSeparator();

  m_actConf = m_toolbar->addAction("Decoders…");
  m_actConf->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_K));
  m_actConf->setToolTip("Configure byte decoders (Ctrl+K)");
  connect(m_actConf, &QAction::triggered, this,
          &MainWindow::on_btn_conf_clicked);

  m_actGraph = m_toolbar->addAction("Plot Graph");
  m_actGraph->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_G));
  m_actGraph->setToolTip("Visualize decoded values (Ctrl+G)");
  connect(m_actGraph, &QAction::triggered, this,
          &MainWindow::on_btn_graph_clicked);

  m_toolbar->addSeparator();

  m_actExportCsv = m_toolbar->addAction("Export CSV…");
  m_actExportCsv->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_E));
  m_actExportCsv->setToolTip("Export raw data as CSV (Ctrl+E)");
  connect(m_actExportCsv, &QAction::triggered, this,
          &MainWindow::on_btn_export_clicked);

  m_actExportData = m_toolbar->addAction("Export Decoded…");
  m_actExportData->setToolTip("Export decoded values as CSV");
  connect(m_actExportData, &QAction::triggered, this,
          &MainWindow::on_btn_exportdata_clicked);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Sidebar + page navigation
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::buildSidebar() {
  // ── Create sidebar ───────────────────────────────────────────────────────
  m_sidebar = new QWidget(this);
  m_sidebar->setFixedWidth(140);
  m_sidebar->setObjectName("sidebar");

  QVBoxLayout *sideLayout = new QVBoxLayout(m_sidebar);
  sideLayout->setSpacing(2);
  sideLayout->setContentsMargins(4, 8, 4, 8);

  const QStringList labels = {"Home", "CSV Analysis", "Live Monitor",
                              "Decoders", "Graph"};

  for (int i = 0; i < labels.size(); ++i) {
    QPushButton *btn = new QPushButton(labels[i], m_sidebar);
    btn->setCheckable(true);
    btn->setMinimumHeight(36);
    btn->setCursor(Qt::PointingHandCursor);
    btn->setStyleSheet(
        "QPushButton { text-align: left; padding: 6px 12px; border: none; "
        "              font-size: 12px; border-radius: 4px; }"
        "QPushButton:checked { background: #0078D4; color: #FFF; font-weight: "
        "bold; }"
        "QPushButton:hover:!checked { background: rgba(255,255,255,0.08); }");
    connect(btn, &QPushButton::clicked, this, [this, i] { switchPage(i); });
    sideLayout->addWidget(btn);
    m_navButtons.append(btn);
  }

  sideLayout->addStretch();

  // ── Version label at bottom of sidebar ────────────────────────────────────
  QLabel *verLabel = new QLabel("v3.2", m_sidebar);
  verLabel->setAlignment(Qt::AlignCenter);
  verLabel->setStyleSheet("color: #888; font-size: 10px; padding: 4px;");
  sideLayout->addWidget(verLabel);

  // ── Create stacked widget ────────────────────────────────────────────────
  m_pages = new QStackedWidget(this);
  m_pages->addWidget(buildWelcomePage());  // 0 - Home
  m_pages->addWidget(buildCsvPage());      // 1 - CSV Analysis
  m_pages->addWidget(buildLivePage());     // 2 - Live Monitor
  m_pages->addWidget(buildDecodersPage()); // 3 - Decoders
  m_pages->addWidget(buildGraphPage());    // 4 - Graph

  // ── Replace central widget content ───────────────────────────────────────
  QWidget *container = new QWidget(this);
  QHBoxLayout *mainLayout = new QHBoxLayout(container);
  mainLayout->setSpacing(0);
  mainLayout->setContentsMargins(0, 0, 0, 0);

  QFrame *vLine = new QFrame(container);
  vLine->setFixedWidth(1);
  // semi-transparent line that adapts somewhat to light/dark behind it
  vLine->setStyleSheet("background-color: rgba(128, 128, 128, 0.3);");

  mainLayout->addWidget(m_sidebar);
  mainLayout->addWidget(vLine);
  mainLayout->addWidget(m_pages, 1);
  setCentralWidget(container);
}

void MainWindow::switchPage(int index) {
  if (index < 0 || index >= m_pages->count())
    return;
  m_pages->setCurrentIndex(index);

  // Refresh available serial ports when opening Live Monitor
  if (index == PAGE_LIVE && m_livePortCombo) {
    m_livePortCombo->clear();
    m_livePortCombo->addItems(SerialWorker::availablePorts());
    // Also refresh CAN interfaces
    if (m_canInterfaceCombo && m_canPluginCombo &&
        m_canPluginCombo->count() > 0) {
      m_canInterfaceCombo->clear();
      m_canInterfaceCombo->addItems(
          CanBusWorker::availableInterfaces(m_canPluginCombo->currentText()));
    }
  }

  for (int i = 0; i < m_navButtons.size(); ++i)
    m_navButtons[i]->setChecked(i == index);
}

QWidget *MainWindow::buildWelcomePage() {
  QWidget *page = new QWidget();
  QVBoxLayout *lay = new QVBoxLayout(page);
  lay->setAlignment(Qt::AlignCenter);
  lay->setSpacing(16);

  QLabel *title = new QLabel("HEDAP");
  title->setAlignment(Qt::AlignCenter);
  title->setStyleSheet(
      "font-size: 36px; font-weight: bold; letter-spacing: 4px;");
  lay->addWidget(title);

  QLabel *subtitle = new QLabel("Hex Data Analysis Platform");
  subtitle->setAlignment(Qt::AlignCenter);
  subtitle->setStyleSheet("font-size: 14px; color: #888;");
  lay->addWidget(subtitle);

  QLabel *ver = new QLabel("Version 3.2");
  ver->setAlignment(Qt::AlignCenter);
  ver->setStyleSheet("font-size: 11px; color: #666; margin-bottom: 24px;");
  lay->addWidget(ver);

  // ── Quick-action buttons ─────────────────────────────────────────────────
  auto makeBtn = [](const QString &text) -> QPushButton * {
    QPushButton *b = new QPushButton(text);
    b->setMinimumSize(220, 40);
    b->setCursor(Qt::PointingHandCursor);
    b->setStyleSheet(
        "QPushButton { background: #0078D4; color: #FFF; border: none; "
        "              border-radius: 4px; font-size: 13px; font-weight: bold; "
        "}"
        "QPushButton:hover { background: #106EBE; }");
    return b;
  };

  QPushButton *btnCsv = makeBtn("Open CSV File");
  QPushButton *btnLive = makeBtn("Connect to Device");

  QHBoxLayout *btnRow = new QHBoxLayout();
  btnRow->setSpacing(12);
  btnRow->addStretch();
  btnRow->addWidget(btnCsv);
  btnRow->addWidget(btnLive);
  btnRow->addStretch();
  lay->addLayout(btnRow);

  connect(btnCsv, &QPushButton::clicked, this, [this] {
    switchPage(PAGE_CSV);
    on_btn_load_clicked();
  });
  connect(btnLive, &QPushButton::clicked, this,
          [this] { switchPage(PAGE_LIVE); });

  return page;
}

QWidget *MainWindow::buildCsvPage() {
  QWidget *page = new QWidget();
  QVBoxLayout *lay = new QVBoxLayout(page);
  lay->setContentsMargins(0, 0, 0, 0);
  lay->setSpacing(0);

  // -- Empty-state overlay (visible when no CSV is loaded) --
  m_csvEmptyState = new QWidget(page);
  QVBoxLayout *emptyLay = new QVBoxLayout(m_csvEmptyState);
  emptyLay->setAlignment(Qt::AlignCenter);
  emptyLay->setSpacing(12);

  QLabel *emptyIcon = new QLabel("No Data Loaded");
  emptyIcon->setAlignment(Qt::AlignCenter);
  emptyIcon->setStyleSheet("font-size: 20px; font-weight: bold; color: #888;");
  emptyLay->addWidget(emptyIcon);

  QLabel *emptyDesc = new QLabel(
      "Load a CSV file to analyze CAN bus data.\n"
      "You can also load a DBC file first for automatic signal decoding.");
  emptyDesc->setAlignment(Qt::AlignCenter);
  emptyDesc->setWordWrap(true);
  emptyDesc->setStyleSheet("font-size: 12px; color: #666; max-width: 400px;");
  emptyLay->addWidget(emptyDesc);

  QPushButton *btnLoad = new QPushButton("Open CSV File");
  btnLoad->setMinimumSize(200, 36);
  btnLoad->setCursor(Qt::PointingHandCursor);
  btnLoad->setStyleSheet(
      "QPushButton { background: #0078D4; color: #FFF; border: none; "
      "              border-radius: 4px; font-size: 13px; font-weight: bold; }"
      "QPushButton:hover { background: #106EBE; }");
  emptyLay->addWidget(btnLoad, 0, Qt::AlignCenter);
  connect(btnLoad, &QPushButton::clicked, this,
          &MainWindow::on_btn_load_clicked);

  lay->addWidget(m_csvEmptyState);

  // -- Decoder guidance overlay (visible when data loaded but no decoders) --
  m_csvDecoderGuide = new QWidget(page);
  QVBoxLayout *guideLay = new QVBoxLayout(m_csvDecoderGuide);
  guideLay->setAlignment(Qt::AlignCenter);
  guideLay->setSpacing(10);

  QLabel *guideTitle = new QLabel("No Decoders Configured");
  guideTitle->setAlignment(Qt::AlignCenter);
  guideTitle->setStyleSheet("font-size: 16px; font-weight: bold; color: #888;");
  guideLay->addWidget(guideTitle);

  QLabel *guideDesc =
      new QLabel("To decode and view signal values, load a DBC file\n"
                 "or configure decoders manually from the Decoders page.");
  guideDesc->setAlignment(Qt::AlignCenter);
  guideDesc->setWordWrap(true);
  guideDesc->setStyleSheet("font-size: 12px; color: #666;");
  guideLay->addWidget(guideDesc);

  auto makeGuideBtn = [](const QString &text) -> QPushButton * {
    QPushButton *b = new QPushButton(text);
    b->setMinimumSize(180, 32);
    b->setCursor(Qt::PointingHandCursor);
    b->setStyleSheet(
        "QPushButton { background: #0078D4; color: #FFF; border: none; "
        "              border-radius: 4px; font-size: 12px; font-weight: bold; "
        "}"
        "QPushButton:hover { background: #106EBE; }");
    return b;
  };

  QHBoxLayout *guideBtnRow = new QHBoxLayout();
  guideBtnRow->setSpacing(10);
  guideBtnRow->addStretch();

  QPushButton *guideDbcBtn = makeGuideBtn("Load DBC File");
  QPushButton *guideConfBtn = makeGuideBtn("Open Decoders");
  guideBtnRow->addWidget(guideDbcBtn);
  guideBtnRow->addWidget(guideConfBtn);
  guideBtnRow->addStretch();
  guideLay->addLayout(guideBtnRow);

  connect(guideDbcBtn, &QPushButton::clicked, this, &MainWindow::onLoadDBC);
  connect(guideConfBtn, &QPushButton::clicked, this,
          [this] { switchPage(PAGE_DECODERS); });

  m_csvDecoderGuide->setVisible(false);
  ui->resultPanelLayout->addWidget(m_csvDecoderGuide);

  // -- Data tables (hidden until CSV is loaded) --
  lay->addWidget(ui->splitter_main);
  ui->splitter_main->setSizes({8000, 8000});
  ui->splitter_main->setVisible(false);

  return page;
}

QWidget *MainWindow::buildLivePage() {
  QWidget *page = new QWidget();
  QVBoxLayout *lay = new QVBoxLayout(page);
  lay->setContentsMargins(8, 8, 8, 8);
  lay->setSpacing(6);

  // ── Top bar: title + connection controls ──────────────────────────────────
  QHBoxLayout *topBar = new QHBoxLayout();
  topBar->setSpacing(6);

  QLabel *header = new QLabel("Live Monitor");
  header->setStyleSheet("font-size: 18px; font-weight: bold;");
  topBar->addWidget(header);
  topBar->addStretch();

  // ── Protocol selector (single unified combo) ─────────────────────────
  m_liveProtoCombo = new QComboBox();
  m_liveProtoCombo->setToolTip("Connection protocol");
  m_liveProtoCombo->addItems({"SLCAN", "UART"});
  if (CanBusWorker::isAvailable())
    m_liveProtoCombo->addItem("PCAN-USB");
  topBar->addWidget(m_liveProtoCombo);

  // ── Serial controls (shown for SLCAN & UART) ──────────────────────────
  m_serialControls = new QWidget();
  QHBoxLayout *serialLay = new QHBoxLayout(m_serialControls);
  serialLay->setContentsMargins(0, 0, 0, 0);
  serialLay->setSpacing(6);

  m_livePortCombo = new QComboBox();
  m_livePortCombo->setMinimumWidth(180);
  m_livePortCombo->setToolTip("Serial port");
  m_livePortCombo->addItems(SerialWorker::availablePorts());
  serialLay->addWidget(m_livePortCombo);

  m_liveBaudCombo = new QComboBox();
  m_liveBaudCombo->setToolTip("Baud rate");
  m_liveBaudCombo->addItems({"9600", "19200", "38400", "57600", "115200",
                             "230400", "460800", "921600", "1000000"});
  m_liveBaudCombo->setCurrentText("115200");
  serialLay->addWidget(m_liveBaudCombo);

  QPushButton *refreshPortsBtn = new QPushButton("\u27f3");
  refreshPortsBtn->setFixedWidth(28);
  refreshPortsBtn->setToolTip("Refresh port list");
  refreshPortsBtn->setCursor(Qt::PointingHandCursor);
  connect(refreshPortsBtn, &QPushButton::clicked, this, [this]() {
    m_livePortCombo->clear();
    m_livePortCombo->addItems(SerialWorker::availablePorts());
  });
  serialLay->addWidget(refreshPortsBtn);
  topBar->addWidget(m_serialControls);

  // ── CAN controls (shown for PCAN-USB) ────────────────────────────────
  m_canControls = new QWidget();
  QHBoxLayout *canLay = new QHBoxLayout(m_canControls);
  canLay->setContentsMargins(0, 0, 0, 0);
  canLay->setSpacing(6);

  m_canPluginCombo = new QComboBox();
  m_canPluginCombo->setToolTip("CAN plugin");
  m_canPluginCombo->setMinimumWidth(120);
  m_canPluginCombo->addItems(CanBusWorker::availablePlugins());
  canLay->addWidget(m_canPluginCombo);

  m_canInterfaceCombo = new QComboBox();
  m_canInterfaceCombo->setToolTip("CAN interface (e.g. usb0)");
  m_canInterfaceCombo->setEditable(true);
  m_canInterfaceCombo->setMinimumWidth(100);
  canLay->addWidget(m_canInterfaceCombo);

  // Helper lambda: populate interface combo with discovered + default entries
  auto refreshCanInterfaces = [this](const QString &plugin) {
    m_canInterfaceCombo->clear();
    QStringList discovered = CanBusWorker::availableInterfaces(plugin);
    m_canInterfaceCombo->addItems(discovered);
    // Add common defaults if not already discovered
    for (const QString &def : {"usb0", "usb1", "usb2", "usb3"}) {
      if (!discovered.contains(def))
        m_canInterfaceCombo->addItem(def);
    }
    m_canInterfaceCombo->setCurrentText(
        discovered.isEmpty() ? "usb0" : discovered.first());
  };

  connect(m_canPluginCombo, &QComboBox::currentTextChanged, this,
          refreshCanInterfaces);
  if (m_canPluginCombo->count() > 0)
    refreshCanInterfaces(m_canPluginCombo->currentText());

  m_canBitrateCombo = new QComboBox();
  m_canBitrateCombo->setToolTip("CAN bitrate");
  m_canBitrateCombo->addItems({"125000", "250000", "500000", "1000000"});
  m_canBitrateCombo->setCurrentText("500000");
  canLay->addWidget(m_canBitrateCombo);

  QPushButton *refreshCanBtn = new QPushButton("\u27f3");
  refreshCanBtn->setFixedWidth(28);
  refreshCanBtn->setToolTip("Refresh CAN interfaces");
  refreshCanBtn->setCursor(Qt::PointingHandCursor);
  connect(refreshCanBtn, &QPushButton::clicked, this, [this]() {
    m_canInterfaceCombo->clear();
    if (m_canPluginCombo->count() > 0)
      m_canInterfaceCombo->addItems(
          CanBusWorker::availableInterfaces(m_canPluginCombo->currentText()));
  });
  canLay->addWidget(refreshCanBtn);

  m_canControls->setVisible(false);
  topBar->addWidget(m_canControls);

  // Toggle controls based on protocol selection
  connect(m_liveProtoCombo, &QComboBox::currentTextChanged, this,
          [this](const QString &proto) {
            bool isCan = (proto == "PCAN-USB");
            m_serialControls->setVisible(!isCan);
            m_canControls->setVisible(isCan);
          });

  // ── Connect button ─────────────────────────────────────────────────────
  m_liveConnectBtn = new QPushButton("Connect");
  m_liveConnectBtn->setMinimumWidth(80);
  m_liveConnectBtn->setCursor(Qt::PointingHandCursor);
  m_liveConnectBtn->setStyleSheet(
      "QPushButton { background: #0078D4; color: #FFF; border: none; "
      "              border-radius: 4px; padding: 4px 14px; font-weight: bold; "
      "}"
      "QPushButton:hover { background: #106EBE; }");
  connect(m_liveConnectBtn, &QPushButton::clicked, this,
          &MainWindow::onLiveConnectClicked);
  topBar->addWidget(m_liveConnectBtn);

  m_liveSimBtn = new QPushButton("\u23ef Simulate");
  m_liveSimBtn->setMinimumWidth(90);
  m_liveSimBtn->setCursor(Qt::PointingHandCursor);
  m_liveSimBtn->setStyleSheet(
      "QPushButton { background: #107C10; color: #FFF; border: none; "
      "              border-radius: 4px; padding: 4px 14px; font-weight: bold; "
      "}"
      "QPushButton:hover { background: #0E6B0E; }");
  connect(m_liveSimBtn, &QPushButton::clicked, this, &MainWindow::onSimToggled);
  topBar->addWidget(m_liveSimBtn);

  topBar->addStretch();

  m_addChartBtn = new QPushButton("+ Add Chart");
  m_addChartBtn->setMinimumHeight(26);
  m_addChartBtn->setCursor(Qt::PointingHandCursor);
  m_addChartBtn->setStyleSheet(
      "QPushButton { background: #0078D4; color: #FFF; border: none; "
      "              border-radius: 4px; font-size: 11px; padding: 2px 10px; }"
      "QPushButton:hover { background: #106EBE; }");
  connect(m_addChartBtn, &QPushButton::clicked, this,
          &MainWindow::onAddChartClicked);
  topBar->addWidget(m_addChartBtn);

  lay->addLayout(topBar);

  // ── Status bar ────────────────────────────────────────────────────────────
  m_liveStatusLabel = new QLabel("○ Disconnected  |  0 fps  |  0 frames");
  m_liveStatusLabel->setStyleSheet(
      "color: #888; font-size: 11px; padding: 2px 0;");
  lay->addWidget(m_liveStatusLabel);

  // ── Decoded signals table + collapsible raw frames (full height) ──────────
  QLabel *decodedHdr = new QLabel(
      "Decoded Signals  —  drag a row onto a chart window to start plotting");
  decodedHdr->setStyleSheet(
      "font-size: 12px; font-weight: bold; padding: 2px 0;");
  lay->addWidget(decodedHdr);

  m_liveDecodedTable = new SignalDragTable(2 /*Signal column*/);
  m_liveDecodedTable->setColumnCount(4);
  m_liveDecodedTable->setHorizontalHeaderLabels(
      {"Time", "ID", "Signal", "Value"});
  m_liveDecodedTable->verticalHeader()->setVisible(false);
  m_liveDecodedTable->verticalHeader()->setDefaultSectionSize(18);
  m_liveDecodedTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
  m_liveDecodedTable->horizontalHeader()->setStretchLastSection(true);
  m_liveDecodedTable->horizontalHeader()->setDefaultSectionSize(100);
  lay->addWidget(m_liveDecodedTable, 1);

  // ── Double-click on decoded signal → open chart ───────────────────────────
  connect(m_liveDecodedTable, &QTableWidget::cellDoubleClicked, this,
          [this](int row, int /*col*/) {
            QTableWidgetItem *sigItem = m_liveDecodedTable->item(row, 2);
            if (sigItem && !sigItem->text().isEmpty())
              openSignalChart(sigItem->text());
          });

  // ── Right-click context menu → "Open Graph" ───────────────────────────────
  m_liveDecodedTable->setContextMenuPolicy(Qt::CustomContextMenu);
  connect(m_liveDecodedTable, &QWidget::customContextMenuRequested, this,
          [this](const QPoint &pos) {
            QTableWidgetItem *sigItem =
                m_liveDecodedTable->item(m_liveDecodedTable->rowAt(pos.y()), 2);
            if (!sigItem || sigItem->text().isEmpty())
              return;
            QString sigName = sigItem->text();
            QMenu menu(this);
            menu.addAction("Open Graph", this,
                           [this, sigName] { openSignalChart(sigName); });
            menu.exec(m_liveDecodedTable->viewport()->mapToGlobal(pos));
          });

  // ── Drop zone: drag a signal here to open its chart ───────────────────────
  SignalDropZone *dropZone = new SignalDropZone(page);
  connect(dropZone, &SignalDropZone::signalDropped, this,
          &MainWindow::openSignalChart);
  lay->addWidget(dropZone);

  QPushButton *rawToggleBtn = new QPushButton("▶  Raw Frames");
  rawToggleBtn->setCheckable(true);
  rawToggleBtn->setChecked(false);
  rawToggleBtn->setFlat(true);
  rawToggleBtn->setCursor(Qt::PointingHandCursor);
  rawToggleBtn->setStyleSheet(
      "QPushButton { text-align: left; font-size: 11px; font-weight: bold; "
      "              padding: 2px 0; border: none; color: #888; }");
  lay->addWidget(rawToggleBtn);

  m_liveRawTable = new QTableWidget();
  m_liveRawTable->setColumnCount(4);
  m_liveRawTable->setHorizontalHeaderLabels({"Time", "ID", "DLC", "Data"});
  m_liveRawTable->verticalHeader()->setVisible(false);
  m_liveRawTable->verticalHeader()->setDefaultSectionSize(18);
  m_liveRawTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
  m_liveRawTable->horizontalHeader()->setStretchLastSection(true);
  m_liveRawTable->horizontalHeader()->setDefaultSectionSize(100);
  m_liveRawTable->setVisible(false);
  lay->addWidget(m_liveRawTable);

  connect(rawToggleBtn, &QPushButton::toggled, this,
          [this, rawToggleBtn](bool checked) {
            m_liveRawTable->setVisible(checked);
            rawToggleBtn->setText(checked ? "▼  Raw Frames" : "▶  Raw Frames");
          });

  return page;
}

QWidget *MainWindow::buildDecodersPage() {
  QWidget *page = new QWidget();
  QVBoxLayout *lay = new QVBoxLayout(page);
  lay->setContentsMargins(12, 12, 12, 12);
  lay->setSpacing(8);

  // -- Header row --
  QHBoxLayout *headerRow = new QHBoxLayout();
  QLabel *header = new QLabel("Decoders");
  header->setStyleSheet("font-size: 18px; font-weight: bold;");
  headerRow->addWidget(header);
  headerRow->addStretch();
  QPushButton *btnExportDBC = new QPushButton("Export as DBC...");
  connect(btnExportDBC, &QPushButton::clicked, this,
          &MainWindow::exportManualDecodersToDBC);
  headerRow->addWidget(btnExportDBC);
  lay->addLayout(headerRow);

  QLabel *desc =
      new QLabel("Configure byte decoders manually or import from a DBC file.");
  desc->setStyleSheet("color: #888; font-size: 12px; margin-bottom: 8px;");
  desc->setWordWrap(true);
  lay->addWidget(desc);

  // -- Info section --
  m_decoderInfoLabel = new QLabel();
  m_decoderInfoLabel->setAlignment(Qt::AlignCenter);
  m_decoderInfoLabel->setStyleSheet("color: #888; font-size: 13px;");
  updateDBCStatus(); // initialize label text
  lay->addWidget(m_decoderInfoLabel);

  // -- Embed Config Widget --
  m_configWidget = new ConfigWidget(this);
  m_configWidget->setConfigList(m_savedConfigs);
  m_configWidget->setIDList(allKnownIDs());

  connect(m_configWidget, &ConfigWidget::configsUpdated, this,
          [this](const QVector<HexConfig> &configs) {
            m_savedConfigs = configs;
            saveConfigsToFile();
            calculateAndPopulateResultTable();
            updateDBCStatus();
            statusBar()->showMessage("Decoder configurations saved.");
          });

  lay->addWidget(m_configWidget);
  lay->addStretch();
  return page;
}

QWidget *MainWindow::buildGraphPage() {
  QWidget *page = new QWidget();
  QVBoxLayout *mainLay = new QVBoxLayout(page);
  mainLay->setContentsMargins(8, 8, 8, 8);
  mainLay->setSpacing(6);

  // -- Top bar: title + buttons --
  QHBoxLayout *topBar = new QHBoxLayout();
  QLabel *header = new QLabel("Graph");
  header->setStyleSheet("font-size: 18px; font-weight: bold;");
  topBar->addWidget(header);
  topBar->addStretch();

  auto makeBtn = [](const QString &text) -> QPushButton * {
    QPushButton *b = new QPushButton(text);
    b->setMinimumHeight(28);
    b->setCursor(Qt::PointingHandCursor);
    b->setStyleSheet(
        "QPushButton { background: #0078D4; color: #FFF; border: none; "
        "              border-radius: 4px; font-size: 12px; padding: 4px 14px; "
        "}"
        "QPushButton:hover { background: #106EBE; }");
    return b;
  };

  QPushButton *btnRefresh = makeBtn("Generate Plot");
  QPushButton *btnSave = makeBtn("Save Image");
  topBar->addWidget(btnRefresh);
  topBar->addWidget(btnSave);
  mainLay->addLayout(topBar);

  // -- Content: settings panel (left) + chart (right) --
  QSplitter *splitter = new QSplitter(Qt::Horizontal, page);

  // ── Left: Signal settings panel ──
  QWidget *settingsPanel = new QWidget();
  settingsPanel->setMinimumWidth(220);
  settingsPanel->setMaximumWidth(320);
  QVBoxLayout *settingsLay = new QVBoxLayout(settingsPanel);
  settingsLay->setContentsMargins(4, 4, 4, 4);
  settingsLay->setSpacing(4);

  QLabel *sigLabel = new QLabel("Signals");
  sigLabel->setStyleSheet(
      "font-size: 13px; font-weight: bold; margin-bottom: 4px;");
  settingsLay->addWidget(sigLabel);

  // Select All / Unselect All buttons
  QHBoxLayout *selRow = new QHBoxLayout();
  selRow->setSpacing(4);
  auto makeMiniBtn = [](const QString &text) -> QPushButton * {
    QPushButton *b = new QPushButton(text);
    b->setFixedHeight(22);
    b->setCursor(Qt::PointingHandCursor);
    b->setStyleSheet(
        "QPushButton { background: #3A3A3A; color: #CCC; border: 1px solid "
        "#555; "
        "              border-radius: 3px; font-size: 10px; padding: 1px 8px; }"
        "QPushButton:hover { background: #505050; }");
    return b;
  };
  QPushButton *btnSelectAll = makeMiniBtn("Select All");
  QPushButton *btnUnselectAll = makeMiniBtn("Unselect All");
  selRow->addWidget(btnSelectAll);
  selRow->addWidget(btnUnselectAll);
  selRow->addStretch();
  settingsLay->addLayout(selRow);

  connect(btnSelectAll, &QPushButton::clicked, this, [this] {
    for (GraphSeriesConfig &c : m_graphSeriesConfigs)
      c.enabled = true;
    refreshGraphSignalList();
  });
  connect(btnUnselectAll, &QPushButton::clicked, this, [this] {
    for (GraphSeriesConfig &c : m_graphSeriesConfigs)
      c.enabled = false;
    refreshGraphSignalList();
  });

  // Scrollable signal list
  QScrollArea *scrollArea = new QScrollArea();
  scrollArea->setWidgetResizable(true);
  scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
  scrollArea->setFrameShape(QFrame::NoFrame);

  QWidget *scrollContent = new QWidget();
  m_graphSignalListLayout = new QVBoxLayout(scrollContent);
  m_graphSignalListLayout->setContentsMargins(0, 0, 0, 0);
  m_graphSignalListLayout->setSpacing(2);
  m_graphSignalListLayout->addStretch();

  scrollArea->setWidget(scrollContent);
  settingsLay->addWidget(scrollArea, 1);

  splitter->addWidget(settingsPanel);

  // ── Right: Chart view ──
  m_chartView = new QChartView();
  m_chartView->setRenderHint(QPainter::Antialiasing);

  QChart *emptyChart = new QChart();
  emptyChart->setTitle("Load data and configure decoders to see the plot.");
  emptyChart->legend()->hide();
  m_chartView->setChart(emptyChart);

  splitter->addWidget(m_chartView);
  splitter->setStretchFactor(0, 0); // settings panel: don't stretch
  splitter->setStretchFactor(1, 1); // chart: stretch to fill
  splitter->setSizes({240, 600});

  mainLay->addWidget(splitter, 1);

  // -- Connections --
  connect(btnRefresh, &QPushButton::clicked, this,
          &MainWindow::on_btn_graph_clicked);
  connect(btnSave, &QPushButton::clicked, this, [this] {
    if (!m_chartView)
      return;
    QString p = QFileDialog::getSaveFileName(this, "Save Image", "",
                                             "PNG (*.png);;JPEG (*.jpg)");
    if (!p.isEmpty()) {
      m_chartView->grab().save(p);
      statusBar()->showMessage("Graph saved: " + p);
    }
  });

  return page;
}

// ─────────────────────────────────────────────────────────────────────────────
// Build/refresh the signal list in the Graph settings panel.
// Called before plotting to discover available decoded signal names.
// ─────────────────────────────────────────────────────────────────────────────
// ═════════════════════════════════════════════════════════════════════════════
//  Live Monitor — slots & helpers
// ═════════════════════════════════════════════════════════════════════════════

void MainWindow::onSerialLineReceived(const QString &csvLine) {
  m_livePendingLines.append(csvLine); // buffered; processed by batch timer
}

void MainWindow::onSerialConnChanged(bool connected) {
  m_liveConnected = connected;
  if (m_liveConnectBtn)
    m_liveConnectBtn->setText(connected ? "Disconnect" : "Connect");
  if (!connected) {
    m_liveTotalFrames = 0;
    m_liveFps = 0;
    m_liveSeenIds.clear();
    // Table kept visible so user can review last values after disconnect
  }
  updateLiveStatus();
  statusBar()->showMessage(connected ? "Live: connected."
                                     : "Live: disconnected.");
}

void MainWindow::onSerialError(const QString &msg) {
  statusBar()->showMessage("Serial error: " + msg);
}

void MainWindow::onSerialStats(int fps) {
  m_liveFps = fps;
  updateLiveStatus();
}

void MainWindow::updateLiveStatus() {
  if (!m_liveStatusLabel)
    return;
  QString dot = m_liveConnected ? "● Connected" : "○ Disconnected";
  m_liveStatusLabel->setText(QString("%1  |  %2 fps  |  %3 frames")
                                 .arg(dot)
                                 .arg(m_liveFps)
                                 .arg(m_liveTotalFrames));
}

// ─────────────────────────────────────────────────────────────────────────────
//  onLiveBatchTimer — called every 50 ms; processes pending serial lines
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onLiveBatchTimer() {
  if (m_livePendingLines.isEmpty())
    return;

  // MED-2: drop oldest lines if buffer grew too large between ticks
  while (m_livePendingLines.size() > MAX_PENDING_LINES)
    m_livePendingLines.removeFirst();

  QStringList batch = std::move(m_livePendingLines);
  m_liveTotalFrames += batch.size();

  if (!m_liveRawTable || !m_liveDecodedTable)
    return;

  m_liveRawTable->setUpdatesEnabled(false);
  m_liveDecodedTable->setUpdatesEnabled(false);

  // Pre-normalise config IDs once per batch
  QVector<quint32> confNormIds;
  confNormIds.reserve(m_savedConfigs.size());
  for (const HexConfig &c : m_savedConfigs)
    confNormIds.append(normaliseCanId(c.targetID));

  for (const QString &csvLine : batch) {
    const auto parts = QStringView(csvLine).split(u',');
    if (parts.size() < 8)
      continue;

    RawData rd;
    rd.isoTime = parts[0].trimmed().toString();
    rd.timestamp = parts[1].trimmed().toLongLong();
    rd.id = parts[4].trimmed().toString();
    rd.dataHex = parts[7].trimmed().toString();
    rd.numericId = normaliseCanId(rd.id);
    rd.cleanHex = rd.dataHex.simplified().replace(" ", "");
    m_liveSeenIds.insert(rd.numericId); // track for late DBC load

    // ── Raw table (cap at 2000 rows) ─────────────────────────────────────
    if (m_liveRawTable->rowCount() >= 2000)
      m_liveRawTable->removeRow(0);
    int rr = m_liveRawTable->rowCount();
    m_liveRawTable->insertRow(rr);
    m_liveRawTable->setItem(rr, 0, new QTableWidgetItem(rd.isoTime));
    m_liveRawTable->setItem(rr, 1, new QTableWidgetItem(rd.id));
    m_liveRawTable->setItem(
        rr, 2, new QTableWidgetItem(QString::number(rd.cleanHex.length() / 2)));
    m_liveRawTable->setItem(rr, 3, new QTableWidgetItem(rd.dataHex.trimmed()));

    // ── Per-ID message rate counter ──────────────────────────────────────
    m_liveMsgRateCurrent[rd.id]++;

    // ── Decode signals ───────────────────────────────────────────────────
    for (int ci = 0; ci < m_savedConfigs.size(); ++ci) {
      if (confNormIds[ci] != rd.numericId)
        continue;

      const HexConfig &conf = m_savedConfigs[ci];
      double rawVal = 0.0;

      if (conf.isDBC) {
        if (!extractDbcSignalRaw(rd.cleanHex, conf.startBit, conf.bitLength,
                                 conf.littleEndian, conf.isSigned, rawVal))
          continue;
      } else {
        int sp = conf.startByte * 2;
        int sl = (conf.endByte - conf.startByte + 1) * 2;
        if (sp + sl > rd.cleanHex.length())
          continue;
        bool ok;
        rawVal = (double)rd.cleanHex.mid(sp, sl).toLongLong(&ok, 16);
        if (!ok)
          continue;
      }
      double finalVal = evaluateFormula(rawVal, conf.formula);

      // Decoded table: one row per signal (grouped by CAN ID), updated in place
      QString key = rd.id + "|" + conf.name;
      int dr;
      if (!m_decodedTableRowMap.contains(key)) {
        dr = m_liveDecodedTable->rowCount();
        m_liveDecodedTable->insertRow(dr);
        m_liveDecodedTable->setItem(dr, 1, new QTableWidgetItem(rd.id));
        m_liveDecodedTable->setItem(dr, 2, new QTableWidgetItem(conf.name));
        m_decodedTableRowMap[key] = dr;
      } else {
        dr = m_decodedTableRowMap[key];
      }
      m_liveDecodedTable->setItem(dr, 0, new QTableWidgetItem(rd.isoTime));
      QTableWidgetItem *valItem =
          new QTableWidgetItem(QString::number(finalVal, 'f', 4));
      valItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
      m_liveDecodedTable->setItem(dr, 3, valItem);

      // Gauge
      updateLiveGauge(conf.name, finalVal);

      // Push to charts that track this signal
      for (DroppableChartView *cv : m_liveCharts)
        if (cv->trackedSignals().contains(conf.name))
          cv->appendData(conf.name, rd.timestamp, finalVal);
    }
  }

  m_liveRawTable->setUpdatesEnabled(true);
  m_liveDecodedTable->setUpdatesEnabled(true);
  m_liveRawTable->scrollToBottom();
  updateLiveStatus();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::updateLiveGauge(const QString &name, double value) {
  if (!m_liveGaugesContent)
    return;

  if (!m_gaugeProgressBars.contains(name)) {
    QWidget *row = new QWidget(m_liveGaugesContent);
    QHBoxLayout *rl = new QHBoxLayout(row);
    rl->setContentsMargins(2, 1, 2, 1);
    rl->setSpacing(4);

    QLabel *nameLabel = new QLabel(name + ":");
    nameLabel->setFixedWidth(120);
    nameLabel->setStyleSheet("font-size: 11px;");

    QProgressBar *bar = new QProgressBar();
    bar->setRange(0, 1000);
    bar->setValue(0);
    bar->setTextVisible(false);
    bar->setFixedWidth(120);
    bar->setFixedHeight(14);

    QLabel *valLabel = new QLabel("—");
    valLabel->setFixedWidth(80);
    valLabel->setStyleSheet("font-size: 11px;");

    rl->addWidget(nameLabel);
    rl->addWidget(bar);
    rl->addWidget(valLabel);
    rl->addStretch();

    auto *vlay = qobject_cast<QVBoxLayout *>(m_liveGaugesContent->layout());
    vlay->insertWidget(vlay->count() - 1, row); // before the stretch

    m_gaugeProgressBars[name] = bar;
    m_gaugeValueLabels[name] = valLabel;
    m_gaugeRanges[name] = {value, value};
  }

  auto &range = m_gaugeRanges[name];
  range.first = qMin(range.first, value);
  range.second = qMax(range.second, value);

  double lo = range.first, hi = range.second;
  int barVal = (hi > lo) ? (int)(1000.0 * (value - lo) / (hi - lo)) : 500;
  m_gaugeProgressBars[name]->setValue(qBound(0, barVal, 1000));
  m_gaugeValueLabels[name]->setText(QString::number(value, 'f', 3));
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onLiveMsgRateTimer() {
  if (!m_liveMsgRateTable)
    return;
  m_liveMsgRateTable->setRowCount(0);
  for (auto it = m_liveMsgRateCurrent.cbegin();
       it != m_liveMsgRateCurrent.cend(); ++it) {
    int row = m_liveMsgRateTable->rowCount();
    m_liveMsgRateTable->insertRow(row);
    m_liveMsgRateTable->setItem(row, 0, new QTableWidgetItem(it.key()));
    QTableWidgetItem *fpsItem =
        new QTableWidgetItem(QString::number(it.value()) + " fps");
    fpsItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
    m_liveMsgRateTable->setItem(row, 1, fpsItem);
  }
  m_liveMsgRateCurrent.clear();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onLiveConnectClicked() {
  if (!m_liveConnected) {
    // Offer to load a DBC if no decoders are configured yet
    if (m_loadedDbcFile.isEmpty()) {
      int choice = QMessageBox::question(
          this, "No DBC Loaded",
          "No DBC file is loaded \u2014 only raw CAN frames will be "
          "visible.\n\n"
          "Load a DBC file now to decode signals as they arrive?",
          QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel,
          QMessageBox::Yes);
      if (choice == QMessageBox::Cancel)
        return;
      if (choice == QMessageBox::Yes)
        onLoadDBC();
    }

    m_liveSeenIds.clear();

    QString proto =
        m_liveProtoCombo ? m_liveProtoCombo->currentText() : "SLCAN";

    if (proto == "PCAN-USB") {
      QString plugin =
          m_canPluginCombo ? m_canPluginCombo->currentText() : QString();
      QString iface =
          m_canInterfaceCombo ? m_canInterfaceCombo->currentText() : QString();
      int bitrate =
          m_canBitrateCombo ? m_canBitrateCombo->currentText().toInt() : 500000;
      if (plugin.isEmpty() || iface.isEmpty()) {
        statusBar()->showMessage("No CAN plugin or interface selected.");
        return;
      }
      m_canBusWorker->connectDevice(plugin, iface, bitrate);
    } else {
      // SLCAN or UART
      QString port =
          m_livePortCombo ? m_livePortCombo->currentText() : QString();
      int baud =
          m_liveBaudCombo ? m_liveBaudCombo->currentText().toInt() : 115200;
      QString serialProto = (proto == "UART") ? "UART" : "CAN_SLCAN";
      if (port.isEmpty()) {
        statusBar()->showMessage("No serial port selected.");
        return;
      }
      m_serialWorker->connectPort(port, baud, serialProto);
    }
  } else {
    m_serialWorker->disconnectPort();
    m_canBusWorker->disconnectDevice();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onAddChartClicked() {
  openSignalChart(); // open an empty chart window
}

// ─────────────────────────────────────────────────────────────────────────────
//  openSignalChart — create a floating live chart window, optionally
//  pre-populated with the given signal.
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::openSignalChart(const QString &signalName) {
  // Create a floating window parented to MainWindow so it closes with the app
  QWidget *win = new QWidget(this, Qt::Window);
  win->setWindowTitle(
      signalName.isEmpty()
          ? QStringLiteral("Live Chart")
          : QStringLiteral("Live Chart \u2014 %1").arg(signalName));
  win->setAttribute(Qt::WA_DeleteOnClose);
  win->resize(800, 450);

  QVBoxLayout *wl = new QVBoxLayout(win);
  wl->setContentsMargins(4, 4, 4, 4);
  wl->setSpacing(2);

  // Toolbar row
  QHBoxLayout *tbRow = new QHBoxLayout();

  QPushButton *liveBtn = new QPushButton("\u23FA Live");
  liveBtn->setCheckable(true);
  liveBtn->setChecked(true);
  liveBtn->setToolTip("Toggle live scrolling mode");
  liveBtn->setStyleSheet("font-size: 10px; padding: 1px 8px; border: 1px "
                         "solid #555; border-radius: 3px;");
  tbRow->addWidget(liveBtn);
  tbRow->addStretch();

  QPushButton *exportBtn = new QPushButton("Export PNG");
  exportBtn->setToolTip("Save chart as PNG image");
  exportBtn->setStyleSheet("font-size: 10px; padding: 1px 8px; border: 1px "
                           "solid #555; border-radius: 3px;");

  QPushButton *clearBtn = new QPushButton("Clear");
  clearBtn->setStyleSheet("font-size: 10px; padding: 1px 8px; border: 1px "
                          "solid #555; border-radius: 3px;");
  tbRow->addWidget(exportBtn);
  tbRow->addWidget(clearBtn);
  wl->addLayout(tbRow);

  DroppableChartView *cv = new DroppableChartView(win);
  wl->addWidget(cv, 1);

  // Pre-populate with the requested signal
  if (!signalName.isEmpty())
    cv->addSignal(signalName);

  m_liveCharts.append(cv);

  // Clean up tracking when the window (and cv as its child) is destroyed
  connect(cv, &QObject::destroyed, this,
          [this, cv]() { m_liveCharts.removeOne(cv); });

  connect(liveBtn, &QPushButton::toggled, cv, &DroppableChartView::setLiveMode);
  connect(clearBtn, &QPushButton::clicked, cv, &DroppableChartView::clearAll);
  connect(exportBtn, &QPushButton::clicked, this, [this, cv]() {
    QString path =
        QFileDialog::getSaveFileName(this, "Export Chart",
                                     QDateTime::currentDateTime().toString(
                                         "'chart_'yyyy-MM-dd_HH-mm-ss'.png'"),
                                     "PNG Images (*.png);;All Files (*)");
    if (!path.isEmpty()) {
      constexpr int W = 1280, H = 720;
      QPixmap px(W, H);
      px.fill(cv->palette().color(QPalette::Window));
      QPainter painter(&px);
      painter.setRenderHint(QPainter::Antialiasing);
      cv->chart()->scene()->render(&painter, QRectF(0, 0, W, H),
                                   cv->chart()->scene()->sceneRect());
      painter.end();
      px.save(path);
      statusBar()->showMessage("Chart exported: " + path);
    }
  });

  win->show();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onSimToggled() {
  if (!m_liveSimActive) {
    // ── Step 1: optionally load a DBC if none is loaded ───────────────────
    if (m_loadedDbcFile.isEmpty()) {
      int choice = QMessageBox::question(
          this, "Load DBC for Decoding?",
          "No DBC file is loaded.\n\n"
          "Without a DBC, only raw frames will be visible.\n"
          "Load a DBC file now to also decode signals?",
          QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel,
          QMessageBox::Yes);
      if (choice == QMessageBox::Cancel)
        return;
      if (choice == QMessageBox::Yes) {
        QString dbcPath = QFileDialog::getOpenFileName(
            this, "Open DBC File", QString(), "DBC Files (*.dbc)");
        if (!dbcPath.isEmpty()) {
          if (m_dbcParser.parse(dbcPath)) {
            m_loadedDbcFile = dbcPath;
            updateDBCStatus();
          } else {
            QMessageBox::warning(this, "DBC Error", m_dbcParser.errorString());
          }
        }
      }
    }

    // ── Step 2: pick the CAN log CSV file ─────────────────────────────────
    QString file = QFileDialog::getOpenFileName(
        this, "Open CAN log for simulation", QString(), "CSV Files (*.csv)");
    if (file.isEmpty())
      return; // cancelled

    QFile f(file);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) {
      statusBar()->showMessage("Cannot open file: " + file);
      return;
    }
    QTextStream in(&f);
    m_liveSimLines.clear();
    in.readLine(); // skip header row
    while (!in.atEnd()) {
      QString line = in.readLine().trimmed();
      if (!line.isEmpty())
        m_liveSimLines.append(line);
    }
    if (m_liveSimLines.isEmpty()) {
      statusBar()->showMessage("No data lines found in CSV.");
      return;
    }
    m_liveSimLineIdx = 0;
    m_liveTotalFrames = 0;

    // ── Step 3: auto-import DBC signals matching IDs found in the CSV ─────
    if (!m_loadedDbcFile.isEmpty() && !m_dbcParser.messages().isEmpty()) {
      // Collect unique CAN IDs from the first pass of the sim lines
      QSet<quint32> simIds;
      for (const QString &ln : m_liveSimLines) {
        const auto parts = QStringView(ln).split(u',');
        if (parts.size() >= 5)
          simIds.insert(normaliseCanId(parts[4].trimmed().toString()));
      }
      // Remove stale DBC configs, then import matches
      for (int i = m_savedConfigs.size() - 1; i >= 0; --i)
        if (m_savedConfigs[i].isDBC)
          m_savedConfigs.removeAt(i);
      for (const DBCMessage &msg : m_dbcParser.messages()) {
        if (!simIds.contains(msg.rawCanId))
          continue;
        for (const DBCSignal &sig : msg.sigs) {
          HexConfig conf;
          conf.targetID = msg.hexID();
          conf.name = sig.name;
          conf.formula = sig.toFormula();
          conf.isDBC = true;
          conf.startBit = sig.startBit;
          conf.bitLength = sig.length;
          conf.littleEndian = sig.littleEndian;
          conf.isSigned = sig.isSigned;
          conf.startByte = sig.startByte();
          conf.endByte = sig.endByte();
          bool dup = false;
          for (const HexConfig &c : m_savedConfigs)
            if (c.name == conf.name &&
                normaliseCanId(c.targetID) == normaliseCanId(conf.targetID)) {
              dup = true;
              break;
            }
          if (!dup)
            m_savedConfigs.append(conf);
        }
      }
      saveConfigsToFile();
      if (m_configWidget)
        m_configWidget->setConfigList(m_savedConfigs);
      updateDBCStatus();
    }

    m_liveSimActive = true;
    if (m_liveSimBtn)
      m_liveSimBtn->setText("■ Stop Sim");
    if (m_liveConnectBtn)
      m_liveConnectBtn->setEnabled(false);
    m_liveSimTimer->start();
    if (m_liveStatusLabel)
      m_liveStatusLabel->setText("⬤ Simulating  |  0 frames");
  } else {
    m_liveSimActive = false;
    m_liveSimTimer->stop();
    m_liveSimLines.clear();
    // Table kept visible so user can review last values after simulation stops
    if (m_liveSimBtn)
      m_liveSimBtn->setText("⏯ Simulate");
    if (m_liveConnectBtn)
      m_liveConnectBtn->setEnabled(true);
    updateLiveStatus();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Replay ~10 CSV lines per tick (100ms timer → ~100 frames/sec).
//  Timestamps are replaced with "now" so the rolling chart window stays
//  current.
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onSimTick() {
  if (m_liveSimLines.isEmpty())
    return;

  qint64 now = QDateTime::currentMSecsSinceEpoch();
  QString isoNow =
      QDateTime::fromMSecsSinceEpoch(now).toString("yyyy-MM-dd HH:mm:ss.zzz");
  QString epochNow = QString::number(now);

  // Send 10 lines per 100 ms tick
  for (int i = 0; i < 10; ++i) {
    const QString &orig = m_liveSimLines.at(m_liveSimLineIdx);
    m_liveSimLineIdx = (m_liveSimLineIdx + 1) % m_liveSimLines.size();

    // Replace parts[0] (isoTime) and parts[1] (epoch_ms) with current time
    // so the chart's 30-second rolling window shows the data
    int c1 = orig.indexOf(',');
    if (c1 < 0)
      continue;
    int c2 = orig.indexOf(',', c1 + 1);
    if (c2 < 0)
      continue;
    // Build: isoNow + ',' + epochNow + rest_from_second_comma
    QString line = isoNow + ',' + epochNow + orig.mid(c2);
    onSerialLineReceived(line);
  }

  if (m_liveStatusLabel) {
    m_liveStatusLabel->setText(
        QString("⬤ Simulating  |  %1 frames").arg(m_liveTotalFrames));
  }
}

// ─────────────────────────────────────────────────────────────────────────────

static const QColor kDefaultColors[] = {
    QColor("#0078D4"), QColor("#E81123"), QColor("#107C10"), QColor("#FF8C00"),
    QColor("#5C2D91"), QColor("#008272"), QColor("#D13438"), QColor("#0063B1"),
    QColor("#767676"), QColor("#C239B3"),
};

void MainWindow::refreshGraphSignalList() {
  if (!m_graphSignalListLayout)
    return;

  // Collect unique signal names from the result model
  QSet<QString> signalSet;
  for (int i = 0; i < m_resultModel->rowCount(); ++i) {
    signalSet.insert(m_resultModel->item(i, 2)->text());
  }
  QStringList signalNames = signalSet.values();
  signalNames.sort();

  // Preserve existing configs, add new ones, remove stale ones
  QMap<QString, GraphSeriesConfig> existing;
  for (const GraphSeriesConfig &c : m_graphSeriesConfigs)
    existing[c.name] = c;

  m_graphSeriesConfigs.clear();
  int colorIdx = 0;
  for (const QString &name : signalNames) {
    if (existing.contains(name)) {
      m_graphSeriesConfigs.append(existing[name]);
    } else {
      GraphSeriesConfig cfg;
      cfg.name = name;
      cfg.enabled = true;
      cfg.color = kDefaultColors[colorIdx % 10];
      cfg.style = 0;
      m_graphSeriesConfigs.append(cfg);
    }
    ++colorIdx;
  }

  // Clear existing UI rows
  QLayoutItem *child;
  while ((child = m_graphSignalListLayout->takeAt(0)) != nullptr) {
    if (child->widget()) {
      child->widget()->deleteLater();
    }
    delete child;
  }

  // Build UI rows for each signal
  for (int i = 0; i < m_graphSeriesConfigs.size(); ++i) {
    GraphSeriesConfig &cfg = m_graphSeriesConfigs[i];

    QWidget *row = new QWidget();
    QHBoxLayout *rowLay = new QHBoxLayout(row);
    rowLay->setContentsMargins(2, 1, 2, 1);
    rowLay->setSpacing(4);

    // Checkbox (enable/disable)
    QCheckBox *chk = new QCheckBox(cfg.name);
    chk->setChecked(cfg.enabled);
    chk->setStyleSheet("font-size: 11px;");
    connect(chk, &QCheckBox::toggled, this, [this, i](bool checked) {
      if (i < m_graphSeriesConfigs.size())
        m_graphSeriesConfigs[i].enabled = checked;
    });
    rowLay->addWidget(chk, 1);

    // Color button
    QPushButton *colorBtn = new QPushButton();
    colorBtn->setFixedSize(20, 20);
    colorBtn->setCursor(Qt::PointingHandCursor);
    colorBtn->setStyleSheet(
        QString("background: %1; border: 1px solid #888; border-radius: 3px;")
            .arg(cfg.color.name()));
    connect(colorBtn, &QPushButton::clicked, this, [this, i, colorBtn] {
      if (i >= m_graphSeriesConfigs.size())
        return;
      QColor c = QColorDialog::getColor(m_graphSeriesConfigs[i].color, this,
                                        "Signal Color");
      if (c.isValid()) {
        m_graphSeriesConfigs[i].color = c;
        colorBtn->setStyleSheet(QString("background: %1; border: 1px "
                                        "solid #888; border-radius: 3px;")
                                    .arg(c.name()));
      }
    });
    rowLay->addWidget(colorBtn);

    // Style combo
    QComboBox *styleCombo = new QComboBox();
    styleCombo->addItems({"Solid", "Dash", "Scatter"});
    styleCombo->setCurrentIndex(cfg.style);
    styleCombo->setFixedWidth(70);
    styleCombo->setStyleSheet("font-size: 10px;");
    connect(styleCombo, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, [this, i](int idx) {
              if (i < m_graphSeriesConfigs.size())
                m_graphSeriesConfigs[i].style = idx;
            });
    rowLay->addWidget(styleCombo);

    m_graphSignalListLayout->addWidget(row);
  }
  m_graphSignalListLayout->addStretch();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::setupTables() {
  ui->tbl_summary->setModel(m_summaryModel);
  ui->tbl_summary->setEditTriggers(QAbstractItemView::NoEditTriggers);
  ui->tbl_summary->verticalHeader()->setVisible(false);
  ui->tbl_summary->verticalHeader()->setDefaultSectionSize(20);
  ui->tbl_summary->setSelectionMode(QAbstractItemView::SingleSelection);

  QHeaderView *sh = ui->tbl_summary->horizontalHeader();
  sh->setHighlightSections(false);
  sh->setStretchLastSection(true);
  sh->setSectionResizeMode(QHeaderView::Interactive);
  sh->setDefaultSectionSize(90);

  ui->tbl_result->setModel(m_resultModel);
  ui->tbl_result->setEditTriggers(QAbstractItemView::NoEditTriggers);
  ui->tbl_result->verticalHeader()->setVisible(false);
  ui->tbl_result->verticalHeader()->setDefaultSectionSize(20);
  ui->tbl_result->setSelectionMode(QAbstractItemView::SingleSelection);

  QHeaderView *rh = ui->tbl_result->horizontalHeader();
  rh->setHighlightSections(false);
  rh->setStretchLastSection(true);
  rh->setSectionResizeMode(QHeaderView::Interactive);
  rh->setDefaultSectionSize(110);
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::resizeEvent(QResizeEvent *event) {
  QMainWindow::resizeEvent(event);
  resizeSplitterAndColumns();
}

void MainWindow::resizeSplitterAndColumns() {
  int total = ui->splitter_main->width();
  if (total > 100) {
    int half = (total - ui->splitter_main->handleWidth()) / 2;
    ui->splitter_main->setSizes({half, half});
  }

  // Auto-fit columns to content, last column stretches to fill
  if (m_summaryModel->rowCount() > 0) {
    ui->tbl_summary->resizeColumnsToContents();
  }
  // Remove slow ui->tbl_result->resizeColumnsToContents() for thousands
  // of rows

  // Automatically refresh graph signal list now that tabular data is
  // loaded
  refreshGraphSignalList();
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::setInterfaceState(bool hasData) {
  m_actUnload->setEnabled(hasData);
  m_actFilter->setEnabled(hasData);
  m_actReset->setEnabled(hasData);
  m_actConf->setEnabled(hasData);
  m_actGraph->setEnabled(hasData);
  m_actExportCsv->setEnabled(hasData);
  m_actExportData->setEnabled(hasData);
  ui->action_unload->setEnabled(hasData);
  ui->action_filter->setEnabled(hasData);
  ui->action_reset->setEnabled(hasData);
  ui->action_conf->setEnabled(hasData);
  ui->action_graph->setEnabled(hasData);
  ui->action_export_csv->setEnabled(hasData);
  ui->action_export_data->setEnabled(hasData);

  // Toggle CSV page: show empty state or data tables
  if (m_csvEmptyState)
    m_csvEmptyState->setVisible(!hasData);

  // Toggle Decoder guidance visually in the right table (result)
  // If we have data, but no rows could be decoded (because no configs or
  // no matches)
  bool showGuide = hasData && (m_resultModel->rowCount() == 0);
  ui->tbl_result->setVisible(!showGuide);
  ui->lbl_result_header->setVisible(!showGuide);
  if (m_csvDecoderGuide)
    m_csvDecoderGuide->setVisible(showGuide);

  if (ui->splitter_main)
    ui->splitter_main->setVisible(hasData);
}

void MainWindow::applyTheme(bool dark) {
  m_isDark = dark;
  if (dark)
    buildDarkPalette(qApp);
  else
    buildLightPalette(qApp);
  setStyleSheet(QSS_COMMON);
}

// ─────────────────────────────────────────────────────────────────────────────
//  ID normalisation: convert any hex/decimal string to uint32 for comparison.
//  Handles: "0x00C", "0x0C", "12", "00C" (bare hex)
// ─────────────────────────────────────────────────────────────────────────────
static quint32 normaliseCanId(const QString &s) {
  QString t = s.trimmed();
  if (t.startsWith("0x") || t.startsWith("0X"))
    return t.mid(2).toUInt(nullptr, 16);
  bool ok = false;
  quint32 v = t.toUInt(&ok, 10);
  if (ok)
    return v;
  // bare hex without prefix (e.g. "00C")
  return t.toUInt(nullptr, 16);
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::parseAndStoreLine(const QString &line) {
  // Use QStringView-based split to avoid temporary QString allocations
  const auto parts = QStringView(line).split(u',');
  if (parts.size() < 8)
    return;
  RawData data;
  data.isoTime = parts[0].trimmed().toString();
  data.timestamp = parts[1].trimmed().toLongLong();
  data.id = parts[4].trimmed().toString();
  data.dataHex = parts[7].trimmed().toString();
  data.numericId = normaliseCanId(data.id);
  data.cleanHex = data.dataHex.simplified().replace(" ", "");
  m_allData.append(data);
}

void MainWindow::populateSummaryTable(const QStringList &filterIds) {
  m_summaryModel->blockSignals(true);
  m_summaryModel->clear();
  m_summaryModel->setHorizontalHeaderLabels(
      {"ID", "Count", "First Seen", "Last Seen"});

  struct GroupInfo {
    int count = 0;
    qint64 minEpoch = -1, maxEpoch = -1;
    QString startTime, endTime;
  };
  QHash<QString, GroupInfo> groups;
  groups.reserve(64);

  const bool hasFilter = !filterIds.isEmpty();
  QSet<QString> filterSet;
  if (hasFilter)
    filterSet = QSet<QString>(filterIds.begin(), filterIds.end());

  m_configWidget->setConfigList(m_savedConfigs);
  calculateAndPopulateResultTable();

  for (const RawData &row : m_allData) {
    if (hasFilter && !filterSet.contains(row.id))
      continue;
    GroupInfo &g = groups[row.id];
    g.count++;
    if (g.minEpoch == -1 || row.timestamp < g.minEpoch) {
      g.minEpoch = row.timestamp;
      g.startTime = row.isoTime;
    }
    if (g.maxEpoch == -1 || row.timestamp > g.maxEpoch) {
      g.maxEpoch = row.timestamp;
      g.endTime = row.isoTime;
    }
  }

  m_summaryModel->setRowCount(groups.size());
  int row = 0;
  for (auto it = groups.begin(); it != groups.end(); ++it, ++row) {
    m_summaryModel->setItem(row, 0, new QStandardItem(it.key()));
    auto *countItem = new QStandardItem(QString::number(it.value().count));
    countItem->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
    m_summaryModel->setItem(row, 1, countItem);
    m_summaryModel->setItem(row, 2, new QStandardItem(it.value().startTime));
    m_summaryModel->setItem(row, 3, new QStandardItem(it.value().endTime));
  }
  m_summaryModel->blockSignals(false);
  m_summaryModel->layoutChanged();
  resizeSplitterAndColumns();
}

// ─────────────────────────────────────────────────────────────────────────────
//  extractDbcSignalRaw()
//
//  Extracts a DBC signal value from an 8-byte CAN payload stored as a hex
//  string (e.g. "DEADBEEF01234567", spaces already removed).
//
//  Intel / little-endian (@1):
//    startBit = position of the LSB. Bits are numbered 0..63 as
//    byte0[0..7], byte1[8..15], ...
//
//  Motorola / big-endian (@0):
//    startBit = position of the MSB using the DBC Motorola numbering:
//    within each byte, bit 7 is the MSB.  Conversion to a linear bit
//    position: linear = (startBit / 8) * 8 + (7 - (startBit % 8))
// ─────────────────────────────────────────────────────────────────────────────
static bool extractDbcSignalRaw(const QString &hexPayload, int startBit,
                                int bitLength, bool littleEndian, bool isSigned,
                                double &outValue) {
  // LOW-3: bounds check on bitLength
  if (bitLength <= 0 || bitLength > 64)
    return false;

  // Build a 64-bit value from the hex payload (up to 8 bytes = 16 hex
  // chars)
  QString padded =
      hexPayload.leftJustified(16, '0', true); // pad/trim to 16 chars
  bool ok = false;

  // Load bytes individually so byte order is unambiguous
  quint8 bytes[8] = {};
  for (int i = 0; i < 8; ++i) {
    bytes[i] = padded.mid(i * 2, 2).toUInt(&ok, 16);
    if (!ok)
      return false;
  }

  quint64 rawBits = 0;

  if (littleEndian) {
    // Intel: assemble as little-endian 64-bit word
    for (int i = 0; i < 8; ++i)
      rawBits |= (quint64)bytes[i] << (i * 8);

    quint64 mask = (bitLength < 64) ? ((1ULL << bitLength) - 1) : ~0ULL;
    rawBits = (rawBits >> startBit) & mask;
  } else {
    // Motorola: convert DBC MSB bit number to a linear position
    int byteIdx = startBit / 8;
    int bitIdx = 7 - (startBit % 8); // within-byte MSB position
    int linMSB = byteIdx * 8 + bitIdx;

    // Collect bits from MSB downwards
    rawBits = 0;
    for (int i = 0; i < bitLength; ++i) {
      int lin = linMSB - i;
      int byt = lin / 8;
      int bit = lin % 8; // within-byte, 0=LSB
      if (byt < 0 || byt > 7)
        return false;
      if (bytes[byt] & (1 << bit))
        rawBits |= (1ULL << (bitLength - 1 - i));
    }
  }

  // Sign extension
  if (isSigned && bitLength > 0 && bitLength < 64) {
    quint64 signBit = 1ULL << (bitLength - 1);
    if (rawBits & signBit) {
      // extend sign
      rawBits |= ~((1ULL << bitLength) - 1);
    }
    outValue = (double)(qint64)rawBits;
  } else {
    outValue = (double)rawBits;
  }

  return true;
}

// Returns {factor, offset} parsed from a simple linear formula like "x * 0.1 +
// 5". Falls back to {1, 0} for complex expressions.
static std::pair<double, double> parseLinearFormula(const QString &formula) {
  QString f = formula.trimmed();
  // x * factor + offset  /  x * factor - offset  /  x * factor
  QRegularExpression reMul(
      R"(^x\s*\*\s*([\d.eE+\-]+)\s*(?:([+\-])\s*([\d.eE+\-]+))?$)");
  auto m = reMul.match(f);
  if (m.hasMatch()) {
    double factor = m.captured(1).toDouble();
    double offset = m.captured(3).isEmpty() ? 0.0 : m.captured(3).toDouble();
    if (m.captured(2) == "-")
      offset = -offset;
    return std::make_pair(factor, offset);
  }
  // x + offset  /  x - offset
  QRegularExpression reAdd(R"(^x\s*([+\-])\s*([\d.eE+\-]+)$)");
  m = reAdd.match(f);
  if (m.hasMatch()) {
    double offset = m.captured(2).toDouble();
    if (m.captured(1) == "-")
      offset = -offset;
    return std::make_pair(1.0, offset);
  }
  if (f == "x")
    return std::make_pair(1.0, 0.0);
  return std::make_pair(1.0, 0.0); // fallback for complex formulas
}

// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::calculateAndPopulateResultTable() {
  m_resultModel->blockSignals(true);
  m_resultModel->clear();
  m_resultModel->setHorizontalHeaderLabels(
      {"Timestamp", "ID", "Decoder", "Raw Hex", "Value"});

  if (m_allData.isEmpty() || m_savedConfigs.isEmpty()) {
    m_resultModel->blockSignals(false);
    resizeSplitterAndColumns();
    return;
  }

  // Pre-normalise config IDs once (avoids re-parsing per row)
  QVector<quint32> confNormIds;
  confNormIds.reserve(m_savedConfigs.size());
  for (const HexConfig &c : m_savedConfigs)
    confNormIds.append(normaliseCanId(c.targetID));

  // Pre-build filter set for O(1) lookup
  const bool hasFilter = !m_activeFilters.isEmpty();
  QSet<QString> filterSet;
  if (hasFilter)
    filterSet = QSet<QString>(m_activeFilters.begin(), m_activeFilters.end());

  // Estimate result size to avoid repeated reallocation
  QVector<QList<QStandardItem *>> rows;
  rows.reserve(m_allData.size()); // upper bound

  for (const RawData &row : m_allData) {
    if (hasFilter && !filterSet.contains(row.id))
      continue;

    quint32 rowCanId = row.numericId;
    const QString &cleanHex = row.cleanHex;

    for (int ci = 0; ci < m_savedConfigs.size(); ++ci) {
      if (confNormIds[ci] != rowCanId)
        continue;

      const HexConfig &conf = m_savedConfigs[ci];
      double rawVal = 0.0;
      QString displayHex;

      if (conf.isDBC) {
        if (!extractDbcSignalRaw(cleanHex, conf.startBit, conf.bitLength,
                                 conf.littleEndian, conf.isSigned, rawVal))
          continue;
        int sb = qBound(0, conf.startBit / 8, 7);
        int eb = qBound(sb, (conf.startBit + conf.bitLength - 1) / 8, 7);
        displayHex = "0x" + cleanHex.mid(sb * 2, (eb - sb + 1) * 2).toUpper();
      } else {
        int startPos = conf.startByte * 2;
        int sliceLen = (conf.endByte - conf.startByte + 1) * 2;
        if (startPos + sliceLen > cleanHex.length())
          continue;
        QString subHex = cleanHex.mid(startPos, sliceLen);
        bool ok = false;
        rawVal = (double)subHex.toLongLong(&ok, 16);
        if (!ok)
          continue;
        displayHex = "0x" + subHex.toUpper();
      }

      double finalVal = evaluateFormula(rawVal, conf.formula);

      QList<QStandardItem *> items;
      items << new QStandardItem(row.isoTime) << new QStandardItem(row.id)
            << new QStandardItem(conf.name) << new QStandardItem(displayHex)
            << new QStandardItem(QString::number(finalVal, 'f', 4));
      items[4]->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
      rows.append(items);
    }
  }

  // Batch insert all rows at once
  m_resultModel->setRowCount(rows.size());
  for (int r = 0; r < rows.size(); ++r) {
    for (int c = 0; c < rows[r].size(); ++c)
      m_resultModel->setItem(r, c, rows[r][c]);
  }
  m_resultModel->blockSignals(false);
  m_resultModel->layoutChanged();
  resizeSplitterAndColumns();
}

double MainWindow::evaluateFormula(double rawValue, const QString &formula) {
  if (formula.isEmpty())
    return rawValue;

  // HIGH-1: Use SafeEval (recursive-descent parser) instead of QJSEngine
  // to eliminate code injection risk entirely.
  bool ok = false;
  double result = SafeEval::evaluate(formula, rawValue, rawValue, &ok);
  return ok ? result : rawValue;
}

// ═════════════════════════════════════════════════════════════════════════════
//  DBC support
// ═════════════════════════════════════════════════════════════════════════════

QStringList MainWindow::allKnownIDs() const {
  QSet<QString> idSet;
  for (const RawData &d : m_allData)
    idSet.insert(d.id);
  for (const DBCMessage &msg : m_dbcParser.messages())
    idSet.insert(msg.hexID());
  return idSet.values();
}

void MainWindow::updateDBCStatus() {
  if (m_decoderInfoLabel) {
    m_decoderInfoLabel->setText(
        QString("Active decoders: %1   |   DBC: %2")
            .arg(m_savedConfigs.size())
            .arg(m_loadedDbcFile.isEmpty()
                     ? "Not loaded"
                     : QFileInfo(m_loadedDbcFile).fileName()));
  }

  // Reload table if we are sitting with loaded data
  if (m_allData.size() > 0) {
    int msgCount = m_dbcParser.messages().size();
    int sigCount = 0;
    for (const DBCMessage &m : m_dbcParser.messages())
      sigCount += m.sigs.size();
    statusBar()->showMessage(QString("DBC: %1  —  %2 messages, %3 signals")
                                 .arg(QFileInfo(m_loadedDbcFile).fileName())
                                 .arg(msgCount)
                                 .arg(sigCount));
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  onLoadDBC()  — triggered by toolbar "Load DBC…"
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onLoadDBC() {
  // If DBC already loaded, offer to re-import signals manually
  if (!m_loadedDbcFile.isEmpty()) {
    int choice = QMessageBox::question(
        this, "DBC Already Loaded",
        QString("DBC file already loaded: <b>%1</b><br><br>"
                "What would you like to do?<br><br>"
                "<b>Load New DBC:</b> Replace with a new .dbc file<br>"
                "<b>Manual Import:</b> Open signal selector for current DBC")
            .arg(QFileInfo(m_loadedDbcFile).fileName()),
        QMessageBox::Open | QMessageBox::Apply | QMessageBox::Cancel,
        QMessageBox::Cancel);

    if (choice == QMessageBox::Apply) {
      showDBCImportDialog();
      return;
    } else if (choice == QMessageBox::Cancel) {
      return;
    }
    // else: Open → continue to file picker below
  }

  QString path = QFileDialog::getOpenFileName(
      this, "Open DBC File", "", "DBC Files (*.dbc);;All Files (*)");
  if (path.isEmpty())
    return;

  if (!m_dbcParser.parse(path)) {
    QMessageBox::critical(this, "DBC Load Error", m_dbcParser.errorString());
    return;
  }

  m_loadedDbcFile = path;
  m_actUnloadDBC->setEnabled(true);
  updateDBCStatus();

  // Clear stale DBC configs from previous imports
  int removedOld = 0;
  for (int i = m_savedConfigs.size() - 1; i >= 0; --i) {
    if (m_savedConfigs[i].isDBC) {
      m_savedConfigs.removeAt(i);
      ++removedOld;
    }
  }
  if (removedOld > 0) {
    saveConfigsToFile();
    qDebug() << "[DBC] Cleared" << removedOld << "stale DBC decoder(s).";
  }

  // Show summary - auto-import will happen when CSV is loaded
  int totalSigs = 0;
  for (const auto &m : m_dbcParser.messages())
    totalSigs += m.sigs.size();

  // ── Auto-import if CSV data already loaded ────────────────────────────────
  if (!m_allData.isEmpty()) {
    autoImportMatchingSignals();
  } else if ((m_liveConnected || m_liveSimActive) && !m_liveSeenIds.isEmpty()) {
    // ── Auto-import if live session is active with accumulated CAN IDs ───────
    autoImportLiveSignals();
  } else {
    // ── No CSV, no live session — import all signals from the DBC ────────────
    for (const DBCMessage &msg : m_dbcParser.messages()) {
      for (const DBCSignal &sig : msg.sigs) {
        HexConfig conf;
        conf.targetID = msg.hexID();
        conf.name = sig.name;
        conf.formula = sig.toFormula();
        conf.isDBC = true;
        conf.startBit = sig.startBit;
        conf.bitLength = sig.length;
        conf.littleEndian = sig.littleEndian;
        conf.isSigned = sig.isSigned;
        conf.startByte = sig.startByte();
        conf.endByte = sig.endByte();
        m_savedConfigs.append(conf); // stale configs already cleared above
      }
    }
    saveConfigsToFile();
    if (m_configWidget)
      m_configWidget->setConfigList(m_savedConfigs);
    updateDBCStatus();
  }

  QMessageBox::information(this, "DBC Loaded",
                           QString("<b>DBC file loaded successfully:</b><br>"
                                   "%1<br><br>"
                                   "<b>%2</b> messages<br>"
                                   "<b>%3</b> signals<br><br>"
                                   "Matching signals have been auto-imported.")
                               .arg(QFileInfo(path).fileName())
                               .arg(m_dbcParser.messages().size())
                               .arg(totalSigs));
}

// ─────────────────────────────────────────────────────────────────────────────
//  onUnloadDBC()
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::onUnloadDBC() {
  m_loadedDbcFile.clear();
  m_dbcParser = DBCParser(); // reset
  m_actUnloadDBC->setEnabled(false);

  // Remove all DBC-sourced decoder configs
  for (int i = m_savedConfigs.size() - 1; i >= 0; --i)
    if (m_savedConfigs[i].isDBC)
      m_savedConfigs.removeAt(i);
  saveConfigsToFile();
  if (m_configWidget)
    m_configWidget->setConfigList(m_savedConfigs);
  updateDBCStatus();

  statusBar()->showMessage("DBC database unloaded — DBC decoders removed.");
}

// ─────────────────────────────────────────────────────────────────────────────
//  showDBCImportDialog()
//  Shows a tree of all DBC messages / signals.  The user checks the signals
//  they want; on OK they are converted to HexConfig entries and appended to
//  m_savedConfigs (duplicates by name are skipped).
// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
//  autoImportMatchingSignals()
//  Called after CSV load when a DBC is already loaded.
//  autoImportLiveSignals()
//  Called when a DBC is loaded while a live session (real or simulation) is
//  already running.  Imports all DBC signals whose message IDs have been seen
//  in the live stream so far (m_liveSeenIds), then clears and resets the
//  decoded table so new rows start appearing immediately on the next batch
//  tick.
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::autoImportLiveSignals() {
  if (m_dbcParser.messages().isEmpty() || m_liveSeenIds.isEmpty())
    return;

  // Remove stale DBC configs from previous imports
  for (int i = m_savedConfigs.size() - 1; i >= 0; --i)
    if (m_savedConfigs[i].isDBC)
      m_savedConfigs.removeAt(i);

  int imported = 0;
  for (const DBCMessage &msg : m_dbcParser.messages()) {
    if (!m_liveSeenIds.contains(msg.rawCanId))
      continue;
    for (const DBCSignal &sig : msg.sigs) {
      HexConfig conf;
      conf.targetID = msg.hexID();
      conf.name = sig.name;
      conf.formula = sig.toFormula();
      conf.isDBC = true;
      conf.startBit = sig.startBit;
      conf.bitLength = sig.length;
      conf.littleEndian = sig.littleEndian;
      conf.isSigned = sig.isSigned;
      conf.startByte = sig.startByte();
      conf.endByte = sig.endByte();
      bool dup = false;
      for (const HexConfig &c : m_savedConfigs)
        if (c.name == conf.name &&
            normaliseCanId(c.targetID) == normaliseCanId(conf.targetID)) {
          dup = true;
          break;
        }
      if (!dup) {
        m_savedConfigs.append(conf);
        ++imported;
      }
    }
  }
  saveConfigsToFile();
  if (m_configWidget)
    m_configWidget->setConfigList(m_savedConfigs);
  updateDBCStatus();

  // Reset decoded table so signals start populating from the next batch tick
  if (m_liveDecodedTable)
    m_liveDecodedTable->setRowCount(0);
  m_decodedTableRowMap.clear();

  statusBar()->showMessage(
      QString("DBC loaded — %1 signal(s) imported from live traffic.")
          .arg(imported));
}

// ─────────────────────────────────────────────────────────────────────────────
//  Automatically imports all signals from DBC messages whose IDs appear in
//  CSV.
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::autoImportMatchingSignals() {
  if (m_dbcParser.messages().isEmpty())
    return;

  // Populate ConfigWidget IDs
  if (m_configWidget)
    m_configWidget->setIDList(allKnownIDs());

  if (m_allData.isEmpty()) {
    return;
  }

  // Collect unique normalised CAN IDs from CSV data
  QSet<quint32> csvIds;
  for (const RawData &row : m_allData) {
    csvIds.insert(row.numericId);
  }
  int imported = 0, updated = 0, skippedNoMatch = 0;

  // For each DBC message, check if its ID appears in CSV
  for (const DBCMessage &msg : m_dbcParser.messages()) {
    if (!csvIds.contains(msg.rawCanId)) {
      ++skippedNoMatch;
      continue; // CSV doesn't have this message ID
    }

    // CSV has this ID → import all its signals
    for (const DBCSignal &sig : msg.sigs) {
      HexConfig conf;
      conf.targetID = msg.hexID();
      conf.name = sig.name;
      conf.formula = sig.toFormula();
      conf.isDBC = true;
      conf.startBit = sig.startBit;
      conf.bitLength = sig.length;
      conf.littleEndian = sig.littleEndian;
      conf.isSigned = sig.isSigned;
      conf.startByte = sig.startByte();
      conf.endByte = sig.endByte();

      // Update if exists, otherwise append
      bool found = false;
      for (int k = 0; k < m_savedConfigs.size(); ++k) {
        if (m_savedConfigs[k].name == conf.name) {
          m_savedConfigs[k] = conf;
          found = true;
          ++updated;
          break;
        }
      }
      if (!found) {
        m_savedConfigs.append(conf);
        ++imported;
      }
    }
  }

  if (imported > 0 || updated > 0) {
    if (m_configWidget) {
      m_configWidget->setConfigList(m_savedConfigs);
    }
    saveConfigsToFile();
    calculateAndPopulateResultTable();
    updateDBCStatus();
    setInterfaceState(true); // forces visibility updates for the guide
  }

  qDebug() << "[Auto-import]" << imported << "new," << updated << "updated,"
           << skippedNoMatch << "DBC messages skipped (ID not in CSV)";
}

void MainWindow::showDBCImportDialog() {
  if (m_loadedDbcFile.isEmpty() || m_dbcParser.messages().isEmpty()) {
    QMessageBox::warning(this, "DBC Import",
                         "No DBC file loaded.<br><br>"
                         "Click <b>Load DBC</b> first to load a .dbc file.");
    return;
  }

  QDialog dlg(this);
  dlg.setWindowTitle("Import DBC Signals as Decoders");
  dlg.resize(680, 520);

  QVBoxLayout *root = new QVBoxLayout(&dlg);
  root->setSpacing(8);
  root->setContentsMargins(10, 10, 10, 10);

  // ── Info label
  // ────────────────────────────────────────────────────────────
  QLabel *info =
      new QLabel("Check the signals you want to import as byte decoders.\n"
                 "Each signal will be converted to a HexConfig entry using its "
                 "DBC start/end byte and scale formula.",
                 &dlg);
  info->setWordWrap(true);
  root->addWidget(info);

  // ── Tree: Message → Signals
  // ───────────────────────────────────────────────
  QTreeWidget *tree = new QTreeWidget(&dlg);
  tree->setHeaderLabels(
      {"Signal / Message", "ID", "Bits", "Factor", "Offset", "Unit"});
  tree->setAlternatingRowColors(true);
  tree->setColumnWidth(0, 200);
  tree->setColumnWidth(1, 80);
  tree->setColumnWidth(2, 60);
  tree->setColumnWidth(3, 60);
  tree->setColumnWidth(4, 60);

  for (const DBCMessage &msg : m_dbcParser.messages()) {
    QTreeWidgetItem *msgItem = new QTreeWidgetItem(tree);
    msgItem->setText(0, QString("%1").arg(msg.name));
    msgItem->setText(1, msg.hexID());
    msgItem->setText(2, QString("%1 B").arg(msg.dlc));
    msgItem->setFlags(msgItem->flags() | Qt::ItemIsUserCheckable |
                      Qt::ItemIsAutoTristate);
    msgItem->setCheckState(0, Qt::Unchecked);
    msgItem->setExpanded(true);

    for (const DBCSignal &sig : msg.sigs) {
      QTreeWidgetItem *sigItem = new QTreeWidgetItem(msgItem);
      sigItem->setFlags(sigItem->flags() | Qt::ItemIsUserCheckable);
      sigItem->setCheckState(0, Qt::Unchecked);

      // Name + optional unit suffix
      QString label = sig.name;
      if (!sig.unit.isEmpty())
        label += QString("  [%1]").arg(sig.unit);
      sigItem->setText(0, label);
      sigItem->setText(1, msg.hexID());
      sigItem->setText(2, QString("%1|%2").arg(sig.startBit).arg(sig.length));
      sigItem->setText(3, QString::number(sig.factor, 'g', 6));
      sigItem->setText(4, QString::number(sig.offset, 'g', 6));
      sigItem->setText(5, sig.unit);

      // Attach signal data as item data for later retrieval
      sigItem->setData(0, Qt::UserRole + 0, msg.hexID());
      sigItem->setData(0, Qt::UserRole + 1, sig.name);
      sigItem->setData(0, Qt::UserRole + 2, sig.toFormula());
      sigItem->setData(0, Qt::UserRole + 3, sig.startBit); // DBC startBit
      sigItem->setData(0, Qt::UserRole + 4, sig.length);   // DBC bitLength
      sigItem->setData(0, Qt::UserRole + 5,
                       sig.littleEndian);                  // DBC byteOrder
      sigItem->setData(0, Qt::UserRole + 6, sig.isSigned); // DBC signed
      sigItem->setData(0, Qt::UserRole + 7, sig.comment);
      sigItem->setData(0, Qt::UserRole + 8,
                       sig.startByte()); // approx byte (for display)
      sigItem->setData(0, Qt::UserRole + 9, sig.endByte());

      // Show comment as tooltip
      if (!sig.comment.isEmpty())
        sigItem->setToolTip(0, sig.comment);
    }

    if (msg.sigs.isEmpty()) {
      QTreeWidgetItem *empty = new QTreeWidgetItem(msgItem);
      empty->setText(0, "(no signals)");
      empty->setFlags(Qt::ItemIsEnabled);
    }
  }

  root->addWidget(tree);

  // ── Select-all / Select-none row
  // ──────────────────────────────────────────
  QHBoxLayout *selRow = new QHBoxLayout();
  QPushButton *bAll = new QPushButton("Check All", &dlg);
  QPushButton *bNone = new QPushButton("Uncheck All", &dlg);
  QPushButton *bExpand = new QPushButton("Expand All", &dlg);
  bAll->setMaximumHeight(24);
  bNone->setMaximumHeight(24);
  bExpand->setMaximumHeight(24);
  selRow->addWidget(bAll);
  selRow->addWidget(bNone);
  selRow->addWidget(bExpand);
  selRow->addStretch();
  root->addLayout(selRow);

  auto setAllChecked = [tree](Qt::CheckState state) {
    for (int i = 0; i < tree->topLevelItemCount(); ++i) {
      auto *msg = tree->topLevelItem(i);
      for (int j = 0; j < msg->childCount(); ++j)
        if (msg->child(j)->flags() & Qt::ItemIsUserCheckable)
          msg->child(j)->setCheckState(0, state);
    }
  };

  connect(bAll, &QPushButton::clicked, [&] { setAllChecked(Qt::Checked); });
  connect(bNone, &QPushButton::clicked, [&] { setAllChecked(Qt::Unchecked); });
  connect(bExpand, &QPushButton::clicked, [tree] { tree->expandAll(); });

  // ── Dialog buttons
  // ────────────────────────────────────────────────────────
  QDialogButtonBox *bb = new QDialogButtonBox(
      QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
  root->addWidget(bb);
  connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
  connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

  if (dlg.exec() != QDialog::Accepted)
    return;

  // ── Collect checked signals
  // ─────────────────────────────────────────────── Strategy: UPDATE
  // existing entries with the same name (so re-importing after a code fix
  // always overwrites stale configs.json entries), ADD new ones.
  int imported = 0, updated = 0;

  for (int i = 0; i < tree->topLevelItemCount(); ++i) {
    auto *msgItem = tree->topLevelItem(i);
    for (int j = 0; j < msgItem->childCount(); ++j) {
      auto *sigItem = msgItem->child(j);
      if (!(sigItem->flags() & Qt::ItemIsUserCheckable))
        continue;
      if (sigItem->checkState(0) != Qt::Checked)
        continue;

      HexConfig conf;
      conf.targetID = sigItem->data(0, Qt::UserRole + 0).toString();
      conf.name = sigItem->data(0, Qt::UserRole + 1).toString();
      conf.formula = sigItem->data(0, Qt::UserRole + 2).toString();
      conf.isDBC = true;
      conf.startBit = sigItem->data(0, Qt::UserRole + 3).toInt();
      conf.bitLength = sigItem->data(0, Qt::UserRole + 4).toInt();
      conf.littleEndian = sigItem->data(0, Qt::UserRole + 5).toBool();
      conf.isSigned = sigItem->data(0, Qt::UserRole + 6).toBool();
      conf.startByte = sigItem->data(0, Qt::UserRole + 8).toInt();
      conf.endByte = sigItem->data(0, Qt::UserRole + 9).toInt();

      // Find existing entry with same name and UPDATE it rather than skip
      bool found = false;
      for (int k = 0; k < m_savedConfigs.size(); ++k) {
        if (m_savedConfigs[k].name == conf.name) {
          m_savedConfigs[k] = conf; // overwrite with correct DBC data
          found = true;
          ++updated;
          break;
        }
      }
      if (!found) {
        m_savedConfigs.append(conf);
        ++imported;
      }
    }
  }

  if (imported == 0 && updated == 0) {
    statusBar()->showMessage("No signals selected.");
    return;
  }

  saveConfigsToFile();
  calculateAndPopulateResultTable();

  // ── Post-import feedback
  // ──────────────────────────────────────────────────
  QString msg =
      QString("DBC import: %1 added, %2 updated.").arg(imported).arg(updated);
  if (m_allData.isEmpty()) {
    msg += "  [!] No CSV data loaded -- open a CSV file to see decoded "
           "values.";
  } else {
    int rows = m_resultModel->rowCount();
    msg += QString("  ->  %1 decoded row(s) in result table.").arg(rows);
    if (rows == 0) {
      // Show sample CSV IDs vs DBC IDs so user can diagnose
      QStringList csvIdSamples;
      QSet<QString> seenCsv;
      for (const RawData &d : m_allData) {
        if (!seenCsv.contains(d.id)) {
          csvIdSamples << d.id;
          seenCsv.insert(d.id);
        }
        if (csvIdSamples.size() >= 4) {
          csvIdSamples << "…";
          break;
        }
      }
      QStringList dbcIdSamples;
      int dbcShown = 0;
      for (const HexConfig &c : m_savedConfigs) {
        if (!dbcIdSamples.contains(c.targetID)) {
          dbcIdSamples << c.targetID;
          if (++dbcShown >= 4) {
            dbcIdSamples << "…";
            break;
          }
        }
      }
      msg += QString("  [!] 0 matches! CSV IDs: [%1]  Decoder IDs: [%2]")
                 .arg(csvIdSamples.join(", "))
                 .arg(dbcIdSamples.join(", "));
    }
  }
  statusBar()->showMessage(msg);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Standard slots
// ─────────────────────────────────────────────────────────────────────────────
void MainWindow::on_btn_load_clicked() {
  QString fileName = QFileDialog::getOpenFileName(
      this, "Open CSV File", "", "CSV Files (*.csv);;All Files (*)");
  if (fileName.isEmpty())
    return;

  QFile file(fileName);
  if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
    // LOW-4: use basename only to avoid leaking full path
    QMessageBox::critical(
        this, "Error", "Cannot open file:\n" + QFileInfo(fileName).fileName());
    return;
  }

  m_allData.clear();
  m_summaryModel->clear();
  m_resultModel->clear();
  m_activeFilters.clear();

  // Pre-allocate based on file size estimate (~80 bytes per CSV line)
  m_allData.reserve(static_cast<int>(file.size() / 80));

  // -- Determine total lines for progress --
  qint64 fileSize = file.size();

  QProgressDialog progress("Loading CSV...", "Cancel", 0,
                           static_cast<int>(fileSize), this);
  progress.setWindowTitle("HEDAP");
  progress.setWindowModality(Qt::WindowModal);
  progress.setMinimumDuration(300); // only show if takes > 300ms
  progress.setValue(0);

  QTextStream in(&file);
  if (!in.atEnd())
    in.readLine(); // skip header

  int lineCount = 0;
  while (!in.atEnd()) {
    // MED-1: cap rows to prevent memory exhaustion from huge files
    if (m_allData.size() >= MAX_CSV_ROWS) {
      QMessageBox::warning(this, "Row Limit",
                           QString("Maximum row limit (%1) reached.\n"
                                   "Only the first %1 rows were loaded.")
                               .arg(MAX_CSV_ROWS));
      break;
    }
    if (progress.wasCanceled()) {
      m_allData.clear();
      m_summaryModel->clear();
      m_resultModel->clear();
      statusBar()->showMessage("Loading cancelled.");
      return;
    }
    parseAndStoreLine(in.readLine());
    ++lineCount;
    if (lineCount % 500 == 0) {
      progress.setValue(static_cast<int>(in.pos()));
      QApplication::processEvents();
    }
  }
  file.close();
  progress.setValue(static_cast<int>(fileSize));

  populateSummaryTable();
  calculateAndPopulateResultTable();
  setInterfaceState(true);

  // ── Auto-import from DBC if loaded
  // ───────────────────────────────────────
  if (!m_loadedDbcFile.isEmpty()) {
    autoImportMatchingSignals();
  }

  int rows = m_resultModel->rowCount();
  QString msg = QString("%1  —  %2 frames loaded")
                    .arg(QFileInfo(fileName).fileName())
                    .arg(m_allData.size());

  if (!m_loadedDbcFile.isEmpty()) {
    msg += QString("  |  DBC: %1").arg(QFileInfo(m_loadedDbcFile).fileName());
  }

  if (m_savedConfigs.isEmpty()) {
    msg += "  |  No decoders -- load a DBC file first";
  } else if (rows == 0) {
    QStringList sampleIds;
    QSet<QString> seen;
    for (const RawData &d : m_allData) {
      if (!seen.contains(d.id)) {
        sampleIds << d.id;
        seen.insert(d.id);
      }
      if (sampleIds.size() >= 3)
        break;
    }
    msg += QString("  |  0 matches -- CSV IDs [%1] not in DBC")
               .arg(sampleIds.join(", "));
  } else {
    msg += QString("  |  %1 decoded rows").arg(rows);
  }
  statusBar()->showMessage(msg);
}

void MainWindow::on_btn_unload_clicked() {
  m_allData.clear();
  m_summaryModel->clear();
  m_resultModel->clear();
  m_activeFilters.clear();
  setInterfaceState(false);
  statusBar()->showMessage("File closed.");
}

void MainWindow::on_btn_filter_clicked() {
  QSet<QString> idSet;
  idSet.reserve(256);
  for (const RawData &d : m_allData)
    idSet.insert(d.id);
  QStringList uniqueIDs = idSet.values();
  uniqueIDs.sort();

  QDialog dlg(this);
  dlg.setWindowTitle("Filter by ID");
  dlg.resize(280, 380);

  QVBoxLayout *lay = new QVBoxLayout(&dlg);
  lay->setSpacing(4);
  lay->setContentsMargins(8, 8, 8, 8);

  QListWidget *lw = new QListWidget(&dlg);
  lw->setSpacing(0);
  for (const QString &id : uniqueIDs) {
    auto *item = new QListWidgetItem(id, lw);
    item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
    item->setCheckState(
        (m_activeFilters.isEmpty() || m_activeFilters.contains(id))
            ? Qt::Checked
            : Qt::Unchecked);
  }
  lay->addWidget(lw);

  QHBoxLayout *btnRow = new QHBoxLayout();
  auto *bAll = new QPushButton("All", &dlg);
  auto *bNone = new QPushButton("None", &dlg);
  bAll->setMaximumHeight(22);
  bNone->setMaximumHeight(22);
  btnRow->addWidget(bAll);
  btnRow->addWidget(bNone);
  lay->addLayout(btnRow);
  connect(bAll, &QPushButton::clicked, [lw] {
    for (int i = 0; i < lw->count(); i++)
      lw->item(i)->setCheckState(Qt::Checked);
  });
  connect(bNone, &QPushButton::clicked, [lw] {
    for (int i = 0; i < lw->count(); i++)
      lw->item(i)->setCheckState(Qt::Unchecked);
  });

  auto *bb = new QDialogButtonBox(
      QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
  lay->addWidget(bb);
  connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
  connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

  if (dlg.exec() == QDialog::Accepted) {
    QStringList sel;
    for (int i = 0; i < lw->count(); i++)
      if (lw->item(i)->checkState() == Qt::Checked)
        sel << lw->item(i)->text();
    if (sel.isEmpty()) {
      QMessageBox::warning(this, "Filter", "Select at least one ID.");
      return;
    }
    m_activeFilters = sel;
    populateSummaryTable(m_activeFilters);
    calculateAndPopulateResultTable();
    statusBar()->showMessage(
        QString("Filter: %1 ID(s) active").arg(sel.size()));
  }
}

void MainWindow::on_btn_reset_clicked() {
  m_activeFilters.clear();
  populateSummaryTable();
  calculateAndPopulateResultTable();
  statusBar()->showMessage("Filter cleared.");
}

void MainWindow::on_btn_conf_clicked() { switchPage(PAGE_DECODERS); }

void MainWindow::on_btn_export_clicked() {
  if (m_allData.isEmpty()) {
    QMessageBox::warning(this, "Export", "No data loaded.");
    return;
  }

  QMessageBox msgBox(this);
  msgBox.setWindowTitle("Export");
  msgBox.setText("Select export scope:");
  msgBox.setIcon(QMessageBox::Question);
  auto *bSummary = msgBox.addButton("Summary Table", QMessageBox::ActionRole);
  auto *bSelected = msgBox.addButton("Selected ID", QMessageBox::ActionRole);
  auto *bAll = msgBox.addButton("All Raw Data", QMessageBox::ActionRole);
  msgBox.addButton(QMessageBox::Cancel);
  msgBox.exec();

  auto *clicked = msgBox.clickedButton();
  if (!clicked || clicked == msgBox.button(QMessageBox::Cancel))
    return;

  QString idFilter;
  if (clicked == bSelected) {
    auto idx = ui->tbl_summary->currentIndex();
    if (!idx.isValid()) {
      QMessageBox::warning(this, "Export", "Select a row first.");
      return;
    }
    idFilter = ui->tbl_summary->model()->index(idx.row(), 0).data().toString();
  }

  QString path =
      QFileDialog::getSaveFileName(this, "Export CSV", "", "CSV Files (*.csv)");
  if (path.isEmpty())
    return;
  QFile f(path);
  if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
    QMessageBox::critical(this, "Error", "Cannot write file.");
    return;
  }
  QTextStream out(&f);
  out.setEncoding(QStringConverter::Utf8);
  out.setGenerateByteOrderMark(true);

  auto escapeCsv = [](const QString &field) -> QString {
    if (field.contains(',') || field.contains('"') || field.contains('\n')) {
      QString escaped = field;
      escaped.replace("\"", "\"\"");
      return "\"" + escaped + "\"";
    }
    return field;
  };

  if (clicked == bSummary) {
    out << "ID,Count,First Seen,Last Seen\n";
    for (int i = 0; i < m_summaryModel->rowCount(); i++)
      out << escapeCsv(m_summaryModel->item(i, 0)->text()) << ","
          << escapeCsv(m_summaryModel->item(i, 1)->text()) << ","
          << escapeCsv(m_summaryModel->item(i, 2)->text()) << ","
          << escapeCsv(m_summaryModel->item(i, 3)->text()) << "\n";
  } else {
    out << "ISO Time,Epoch,ID,Data Hex\n";
    for (const RawData &d : m_allData) {
      if (clicked == bSelected && d.id != idFilter)
        continue;
      out << escapeCsv(d.isoTime) << "," << d.timestamp << ","
          << escapeCsv(d.id) << "," << escapeCsv(d.dataHex) << "\n";
    }
  }
  f.close();
  statusBar()->showMessage("Exported: " + QFileInfo(path).fileName());
}

void MainWindow::on_btn_exportdata_clicked() {
  if (m_resultModel->rowCount() == 0) {
    QMessageBox::warning(this, "Export", "No decoded data to export.");
    return;
  }
  QString path = QFileDialog::getSaveFileName(this, "Export Decoded Data", "",
                                              "CSV Files (*.csv)");
  if (path.isEmpty())
    return;
  QFile f(path);
  if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
    QMessageBox::critical(this, "Error", "Cannot write file.");
    return;
  }
  QTextStream out(&f);
  out.setEncoding(QStringConverter::Utf8);
  out.setGenerateByteOrderMark(true);
  auto escapeCsv = [](const QString &field) -> QString {
    if (field.contains(',') || field.contains('"') || field.contains('\n')) {
      QString escaped = field;
      escaped.replace("\"", "\"\"");
      return "\"" + escaped + "\"";
    }
    return field;
  };

  QStringList hdr;
  for (int i = 0; i < m_resultModel->columnCount(); i++)
    hdr << escapeCsv(m_resultModel->headerData(i, Qt::Horizontal).toString());
  out << hdr.join(",") << "\n";
  for (int i = 0; i < m_resultModel->rowCount(); i++) {
    QStringList row;
    for (int j = 0; j < m_resultModel->columnCount(); j++)
      row << escapeCsv(m_resultModel->item(i, j)->text());
    out << row.join(",") << "\n";
  }
  f.close();
  statusBar()->showMessage("Exported: " + QFileInfo(path).fileName());
}

void MainWindow::exportManualDecodersToDBC() {
  QVector<HexConfig> manual;
  for (const HexConfig &c : m_savedConfigs)
    if (!c.isDBC)
      manual.append(c);

  if (manual.isEmpty()) {
    QMessageBox::information(this, "Export as DBC",
                             "No manual decoder configurations to export.");
    return;
  }

  QString path = QFileDialog::getSaveFileName(this, "Export as DBC", "",
                                              "DBC Files (*.dbc)");
  if (path.isEmpty())
    return;

  // Group configs by CAN ID
  QMap<quint32, QVector<const HexConfig *>> groups;
  for (const HexConfig &c : manual)
    groups[normaliseCanId(c.targetID)].append(&c);

  QFile f(path);
  if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
    QMessageBox::critical(this, "Error", "Cannot write file.");
    return;
  }
  QTextStream out(&f);
  out << "VERSION \"\"\n\nNS_ :\n\nBS_:\n\nBU_:\n\n";

  for (auto it = groups.begin(); it != groups.end(); ++it) {
    quint32 id = it.key();
    out << QString("BO_ %1 MSG_%1: 8 Vector__XXX\n").arg(id);
    for (const HexConfig *c : it.value()) {
      int startBit = c->startByte * 8;
      int bitLen = (c->endByte - c->startByte + 1) * 8;
      auto fo = parseLinearFormula(c->formula);
      out << QString(" SG_ %1 : %2|%3@1+ (%4,%5) [0|0] \"\" Vector__XXX\n")
                 .arg(c->name)
                 .arg(startBit)
                 .arg(bitLen)
                 .arg(fo.first)
                 .arg(fo.second);
    }
    out << "\n";
  }

  statusBar()->showMessage(QString("Exported %1 decoder(s) to %2")
                               .arg(manual.size())
                               .arg(QFileInfo(path).fileName()));
}

void MainWindow::on_btn_graph_clicked() {
  if (m_allData.isEmpty() || m_savedConfigs.isEmpty()) {
    QMessageBox::warning(this, "Plot",
                         "No decoded data. Configure decoders first.");
    return;
  }

  // ── Build fast lookup structures ──────────────────────────────────────────
  // Hash: signal name -> graph config (enabled, color, style)
  QHash<QString, GraphSeriesConfig> cfgHash;
  cfgHash.reserve(m_graphSeriesConfigs.size());
  for (const GraphSeriesConfig &c : m_graphSeriesConfigs)
    cfgHash[c.name] = c;

  // Pre-normalise config IDs and build enabled flags
  struct ConfigInfo {
    quint32 normId;
    bool enabled;
    QString name;
    // Config fields needed for value extraction
    const HexConfig *cfg;
  };
  QVector<ConfigInfo> enabledConfigs;
  enabledConfigs.reserve(m_savedConfigs.size());
  for (int ci = 0; ci < m_savedConfigs.size(); ++ci) {
    const HexConfig &conf = m_savedConfigs[ci];
    bool en = true;
    if (cfgHash.contains(conf.name))
      en = cfgHash[conf.name].enabled;
    if (!en)
      continue; // skip disabled signals entirely
    ConfigInfo info;
    info.normId = normaliseCanId(conf.targetID);
    info.enabled = true;
    info.name = conf.name;
    info.cfg = &m_savedConfigs[ci];
    enabledConfigs.append(info);
  }

  if (enabledConfigs.isEmpty()) {
    QMessageBox::information(this, "Plot", "No signals enabled for plotting.");
    return;
  }

  // Pre-build filter set for O(1) lookup (same as
  // calculateAndPopulateResultTable)
  const bool hasFilter = !m_activeFilters.isEmpty();
  QSet<QString> filterSet;
  if (hasFilter)
    filterSet = QSet<QString>(m_activeFilters.begin(), m_activeFilters.end());

  // ── Collect points directly from raw data (bypass QStandardItemModel) ─────
  QHash<QString, QVector<QPointF>> pointsMap;
  pointsMap.reserve(enabledConfigs.size());
  qint64 minX = std::numeric_limits<qint64>::max(),
         maxX = std::numeric_limits<qint64>::min();
  double minY = std::numeric_limits<double>::max(),
         maxY = std::numeric_limits<double>::lowest();
  int totalPoints = 0;

  for (const RawData &row : m_allData) {
    if (hasFilter && !filterSet.contains(row.id))
      continue;

    const quint32 rowCanId = row.numericId;
    const qint64 xv = row.timestamp; // epoch ms — no string parsing needed

    for (const ConfigInfo &ci : enabledConfigs) {
      if (ci.normId != rowCanId)
        continue;

      const HexConfig &conf = *ci.cfg;
      double rawVal = 0.0;

      if (conf.isDBC) {
        if (!extractDbcSignalRaw(row.cleanHex, conf.startBit, conf.bitLength,
                                 conf.littleEndian, conf.isSigned, rawVal))
          continue;
      } else {
        int startPos = conf.startByte * 2;
        int sliceLen = (conf.endByte - conf.startByte + 1) * 2;
        if (startPos + sliceLen > row.cleanHex.length())
          continue;
        bool ok = false;
        rawVal =
            (double)row.cleanHex.mid(startPos, sliceLen).toLongLong(&ok, 16);
        if (!ok)
          continue;
      }

      double finalVal = evaluateFormula(rawVal, conf.formula);

      pointsMap[ci.name].append(QPointF(xv, finalVal));
      minX = qMin(minX, xv);
      maxX = qMax(maxX, xv);
      minY = qMin(minY, finalVal);
      maxY = qMax(maxY, finalVal);
      ++totalPoints;
    }
  }

  if (pointsMap.isEmpty()) {
    QMessageBox::information(this, "Plot", "No signals enabled for plotting.");
    return;
  }

  // ── Build chart ───────────────────────────────────────────────────────────
  auto *chart = new QChart();
  chart->setTitle("Decoded Values -- Time Series");
  chart->setAnimationOptions(QChart::NoAnimation);

  static const int MAX_POINTS_PER_SERIES = 2000;
  int seriesCount = 0;

  for (auto it = pointsMap.begin(); it != pointsMap.end(); ++it) {
    const QString &name = it.key();
    QColor seriesColor = Qt::blue;
    int seriesStyle = 0;

    if (cfgHash.contains(name)) {
      seriesColor = cfgHash[name].color;
      seriesStyle = cfgHash[name].style;
    }

    QVector<QPointF> &pts = it.value();

    // Downsample if too many points
    QVector<QPointF> finalPts;
    if (pts.size() > MAX_POINTS_PER_SERIES) {
      finalPts.reserve(MAX_POINTS_PER_SERIES + 1);
      double step = static_cast<double>(pts.size()) / MAX_POINTS_PER_SERIES;
      for (int i = 0; i < MAX_POINTS_PER_SERIES; ++i)
        finalPts.append(pts[static_cast<int>(i * step)]);
      finalPts.append(pts.last());
    } else {
      finalPts = std::move(pts); // move instead of copy
    }

    if (seriesStyle == 2) {
      auto *scatter = new QScatterSeries();
      scatter->setName(name);
      scatter->setColor(seriesColor);
      scatter->setMarkerSize(6);
      scatter->setUseOpenGL(true);
      scatter->replace(finalPts);
      chart->addSeries(scatter);
    } else {
      auto *line = new QLineSeries();
      line->setName(name);
      line->setColor(seriesColor);
      line->setUseOpenGL(true);
      if (seriesStyle == 1) {
        QPen pen(seriesColor, 2, Qt::DashLine);
        line->setPen(pen);
      }
      line->replace(finalPts);
      chart->addSeries(line);
    }
    ++seriesCount;
  }

  auto *axX = new QDateTimeAxis;
  axX->setFormat("HH:mm:ss.zzz");
  axX->setTitleText("Time");
  axX->setRange(QDateTime::fromMSecsSinceEpoch(minX),
                QDateTime::fromMSecsSinceEpoch(maxX));
  chart->addAxis(axX, Qt::AlignBottom);

  double pad = (maxY - minY) * 0.08 + 0.001;
  auto *axY = new QValueAxis;
  axY->setTitleText("Value");
  axY->setRange(minY - pad, maxY + pad);
  chart->addAxis(axY, Qt::AlignLeft);
  for (auto *s : chart->series()) {
    s->attachAxis(axX);
    s->attachAxis(axY);
  }

  m_chartView->setChart(chart);
  switchPage(PAGE_GRAPH);
  statusBar()->showMessage(QString("Plot: %1 series, %2 data points.")
                               .arg(seriesCount)
                               .arg(totalPoints));
}

void MainWindow::onThemeLight() {
  applyTheme(false);
  saveSettings();
  statusBar()->showMessage("Light theme.");
}
void MainWindow::onThemeDark() {
  applyTheme(true);
  saveSettings();
  statusBar()->showMessage("Dark theme.");
}

void MainWindow::onAbout() {
  QMessageBox::about(this, "About HEDAP",
                     "<b>HEDAP</b>  –  Hex Data Analysis Platform<br>"
                     "Version 3.2<br><br>"
                     "CSV import · DBC decoding · Formula decoding · "
                     "Time-series plotting");
}

void MainWindow::saveConfigsToFile() {
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QDir().mkpath(dir);
  QFile f(dir + "/configs.json");
  if (!f.open(QIODevice::WriteOnly))
    return;
  QJsonArray arr;
  for (const HexConfig &c : m_savedConfigs) {
    if (c.isDBC)
      continue; // DBC configs are transient; re-imported each session
    QJsonObject o;
    c.write(o);
    arr.append(o);
  }
  f.write(QJsonDocument(arr).toJson());
}

void MainWindow::loadConfigsFromFile() {
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QFile f(dir + "/configs.json");
  if (!f.open(QIODevice::ReadOnly))
    return;
  m_savedConfigs.clear();
  QJsonParseError err;
  QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &err);
  if (err.error == QJsonParseError::NoError && doc.isArray()) {
    for (const QJsonValue &v : doc.array()) {
      HexConfig c;
      c.read(v.toObject());

      // MED-3: validate fields loaded from disk to prevent exploitation
      c.startByte = qBound(0, c.startByte, 7);
      c.endByte = qBound(c.startByte, c.endByte, 7);
      c.startBit = qBound(0, c.startBit, 63);
      c.bitLength = qBound(1, c.bitLength, 64);

      // Validate formula: SafeEval will reject bad formulas at runtime,
      // but truncate obviously suspicious strings from tampered files.
      if (c.formula.length() > 512)
        c.formula.clear();

      m_savedConfigs.append(c);
    }
  }
}

void MainWindow::saveSettings() {
  QJsonObject obj;
  obj["darkTheme"] = m_isDark;
  obj["lastDbcPath"] = m_loadedDbcFile;
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QDir().mkpath(dir);
  QFile f(dir + "/settings.json");
  if (!f.open(QIODevice::WriteOnly))
    return;
  f.write(QJsonDocument(obj).toJson());
}

void MainWindow::loadSettings() {
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QFile f(dir + "/settings.json");
  if (!f.open(QIODevice::ReadOnly))
    return;
  QJsonParseError err;
  QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &err);
  if (err.error == QJsonParseError::NoError && doc.isObject()) {
    QJsonObject obj = doc.object();
    if (obj.contains("darkTheme"))
      m_isDark = obj["darkTheme"].toBool();
  }
}

void MainWindow::restoreLastDBC() {
  QString dir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QFile f(dir + "/settings.json");
  if (!f.open(QIODevice::ReadOnly))
    return;
  QJsonParseError err;
  QJsonDocument doc = QJsonDocument::fromJson(f.readAll(), &err);
  if (err.error != QJsonParseError::NoError || !doc.isObject())
    return;
  QString path = doc.object()["lastDbcPath"].toString();
  if (path.isEmpty() || !QFile::exists(path))
    return;

  // Silently re-parse — no auto-import yet (waits for CSV/live to trigger)
  if (!m_dbcParser.parse(path))
    return;
  m_loadedDbcFile = path;
  m_actUnloadDBC->setEnabled(true);
  updateDBCStatus();
}
