#ifndef SAFEEVAL_H
#define SAFEEVAL_H

#include <QString>
#include <QtGlobal>
#include <cmath>
#include <limits>

// ─────────────────────────────────────────────────────────────────────────────
//  SafeEval — a minimal recursive-descent expression evaluator.
//
//  Supports:
//    • Arithmetic: +  -  *  /  %  (unary -)
//    • Parentheses: ( )
//    • Variable:    x  (case-insensitive)
//    • Constants:   PI, E, numeric literals (int, float, scientific)
//    • Functions:   abs  sqrt  pow  min  max  round  floor  ceil
//                   log  sin  cos  tan   (optionally prefixed with "Math.")
//
//  This parser is immune to code injection — it only supports the grammar
//  above and rejects all other identifiers, string literals, assignment,
//  control flow, etc.
// ─────────────────────────────────────────────────────────────────────────────

class SafeEval {
public:
  static double evaluate(const QString &formula, double x,
                         double fallback = 0.0, bool *ok = nullptr) {
    if (formula.isEmpty() || formula.length() > 512) {
      if (ok)
        *ok = false;
      return fallback;
    }
    SafeEval ev(formula, x);
    double result = ev.parseExpr();
    ev.skipSpaces();
    if (ev.m_error || ev.m_pos < ev.m_len) {
      if (ok)
        *ok = false;
      return fallback;
    }
    if (ok)
      *ok = true;
    return qIsFinite(result) ? result : fallback;
  }

private:
  SafeEval(const QString &formula, double x)
      : m_str(formula), m_len(formula.length()), m_pos(0), m_x(x),
        m_error(false) {}

  QChar peek() const { return (m_pos < m_len) ? m_str[m_pos] : QChar(0); }
  QChar advance() { return (m_pos < m_len) ? m_str[m_pos++] : QChar(0); }
  void skipSpaces() {
    while (m_pos < m_len && m_str[m_pos].isSpace())
      ++m_pos;
  }
  bool match(QChar ch) {
    skipSpaces();
    if (peek() == ch) {
      ++m_pos;
      return true;
    }
    return false;
  }

  // expr = term (('+' | '-') term)*
  double parseExpr() {
    double left = parseTerm();
    while (!m_error) {
      skipSpaces();
      if (peek() == '+') {
        advance();
        left += parseTerm();
      } else if (peek() == '-') {
        advance();
        left -= parseTerm();
      } else
        break;
    }
    return left;
  }

  // term = unary (('*' | '/' | '%') unary)*
  double parseTerm() {
    double left = parseUnary();
    while (!m_error) {
      skipSpaces();
      if (peek() == '*') {
        advance();
        left *= parseUnary();
      } else if (peek() == '/') {
        advance();
        double d = parseUnary();
        left = (d == 0.0) ? std::numeric_limits<double>::quiet_NaN() : left / d;
      } else if (peek() == '%') {
        advance();
        double d = parseUnary();
        left = (d == 0.0) ? std::numeric_limits<double>::quiet_NaN()
                          : std::fmod(left, d);
      } else
        break;
    }
    return left;
  }

  // unary = ('-' | '+') unary | primary
  double parseUnary() {
    skipSpaces();
    if (peek() == '-') {
      advance();
      return -parseUnary();
    }
    if (peek() == '+') {
      advance();
      return parseUnary();
    }
    return parsePrimary();
  }

  // primary = NUMBER | IDENT | FUNC '(' args ')' | '(' expr ')'
  double parsePrimary() {
    skipSpaces();
    if (m_error)
      return 0.0;
    QChar c = peek();

    if (c == '(') {
      advance();
      double v = parseExpr();
      if (!match(')'))
        m_error = true;
      return v;
    }
    if (c.isDigit() || c == '.')
      return parseNumber();
    if (c.isLetter() || c == '_')
      return parseIdentifier();

    m_error = true;
    return 0.0;
  }

  double parseNumber() {
    int start = m_pos;
    while (m_pos < m_len && (m_str[m_pos].isDigit() || m_str[m_pos] == '.'))
      ++m_pos;
    if (m_pos < m_len && (m_str[m_pos] == 'e' || m_str[m_pos] == 'E')) {
      ++m_pos;
      if (m_pos < m_len && (m_str[m_pos] == '+' || m_str[m_pos] == '-'))
        ++m_pos;
      while (m_pos < m_len && m_str[m_pos].isDigit())
        ++m_pos;
    }
    bool ok = false;
    double v = m_str.mid(start, m_pos - start).toDouble(&ok);
    if (!ok)
      m_error = true;
    return v;
  }

  double parseIdentifier() {
    int start = m_pos;
    while (m_pos < m_len &&
           (m_str[m_pos].isLetterOrNumber() || m_str[m_pos] == '_'))
      ++m_pos;
    QString id = m_str.mid(start, m_pos - start);
    QString lower = id.toLower();

    // Strip optional "Math." prefix:  "Math.abs(x)" → call abs
    if (lower == "math") {
      skipSpaces();
      if (peek() == '.') {
        advance(); // consume '.'
        // Read the actual function name
        start = m_pos;
        while (m_pos < m_len &&
               (m_str[m_pos].isLetterOrNumber() || m_str[m_pos] == '_'))
          ++m_pos;
        if (m_pos == start) {
          m_error = true;
          return 0.0;
        }
        id = m_str.mid(start, m_pos - start);
        lower = id.toLower();
        // Now fall through to function/constant lookup below
      } else {
        m_error = true; // bare "Math" is not valid
        return 0.0;
      }
    }

    // Variable
    if (lower == "x")
      return m_x;

    // Constants
    if (lower == "pi")
      return M_PI;
    if (lower == "e")
      return M_E;

    // Functions — require '(' after name
    skipSpaces();
    if (peek() != '(') {
      m_error = true;
      return 0.0;
    }
    advance(); // consume '('

    // Single-argument functions
    if (lower == "abs") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::fabs(a);
    }
    if (lower == "sqrt") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::sqrt(a);
    }
    if (lower == "log") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::log(a);
    }
    if (lower == "sin") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::sin(a);
    }
    if (lower == "cos") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::cos(a);
    }
    if (lower == "tan") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::tan(a);
    }
    if (lower == "round") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::round(a);
    }
    if (lower == "floor") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::floor(a);
    }
    if (lower == "ceil") {
      double a = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::ceil(a);
    }

    // Two-argument functions
    if (lower == "pow") {
      double a = parseExpr();
      if (!match(',')) {
        m_error = true;
        return 0.0;
      }
      double b = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::pow(a, b);
    }
    if (lower == "min") {
      double a = parseExpr();
      if (!match(',')) {
        m_error = true;
        return 0.0;
      }
      double b = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::fmin(a, b);
    }
    if (lower == "max") {
      double a = parseExpr();
      if (!match(',')) {
        m_error = true;
        return 0.0;
      }
      double b = parseExpr();
      if (!match(')'))
        m_error = true;
      return std::fmax(a, b);
    }

    // Unknown function
    m_error = true;
    return 0.0;
  }

  const QString &m_str;
  int m_len;
  int m_pos;
  double m_x;
  bool m_error;
};

#endif // SAFEEVAL_H
