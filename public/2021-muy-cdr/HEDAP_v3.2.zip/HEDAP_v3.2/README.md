# HEDAP — Hex Data Analysis Platform

**Version 3.2** | Qt6 Desktop Application | C++17 | CMake

HEDAP is a desktop tool for acquiring, decoding, and visualizing CAN bus data in real time. It is designed for embedded systems and battery management applications where engineers need to inspect raw CAN frames, decode signals using industry-standard DBC databases, and monitor live telemetry from hardware over a serial interface.

---

## Features

### CSV Analysis
- Load CAN log files exported from serial capture tools
- Automatic signal decoding when a DBC file is loaded alongside a CSV
- Full decoded result table with CAN ID, signal name, raw value, and formula-evaluated physical value
- Export decoded results to CSV

### Live Monitor
- Connect to hardware over UART or SLCAN protocol via any system serial port
- Real-time decoded signal table — one row per signal, updated in place, grouped by CAN ID
- Up to 4 simultaneous live charts; drag any decoded signal row onto a chart to start plotting
- 30-second rolling window with 5-minute history retained in memory
- Mouse wheel to pan through history; Ctrl+wheel to zoom the time axis
- Auto-returns to live view after 5 seconds of no interaction
- Export any chart as a 1280×720 PNG
- CSV file replay (simulation) mode for offline testing without hardware

### DBC Support
- Loads Vector `.dbc` CAN database files
- Intel (Little-Endian) and Motorola (Big-Endian) byte order
- Bit-level signal extraction with signed/unsigned support
- Automatic signal import matched against CAN IDs present in the loaded CSV or live traffic

### Manual Decoders
- Define custom byte-slice decoders without a DBC file
- JavaScript formula field (`x` = raw decimal value) for unit conversion and scaling
- Start/end byte selection with a live visual preview

---

## Requirements

| Dependency | Version |
|---|---|
| Qt | 6.5 or later (Widgets, Charts, SerialPort, Qml) |
| CMake | 3.19 or later |
| C++ standard | C++17 |
| Platform | macOS, Windows |

---

## Building

```bash
git clone <repository-url>
cd HEDAP_v3.2

cmake -B build
cmake --build build -j8
```

On macOS, run the resulting application bundle:

```bash
open build/HEDAP.app
```

On Windows, the executable is at `build\HEDAP.exe`. Deploy Qt dependencies with `windeployqt`.

---

## Project Structure

```
HEDAP_v3.2/
├── main.cpp                  # Application entry point
├── mainwindow.h/.cpp         # Main window — all pages and application logic
├── configwidget.h/.cpp       # Decoder configuration UI and HexConfig data model
├── serialworker.h/.cpp       # Serial port I/O (UART and SLCAN protocols)
├── dbcparser.h/.cpp          # Vector DBC file parser
├── droppablechartview.h/.cpp # Drag-and-drop live chart widget
├── CMakeLists.txt
└── test_data/
    ├── Model3CAN.dbc         # Example DBC (Tesla Model 3 CAN database)
    └── fake_data/
        ├── bms_fake.dbc      # Minimal BMS DBC for offline testing
        └── bms_fake_data.csv # Synthetic BMS drive-cycle log (6481 frames, ~3 min)
```

---

## CSV Format

HEDAP expects CAN log files in the following column format:

```
ts_iso_ms, epoch_ms, millis, direction, id_hex, frame_type, dlc, data_hex
```

- `id_hex` may be decimal (`512`) or hex (`0x200`) — both are accepted
- `data_hex` is the raw 8-byte CAN payload as a hex string

---

## Workflow

### Analyzing a Recorded Log

1. **Load DBC** — Toolbar → *Load DBC…* (Ctrl+D) — select a `.dbc` file
2. **Open CSV** — Toolbar → *Open CSV* (Ctrl+O) — select a CAN log
3. Decoded signals appear automatically in the result table
4. Navigate to **Graph** to plot any signal over time

### Live Hardware Monitoring

1. Connect the hardware to a USB-serial adapter
2. Select port, baud rate, and protocol (UART / SLCAN) in the Live Monitor toolbar
3. Click **Connect** — decoded signals populate the table in real time
4. Drag any signal row onto a chart panel to start plotting

### Offline Simulation

1. Click **Simulate** in the Live Monitor toolbar
2. Select a DBC and a CSV log file when prompted
3. The replay runs at approximately 100 frames/second in a continuous loop

---

## License

Internal development tool — Aspilsan Enerji A.Ş.
