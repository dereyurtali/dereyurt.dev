#include "dbcparser.h"

#include <QDebug>
#include <QFile>
#include <QRegularExpression>
#include <QSet>
#include <QTextStream>

bool DBCParser::parse(const QString &filePath) {
  m_messages.clear();
  m_error.clear();

  QFile file(filePath);
  if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
    m_error = QString("Cannot open file: %1").arg(filePath);
    return false;
  }

  // LOW-1: reject oversized files to prevent memory exhaustion
  static constexpr qint64 MAX_DBC_SIZE = 50 * 1024 * 1024; // 50 MB
  if (file.size() > MAX_DBC_SIZE) {
    m_error = QString("DBC file too large (%1 MB). Maximum is 50 MB.")
                  .arg(file.size() / (1024 * 1024));
    return false;
  }

  QTextStream in(&file);
  in.setEncoding(QStringConverter::Utf8);

  // BO_ <raw_id> <name>: <dlc> <transmitter>
  static const QRegularExpression reMessage(
      "^BO_\\s+(\\d+)\\s+(\\w+)\\s*:\\s*(\\d+)\\s*(\\w*)");

  // SG_ <name> [mux] : <startBit>|<length>@<byteOrder><valueType>
  //     (<factor>,<offset>) [<min>|<max>] "<unit>" <receivers>
  static const QRegularExpression reSignal(
      "^\\s*SG_\\s+(\\w+)\\s*(?:[Mm]\\d*)?\\s*:\\s*"
      "(\\d+)\\|(\\d+)@([01])([+-])\\s*"
      "\\(([^,]+),([^)]+)\\)\\s*"
      "\\[([^|]*)\\|([^\\]]*)\\]\\s*"
      "\"([^\"]*)\"");

  // CM_ SG_ <msg_id> <sig_name> "<comment>";
  static const QRegularExpression reCommentSig(
      "CM_\\s+SG_\\s+(\\d+)\\s+(\\w+)\\s+\"((?:[^\"\\\\]|\\\\.)*)\"");

  enum State { Idle, InMessage } state = Idle;
  DBCMessage currentMsg;

  QString fullText = in.readAll();
  file.close();

  // LOW-2: basic content validation — ensure this looks like a DBC file
  if (!fullText.contains("BO_")) {
    m_error =
        "File does not appear to be a valid DBC file (no BO_ blocks found).";
    return false;
  }

  QString normalised = fullText;
  normalised.replace("\r\n", "\n").replace('\r', '\n');

  const QStringList lines = normalised.split('\n');

  for (const QString &rawLine : lines) {
    QString line = rawLine.trimmed();

    auto mMsg = reMessage.match(line);
    if (mMsg.hasMatch()) {
      if (state == InMessage && !currentMsg.sigs.isEmpty())
        m_messages.append(currentMsg);

      state = InMessage;
      currentMsg = DBCMessage();
      quint32 rawId = mMsg.captured(1).toUInt();
      currentMsg.id = rawId;
      currentMsg.rawCanId = rawId & 0x1FFFFFFF;
      currentMsg.name = mMsg.captured(2);
      currentMsg.dlc = mMsg.captured(3).toInt();
      currentMsg.transmitter = mMsg.captured(4);
      continue;
    }

    if (state == InMessage) {
      auto mSig = reSignal.match(line);
      if (mSig.hasMatch()) {
        DBCSignal sig;
        sig.name = mSig.captured(1);
        sig.startBit = mSig.captured(2).toInt();
        sig.length = mSig.captured(3).toInt();
        sig.littleEndian = (mSig.captured(4) == "1");
        sig.isSigned = (mSig.captured(5) == "-");
        sig.factor = mSig.captured(6).toDouble();
        sig.offset = mSig.captured(7).toDouble();
        sig.minimum = mSig.captured(8).toDouble();
        sig.maximum = mSig.captured(9).toDouble();
        sig.unit = mSig.captured(10);
        currentMsg.sigs.append(sig);
      }
    }
  }

  if (state == InMessage)
    m_messages.append(currentMsg);

  // Attach CM_ SG_ comments
  auto itComment = reCommentSig.globalMatch(normalised);
  while (itComment.hasNext()) {
    auto m = itComment.next();
    quint32 mid = m.captured(1).toUInt() & 0x1FFFFFFF;
    QString sname = m.captured(2);
    QString ctext = m.captured(3);
    ctext.replace("\\\"", "\"");

    for (DBCMessage &msg : m_messages) {
      if (msg.rawCanId != mid)
        continue;
      for (DBCSignal &sig : msg.sigs) {
        if (sig.name == sname) {
          sig.comment = ctext;
          break;
        }
      }
      break;
    }
  }

  if (m_messages.isEmpty()) {
    m_error = "No BO_ message blocks found. Is this a valid .dbc file?";
    return false;
  }

  qDebug() << "[DBCParser] Parsed" << m_messages.size() << "messages from"
           << filePath;
  return true;
}

const DBCMessage *DBCParser::messageById(quint32 canId) const {
  for (const DBCMessage &msg : m_messages)
    if (msg.rawCanId == canId)
      return &msg;
  return nullptr;
}

QStringList DBCParser::allSignalNames() const {
  QSet<QString> seen;
  QStringList names;
  for (const DBCMessage &msg : m_messages)
    for (const DBCSignal &sig : msg.sigs)
      if (!seen.contains(sig.name)) {
        seen.insert(sig.name);
        names.append(sig.name);
      }
  names.sort();
  return names;
}
