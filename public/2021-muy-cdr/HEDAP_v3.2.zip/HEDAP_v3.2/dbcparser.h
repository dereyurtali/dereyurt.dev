#ifndef DBCPARSER_H
#define DBCPARSER_H

#include <QString>
#include <QStringList>
#include <QVector>
#include <QMap>

// ─────────────────────────────────────────────────────────────────────────────
//  DBCSignal: One physical signal within a CAN message.
//  Matches the SG_ record in a .dbc file.
// ─────────────────────────────────────────────────────────────────────────────
struct DBCSignal {
    QString name;
    int     startBit     = 0;
    int     length       = 8;       // bit length
    bool    littleEndian = true;    // true = Intel/LE (@1), false = Motorola/BE (@0)
    bool    isSigned     = false;   // true = signed (-)
    double  factor       = 1.0;
    double  offset       = 0.0;
    double  minimum      = 0.0;
    double  maximum      = 0.0;
    QString unit;
    QString comment;

    // ── Byte helpers ──────────────────────────────────────────────────────────
    // For Intel (LE) signals: startBit is the LSB position.
    // For Motorola (BE) signals: startBit is the MSB position (bit numbering differs).
    // These helpers give an *approximate* byte range suitable for HexConfig.
    int startByte() const
    {
        if (littleEndian)
            return startBit / 8;
        // Motorola: MSB is at startBit; convert to actual byte span
        int msb = startBit;
        // Reorder to find physical bytes; simple approximation:
        int byteOfMSB = (msb / 8);
        int byteOfLSB = byteOfMSB + (length - 1) / 8;
        return qMin(byteOfMSB, byteOfLSB);
    }
    int endByte() const
    {
        if (littleEndian)
            return (startBit + length - 1) / 8;
        int msb = startBit;
        int byteOfMSB = (msb / 8);
        int byteOfLSB = byteOfMSB + (length - 1) / 8;
        return qMax(byteOfMSB, byteOfLSB);
    }

    // Build a formula string for HexConfig ("x * factor + offset")
    QString toFormula() const
    {
        QString f;
        if (qFuzzyCompare(factor, 1.0))
            f = "x";
        else
            f = QString("x * %1").arg(factor, 0, 'g', 10);

        if (!qFuzzyIsNull(offset)) {
            if (offset > 0)
                f += QString(" + %1").arg(offset, 0, 'g', 10);
            else
                f += QString(" - %1").arg(-offset, 0, 'g', 10);
        }
        return f;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  DBCMessage: One CAN message (BO_ block) with its signals.
// ─────────────────────────────────────────────────────────────────────────────
struct DBCMessage {
    quint32 id;        // Raw CAN ID as stored in the .dbc (may include extended flag)
    quint32 rawCanId;  // 11/29-bit CAN ID (mask off extended-frame bit 0x80000000)
    QString name;
    int     dlc = 8;   // Data length in bytes
    QString transmitter;
    QVector<DBCSignal> sigs;   // named 'sigs' to avoid conflict with Qt 'signals' macro

    // Formatted hex string suitable for HexConfig.targetID matching
    QString hexID() const
    {
        return QString("0x%1").arg(rawCanId, (rawCanId > 0x7FF) ? 8 : 3,
                                   16, QChar('0')).toUpper();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  DBCParser: Reads a Vector .dbc file and exposes all messages and signals.
//
//  Supported records:  BO_  SG_  CM_  (partial)
//  Known limitation:   Multiplexed signals (M/m0) are loaded but the mux
//                      indicator is stripped – all signals appear flat.
// ─────────────────────────────────────────────────────────────────────────────
class DBCParser
{
public:
    // Returns true if the file was parsed without fatal errors.
    // On failure call errorString().
    bool parse(const QString &filePath);

    const QVector<DBCMessage> &messages() const { return m_messages; }

    // Convenience: find a message by its raw CAN ID.
    const DBCMessage *messageById(quint32 canId) const;

    // All unique signal names across all messages (useful for combo boxes).
    QStringList allSignalNames() const;

    QString errorString() const { return m_error; }

private:
    QVector<DBCMessage> m_messages;
    QString             m_error;

    // Parse one SG_ text line and fill sig; returns false on parse error.
    bool parseSignalLine(const QString &line, DBCSignal &sig);
};

#endif // DBCPARSER_H
