#include "droppablechartview.h"

#include <QChart>
#include <QDateTime>
#include <QDragEnterEvent>
#include <QDragMoveEvent>
#include <QDropEvent>
#include <QMimeData>
#include <QMouseEvent>
#include <QPainter>
#include <QWheelEvent>

// Same 10-color palette as mainwindow.cpp
const QColor DroppableChartView::kColors[10] = {
    QColor("#0078D4"), QColor("#E81123"), QColor("#107C10"), QColor("#FF8C00"),
    QColor("#5C2D91"), QColor("#008272"), QColor("#D13438"), QColor("#0063B1"),
    QColor("#767676"), QColor("#C239B3"),
};

// ─────────────────────────────────────────────────────────────────────────────
DroppableChartView::DroppableChartView(QWidget *parent)
    : QChartView(new QChart(), parent) {
  setAcceptDrops(true);
  setRenderHint(QPainter::Antialiasing);

  // Enable pinch gesture for touchpad zoom
  grabGesture(Qt::PinchGesture);

  QChart *ch = chart();
  ch->setTitle("");
  ch->legend()->setVisible(true);
  ch->legend()->setAlignment(Qt::AlignBottom);
  ch->setAnimationOptions(QChart::NoAnimation);
  ch->setMargins(QMargins(4, 4, 4, 4));

  // X axis: datetime
  m_axisX = new QDateTimeAxis(ch);
  m_axisX->setFormat("HH:mm:ss");
  m_axisX->setTitleText("Time");
  qint64 now = QDateTime::currentMSecsSinceEpoch();
  m_axisX->setRange(QDateTime::fromMSecsSinceEpoch(now - WINDOW_MS),
                    QDateTime::fromMSecsSinceEpoch(now));
  ch->addAxis(m_axisX, Qt::AlignBottom);

  // Y axis: value
  m_axisY = new QValueAxis(ch);
  m_axisY->setTitleText("Value");
  m_axisY->setRange(0.0, 1.0);
  ch->addAxis(m_axisY, Qt::AlignLeft);
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::addSignal(const QString &name) {
  if (m_series.contains(name))
    return;

  QColor color = kColors[m_nextColorIdx % 10];
  ++m_nextColorIdx;

  QLineSeries *series = new QLineSeries(chart());
  series->setName(name);
  series->setColor(color);
  series->setUseOpenGL(
      false); // OpenGL can cause issues with transparent overlay painting

  chart()->addSeries(series);
  series->attachAxis(m_axisX);
  series->attachAxis(m_axisY);

  m_series.insert(name, series);
  updateChartTitle();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::removeSignal(const QString &name) {
  QLineSeries *series = m_series.take(name);
  if (!series)
    return;
  chart()->removeSeries(series);
  delete series;
  updateChartTitle();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::clearAll() {
  for (QLineSeries *s : m_series)
    chart()->removeSeries(s);
  qDeleteAll(m_series);
  m_series.clear();
  m_nextColorIdx = 0;
  updateChartTitle();
  refreshAxes();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::appendData(const QString &name, qint64 timestampMs,
                                    double value) {
  if (!m_series.contains(name))
    addSignal(name);

  QLineSeries *series = m_series.value(name);
  series->append(timestampMs, value);

  // Trim points older than STORE_MS (5 min) to bound memory use
  while (series->count() > 1 &&
         series->at(0).x() < (double)(timestampMs - STORE_MS))
    series->remove(0);

  // Hard cap to avoid unbounded growth
  while (series->count() > MAX_PTS)
    series->remove(0);

  // Auto-return to live mode if the user hasn't touched the wheel for
  // AUTO_LIVE_MS
  if (!m_liveMode && (timestampMs - m_lastWheelMs) >= AUTO_LIVE_MS)
    setLiveMode(true);

  refreshAxes();
}

// ─────────────────────────────────────────────────────────────────────────────
QStringList DroppableChartView::trackedSignals() const {
  return m_series.keys();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::refreshAxes() {
  if (m_liveMode) {
    qint64 now = QDateTime::currentMSecsSinceEpoch();
    m_axisX->setRange(QDateTime::fromMSecsSinceEpoch(now - WINDOW_MS),
                      QDateTime::fromMSecsSinceEpoch(now));
  } else if (m_manualXMin != 0 && m_manualXMax != 0) {
    // Respect the manually set zoom range
    m_axisX->setRange(QDateTime::fromMSecsSinceEpoch(m_manualXMin),
                      QDateTime::fromMSecsSinceEpoch(m_manualXMax));
  }

  if (m_series.isEmpty()) {
    m_axisY->setRange(0.0, 1.0);
    return;
  }

  // Compute Y range from visible data only
  qint64 visMin = m_axisX->min().toMSecsSinceEpoch();
  qint64 visMax = m_axisX->max().toMSecsSinceEpoch();

  double yMin = std::numeric_limits<double>::max();
  double yMax = std::numeric_limits<double>::lowest();
  for (const QLineSeries *s : m_series) {
    for (const QPointF &pt : s->points()) {
      qint64 t = (qint64)pt.x();
      if (t < visMin || t > visMax)
        continue;
      if (pt.y() < yMin)
        yMin = pt.y();
      if (pt.y() > yMax)
        yMax = pt.y();
    }
  }
  if (yMin > yMax) {
    yMin = 0.0;
    yMax = 1.0;
  }
  double pad = (yMax - yMin) * 0.08 + 0.001;
  m_axisY->setRange(yMin - pad, yMax + pad);
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::updateChartTitle() {
  chart()->setTitle(""); // placeholder is drawn by paintEvent only
  viewport()->update();  // force immediate repaint to clear/show placeholder
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::setLiveMode(bool live) {
  m_liveMode = live;
  if (live) {
    m_manualXMin = 0;
    m_manualXMax = 0;
    refreshAxes(); // snap X axis back to the live window immediately
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Shared zoom helper: scale X axis by `factor` centered on the current view.
// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::zoomAroundCenter(double factor) {
  qint64 xMin = m_axisX->min().toMSecsSinceEpoch();
  qint64 xMax = m_axisX->max().toMSecsSinceEpoch();
  qint64 range = xMax - xMin;
  qint64 newRange = qMax((qint64)(range * factor), (qint64)1000);
  qint64 center = (xMin + xMax) / 2;

  m_manualXMin = center - newRange / 2;
  m_manualXMax = center + newRange / 2;

  m_axisX->setRange(QDateTime::fromMSecsSinceEpoch(m_manualXMin),
                    QDateTime::fromMSecsSinceEpoch(m_manualXMax));
  refreshAxes();
}

// ─────────────────────────────────────────────────────────────────────────────
//  Scroll wheel / trackpad two-finger scroll:
//    Plain scroll  = PAN left/right through time
//    Ctrl+scroll   = ZOOM in/out (smooth, proportional to delta)
// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::wheelEvent(QWheelEvent *event) {
  if (m_series.isEmpty()) {
    event->ignore();
    return;
  }

  m_liveMode = false;
  m_lastWheelMs = QDateTime::currentMSecsSinceEpoch();

  if (event->modifiers() & Qt::ControlModifier) {
    // Ctrl+scroll → ZOOM (smooth proportional factor)
    int delta = event->angleDelta().y();
    if (delta == 0) {
      event->accept();
      return;
    }
    // Smooth: scale proportionally to scroll amount
    double factor = 1.0 - (delta / 600.0); // ~0.8 for +120, ~1.2 for -120
    factor = qBound(0.5, factor, 2.0);
    zoomAroundCenter(factor);
  } else {
    // Plain scroll → PAN left/right
    // Use pixelDelta for trackpad (smooth), angleDelta for mouse wheel
    int dx;
    if (!event->pixelDelta().isNull())
      dx = event->pixelDelta().x(); // trackpad: smooth pixel pan
    else
      dx = event->angleDelta().y(); // mouse wheel: use y as horizontal scroll

    if (dx == 0) {
      event->accept();
      return;
    }

    qint64 xMin = m_axisX->min().toMSecsSinceEpoch();
    qint64 xMax = m_axisX->max().toMSecsSinceEpoch();
    double msPerPixel = (double)(xMax - xMin) / chart()->plotArea().width();
    qint64 deltaMs = (qint64)(dx * msPerPixel * 2.0);

    m_manualXMin = xMin - deltaMs;
    m_manualXMax = xMax - deltaMs;

    m_axisX->setRange(QDateTime::fromMSecsSinceEpoch(m_manualXMin),
                      QDateTime::fromMSecsSinceEpoch(m_manualXMax));
    refreshAxes();
  }
  event->accept();
}

// ─────────────────────────────────────────────────────────────────────────────
//  Pinch gesture: zoom the chart with two-finger pinch on touchpad
// ─────────────────────────────────────────────────────────────────────────────
bool DroppableChartView::event(QEvent *event) {
  if (event->type() == QEvent::Gesture)
    return gestureEvent(static_cast<QGestureEvent *>(event));
  return QChartView::event(event);
}

bool DroppableChartView::gestureEvent(QGestureEvent *event) {
  if (QPinchGesture *pinch =
          static_cast<QPinchGesture *>(event->gesture(Qt::PinchGesture))) {
    if (m_series.isEmpty())
      return true;

    m_liveMode = false;
    m_lastWheelMs = QDateTime::currentMSecsSinceEpoch();

    qreal scaleFactor = pinch->scaleFactor();
    if (scaleFactor > 0.01) {
      // pinch in = scaleFactor<1 = zoom out, pinch out = scaleFactor>1 = zoom
      // in
      double factor = 1.0 / scaleFactor;
      factor = qBound(0.5, factor, 2.0);
      zoomAroundCenter(factor);
    }
    return true;
  }
  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Single click: pause live mode.
//  Double click: resume live mode.
//  Click-and-drag: pan the chart left/right (after DRAG_THRESHOLD px).
// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::mousePressEvent(QMouseEvent *event) {
  if (event->button() == Qt::LeftButton && !m_series.isEmpty()) {
    m_dragStartPos = event->pos();
    m_dragLastPos = event->pos();
    m_dragMoved = false;
    m_isDragging = false;
    m_lastWheelMs = QDateTime::currentMSecsSinceEpoch();
    event->accept();
    return;
  }
  QChartView::mousePressEvent(event);
}

void DroppableChartView::mouseMoveEvent(QMouseEvent *event) {
  if (event->buttons() & Qt::LeftButton && !m_series.isEmpty()) {
    QPoint diff = event->pos() - m_dragStartPos;
    if (!m_dragMoved && diff.manhattanLength() >= DRAG_THRESHOLD) {
      m_dragMoved = true;
      m_isDragging = true;
      m_liveMode = false;
      setCursor(Qt::ClosedHandCursor);
    }
    if (m_isDragging) {
      const int dx = event->pos().x() - m_dragLastPos.x();
      m_dragLastPos = event->pos();

      // Pan by converting pixel delta to time delta
      qint64 xMin = m_axisX->min().toMSecsSinceEpoch();
      qint64 xMax = m_axisX->max().toMSecsSinceEpoch();
      double msPerPixel = (double)(xMax - xMin) / chart()->plotArea().width();
      qint64 deltaMs = (qint64)(dx * msPerPixel);

      m_manualXMin = xMin - deltaMs;
      m_manualXMax = xMax - deltaMs;

      m_axisX->setRange(QDateTime::fromMSecsSinceEpoch(m_manualXMin),
                        QDateTime::fromMSecsSinceEpoch(m_manualXMax));
      refreshAxes();

      m_lastWheelMs = QDateTime::currentMSecsSinceEpoch();
    }
    event->accept();
    return;
  }
  QChartView::mouseMoveEvent(event);
}

void DroppableChartView::mouseReleaseEvent(QMouseEvent *event) {
  if (event->button() == Qt::LeftButton) {
    if (m_isDragging) {
      m_isDragging = false;
      setCursor(Qt::ArrowCursor);
    } else if (!m_dragMoved && !m_inDoubleClick) {
      // Simple click (no drag, not part of a double-click) → pause live mode
      if (m_liveMode) {
        m_liveMode = false;
        // Freeze current view range
        m_manualXMin = m_axisX->min().toMSecsSinceEpoch();
        m_manualXMax = m_axisX->max().toMSecsSinceEpoch();
        m_lastWheelMs = QDateTime::currentMSecsSinceEpoch();
      }
    }
    m_dragMoved = false;
    m_inDoubleClick = false;
    event->accept();
    return;
  }
  QChartView::mouseReleaseEvent(event);
}

void DroppableChartView::mouseDoubleClickEvent(QMouseEvent *event) {
  if (event->button() == Qt::LeftButton) {
    // Flag suppresses the upcoming mouseReleaseEvent from pausing again.
    // Then immediately resume live mode.
    m_inDoubleClick = true;
    setLiveMode(true);
    event->accept();
    return;
  }
  QChartView::mouseDoubleClickEvent(event);
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::dragEnterEvent(QDragEnterEvent *event) {
  if (event->mimeData()->hasFormat("application/x-hedap-signal"))
    event->acceptProposedAction();
  else
    event->ignore();
}

void DroppableChartView::dragMoveEvent(QDragMoveEvent *event) {
  if (event->mimeData()->hasFormat("application/x-hedap-signal"))
    event->acceptProposedAction();
  else
    event->ignore();
}

void DroppableChartView::dropEvent(QDropEvent *event) {
  if (!event->mimeData()->hasFormat("application/x-hedap-signal")) {
    event->ignore();
    return;
  }
  QString payload =
      QString::fromUtf8(event->mimeData()->data("application/x-hedap-signal"));
  const QStringList names = payload.split(',', Qt::SkipEmptyParts);
  for (const QString &name : names)
    addSignal(name.trimmed());
  event->acceptProposedAction();
}

// ─────────────────────────────────────────────────────────────────────────────
void DroppableChartView::paintEvent(QPaintEvent *event) {
  QChartView::paintEvent(event);

  // Draw a placeholder message when no series have been added yet
  if (!m_series.isEmpty())
    return;

  QPainter p(viewport());
  p.setRenderHint(QPainter::Antialiasing);

  QFont f = p.font();
  f.setPointSize(11);
  p.setFont(f);
  p.setPen(QColor(0x88, 0x88, 0x88));

  QRect r = viewport()->rect();
  p.drawText(r, Qt::AlignCenter,
             "Drop a signal here to start plotting\n"
             "(drag from Decoded Signals or Message Rate tables)");
}
