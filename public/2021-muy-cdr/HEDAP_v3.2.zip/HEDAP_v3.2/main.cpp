#include "mainwindow.h"

#include <QApplication>
#include <QDir>
#include <QLockFile>
#include <QMessageBox>
#include <QStandardPaths>

int main(int argc, char *argv[]) {
  QApplication a(argc, argv);
  a.setApplicationName("HEDAP");
  a.setOrganizationName("HEDAP");

  // ── Tek örnek koruması ──────────────────────────────────────────────────
  // MED-4: Lock file app data dizinine taşındı (/tmp yerine)
  // Paylaşımlı sistemlerde symlink saldırısını önler.
  QString lockDir =
      QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
  QDir().mkpath(lockDir);
  QLockFile lockFile(lockDir + "/HEDAP_instance.lock");
  lockFile.setStaleLockTime(0); // Eski kilidi temizleme — her zaman taze say

  if (!lockFile.tryLock(100)) {
    QMessageBox::warning(
        nullptr, "HEDAP – Already Running",
        "HEDAP is already open.\n\nOnly one instance can run at a time.");
    return 1;
  }
  // ───────────────────────────────────────────────────────────────────────

  MainWindow w;
  w.show();
  return a.exec();

  // lockFile kapsam dışına çıkınca otomatik serbest bırakılır
}
