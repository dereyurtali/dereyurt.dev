#ifndef DROPPABLECHARTVIEW_H
#define DROPPABLECHARTVIEW_H

#include <QChartView>
#include <QDateTimeAxis>
#include <QGestureEvent>
#include <QHash>
#include <QLineSeries>
#include <QMouseEvent>
#include <QPoint>
#include <QValueAxis>
#include <QtGlobal>

// ─────────────────────────────────────────────────────────────────────────────
//  DroppableChartView
//  A QChartView that accepts drag-and-drop of signal names via the MIME type
//  "application/x-hedap-signal".  Displays a rolling 30-second time window.
//
//  Usage:
//    chart->addSignal("Voltage");          // manual add
//    chart->appendData("Voltage", ts, v);  // push a live data point
//    // or just drag a row from the decoded-signals table onto the widget
// ─────────────────────────────────────────────────────────────────────────────
class DroppableChartView : public QChartView {
  Q_OBJECT

public:
  explicit DroppableChartView(QWidget *parent = nullptr);

  // Add a signal series (no-op if already present)
  void addSignal(const QString &name);
  // Remove a signal series
  void removeSignal(const QString &name);
  // Remove all series
  void clearAll();
  // Append a live data point; adds the signal automatically if not present
  void appendData(const QString &name, qint64 timestampMs, double value);
  // Returns names of all currently tracked signals
  QStringList trackedSignals() const;

  // Live mode: auto-scrolls X axis to show the last 30s.
  // When the user scrolls with the mouse wheel, live mode is paused so
  // they can inspect historical data. Call setLiveMode(true) to resume.
  void setLiveMode(bool live);
  bool isLiveMode() const { return m_liveMode; }
  // Single click = pause live, Double click = resume live
  void mouseDoubleClickEvent(QMouseEvent *event) override;

protected:
  void dragEnterEvent(QDragEnterEvent *event) override;
  void dragMoveEvent(QDragMoveEvent *event) override;
  void dropEvent(QDropEvent *event) override;
  void paintEvent(QPaintEvent *event) override;
  void wheelEvent(QWheelEvent *event) override;
  void mousePressEvent(QMouseEvent *event) override;
  void mouseMoveEvent(QMouseEvent *event) override;
  void mouseReleaseEvent(QMouseEvent *event) override;
  bool event(QEvent *event) override;

private:
  void refreshAxes();
  void updateChartTitle();
  void zoomAroundCenter(double factor);
  bool gestureEvent(QGestureEvent *event);

  QHash<QString, QLineSeries *> m_series;
  QDateTimeAxis *m_axisX = nullptr;
  QValueAxis *m_axisY = nullptr;
  int m_nextColorIdx = 0;

  bool m_liveMode = true; // false = user is panning/inspecting history
  qint64 m_lastWheelMs =
      0; // timestamp of last user interaction (ms since epoch)
  bool m_isDragging = false;   // true while left-button drag is in progress
  bool m_inDoubleClick = false; // suppresses release-pause on double-click
  QPoint m_dragStartPos;       // position when mouse was first pressed
  QPoint m_dragLastPos;        // previous mouse position during drag
  bool m_dragMoved = false;    // true once mouse moved beyond threshold

  // Manual zoom range (used when not in live mode)
  qint64 m_manualXMin = 0;
  qint64 m_manualXMax = 0;

  // Display window shown in live mode
  static constexpr int WINDOW_MS = 30'000;
  // How much history to retain in memory (5 minutes)
  static constexpr int STORE_MS = 300'000;
  // Max points per series to keep rendering fast
  static constexpr int MAX_PTS = 10'000;
  // Auto-return to live mode after this many ms of no wheel input
  static constexpr int AUTO_LIVE_MS = 5'000;
  // Minimum mouse movement (px) before a press becomes a drag
  static constexpr int DRAG_THRESHOLD = 5;

  static const QColor kColors[10];
};

#endif // DROPPABLECHARTVIEW_H
