#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtCharts>
#include <QChartView>
#include <QLineSeries>
#include <QDateTimeAxis>
#include <QValueAxis>
#include <QMainWindow>
#include <QVector>
#include <QStandardItemModel>
#include <QJSEngine>
#include <QLabel>
#include <QToolBar>
#include <QAction>

#include "configdialog.h"

struct RawData {
    qint64  timestamp;
    QString isoTime;
    QString id;
    QString dataHex;
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void resizeEvent(QResizeEvent *event) override;

private slots:
    void on_btn_load_clicked();
    void on_btn_unload_clicked();
    void on_btn_filter_clicked();
    void on_btn_reset_clicked();
    void on_btn_conf_clicked();
    void on_btn_export_clicked();
    void on_btn_exportdata_clicked();
    void on_btn_graph_clicked();

    void onThemeLight();
    void onThemeDark();
    void onAbout();

private:
    Ui::MainWindow       *ui;
    QToolBar             *m_toolbar;

    QVector<RawData>      m_allData;
    QStandardItemModel   *m_summaryModel;
    QStandardItemModel   *m_resultModel;

    QStringList           m_activeFilters;
    QVector<HexConfig>    m_savedConfigs;
    bool                  m_isDark = false;

    QAction *m_actLoad;
    QAction *m_actUnload;
    QAction *m_actFilter;
    QAction *m_actReset;
    QAction *m_actConf;
    QAction *m_actGraph;
    QAction *m_actExportCsv;
    QAction *m_actExportData;

    void buildToolbar();
    void setupTables();
    void parseAndStoreLine(const QString &line);
    void populateSummaryTable(const QStringList &filterIds = QStringList());
    void setInterfaceState(bool hasData);
    void applyTheme(bool dark);
    void resizeSplitterAndColumns();

    void calculateAndPopulateResultTable();
    double evaluateFormula(double rawValue, const QString &formula);

    void loadConfigsFromFile();
    void saveConfigsToFile();

    // Tema ayarları için yeni eklendi
    void loadSettings();
    void saveSettings();
};

#endif // MAINWINDOW_H
