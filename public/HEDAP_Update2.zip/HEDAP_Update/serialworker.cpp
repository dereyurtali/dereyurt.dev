#include "serialworker.h"
#include <QDateTime>
#include <QDebug>

SerialWorker::SerialWorker(QObject *parent)
    : QObject(parent)
    , m_serial(new QSerialPort(this))
    , m_protocol(Protocol::UART)
    , m_statsTimer(new QTimer(this))
    , m_frameCounter(0)
{
    connect(m_serial, &QSerialPort::readyRead,
            this, &SerialWorker::onReadyRead);
    connect(m_serial, &QSerialPort::errorOccurred,
            this, &SerialWorker::onSerialError);
    m_statsTimer->setInterval(1000);
    connect(m_statsTimer, &QTimer::timeout, this, &SerialWorker::onStatsTimer);
}

SerialWorker::~SerialWorker()
{
    disconnectPort();
}

QStringList SerialWorker::availablePorts()
{
    QStringList result;
    for (const QSerialPortInfo &info : QSerialPortInfo::availablePorts()) {
        if (!info.description().isEmpty())
            result << QString("%1  –  %2").arg(info.portName(), info.description());
        else
            result << info.portName();
    }
    return result;
}

bool SerialWorker::isConnected() const { return m_serial->isOpen(); }

void SerialWorker::connectPort(const QString &portName, int baudRate, const QString &protocolStr)
{
    if (m_serial->isOpen()) disconnectPort();

    // Strip description part if present ("COM3  –  USB Serial" → "COM3")
    QString cleanPort = portName;
    if (cleanPort.contains("  –  "))
        cleanPort = cleanPort.section("  –  ", 0, 0).trimmed();
    else
        cleanPort = cleanPort.section(' ', 0, 0).trimmed();
    if (cleanPort.isEmpty()) cleanPort = portName.trimmed();

    m_serial->setPortName(cleanPort);
    m_serial->setBaudRate(baudRate);
    m_serial->setDataBits(QSerialPort::Data8);
    m_serial->setParity(QSerialPort::NoParity);
    m_serial->setStopBits(QSerialPort::OneStop);
    m_serial->setFlowControl(QSerialPort::NoFlowControl);
    m_protocol = (protocolStr == "CAN_SLCAN") ? Protocol::CAN_SLCAN : Protocol::UART;

    if (!m_serial->open(QIODevice::ReadWrite)) {
        emit errorOccurred(tr("Cannot open %1: %2").arg(cleanPort, m_serial->errorString()));
        return;
    }

    m_rxBuffer.clear();
    m_rawBuffer.clear();
    m_frameCounter = 0;
    m_statsTimer->start();

    qDebug() << "[SerialWorker] Connected to" << cleanPort << "@" << baudRate
             << "| Protocol:" << protocolStr;

    emit connectionChanged(true);
}

void SerialWorker::disconnectPort()
{
    m_statsTimer->stop();
    if (m_serial->isOpen()) {
        m_serial->close();
        emit connectionChanged(false);
        qDebug() << "[SerialWorker] Disconnected.";
    }
}

void SerialWorker::sendRaw(const QByteArray &data)
{
    if (m_serial->isOpen()) m_serial->write(data);
}

void SerialWorker::onReadyRead()
{
    QByteArray incoming = m_serial->readAll();

    if (m_protocol == Protocol::UART) {
        m_rxBuffer += QString::fromLatin1(incoming);
        while (m_rxBuffer.contains('\n')) {
            int idx = m_rxBuffer.indexOf('\n');
            QString line = m_rxBuffer.left(idx).trimmed();
            m_rxBuffer.remove(0, idx + 1);
            if (!line.isEmpty()) { m_frameCounter++; emit lineReceived(line); }
        }
    } else {
        // SLCAN: frames terminated by '\r'
        m_rawBuffer += incoming;
        while (m_rawBuffer.contains('\r')) {
            int idx = m_rawBuffer.indexOf('\r');
            QString frame = QString::fromLatin1(m_rawBuffer.left(idx)).trimmed();
            m_rawBuffer.remove(0, idx + 1);
            if (!frame.isEmpty()) {
                QString csvLine = parseSLCANFrame(frame);
                if (!csvLine.isEmpty()) { m_frameCounter++; emit lineReceived(csvLine); }
            }
        }
    }
}

void SerialWorker::onStatsTimer()
{
    emit statsUpdated(m_frameCounter);
    m_frameCounter = 0;
}

void SerialWorker::onSerialError(QSerialPort::SerialPortError error)
{
    if (error == QSerialPort::NoError) return;
    if (error == QSerialPort::ResourceError) disconnectPort(); // device unplugged
    emit errorOccurred(m_serial->errorString());
}

// ─── SLCAN Frame Parser ──────────────────────────────────────────────────────
// Standard: t<ID:3><DLC:1><DATA:DLC*2>
// Extended: T<ID:8><DLC:1><DATA:DLC*2>
// Example:  t1230DEADBEEF
QString SerialWorker::parseSLCANFrame(const QString &frame)
{
    if (frame.isEmpty()) return {};
    QChar type = frame[0].toUpper();
    bool extended = (type == 'T');
    if (type != 'T' && type.toLower() != 't') return {}; // skip z/Z/status

    int idLen  = extended ? 8 : 3;
    int minLen = 1 + idLen + 1;
    if (frame.length() < minLen) return {};

    bool ok;
    QString idStr = frame.mid(1, idLen).toUpper();
    idStr.toUInt(&ok, 16);
    if (!ok) return {};

    int dlc = frame.mid(1 + idLen, 1).toInt(&ok);
    if (!ok || dlc < 0 || dlc > 8) return {};
    if (frame.length() < minLen + dlc * 2) return {};

    QString dataHex = frame.mid(1 + idLen + 1, dlc * 2).toUpper();

    // Group bytes with spaces: "DEADBEEF" → "DE AD BE EF"
    QString prettyHex;
    for (int i = 0; i < dataHex.length(); i += 2) {
        if (!prettyHex.isEmpty()) prettyHex += ' ';
        prettyHex += dataHex.mid(i, 2);
    }

    return slcanToCSV(idStr, prettyHex);
}

// Convert to HEDAP CSV format: parts[0]=isoTime, [1]=epoch, [4]=id, [7]=dataHex
QString SerialWorker::slcanToCSV(const QString &id, const QString &dataHex)
{
    QDateTime now   = QDateTime::currentDateTime();
    QString isoTime = now.toString("yyyy-MM-dd HH:mm:ss.zzz");
    QString epoch   = QString::number(now.toMSecsSinceEpoch());
    return QString("%1,%2,,,0x%3,,,  %4").arg(isoTime, epoch, id, dataHex);
}
