#ifndef SERIALWORKER_H
#define SERIALWORKER_H

#include <QObject>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTimer>

// ─────────────────────────────────────────────────────────────────────────────
//  SerialWorker
//  Arka planda çalışan serial port okuyucu.
//  CAN (SLCAN protokolü) ve UART (CSV satır tabanlı) destekler.
//
//  SLCAN örnek frame:  t1230DEADBEEF\r
//     t = standart CAN
//     123 = ID (hex)
//     0 = DLC (veri uzunluğu)... aslında 8 byte için 8 yazılır
//     DEADBEEF = data
//     \r = frame sonu
//
//  UART frame: CSV formatı, her satır bir kayıt.
//  ─────────────────────────────────────────────────────────────────────────
class SerialWorker : public QObject
{
    Q_OBJECT

public:
    enum class Protocol {
        UART,       // CSV tabanlı, satır ayrımlı
        CAN_SLCAN   // SLCAN (SocketCAN/CANable/USB2CAN tarzı USB dongle)
    };
    Q_ENUM(Protocol)

    explicit SerialWorker(QObject *parent = nullptr);
    ~SerialWorker();

    static QStringList availablePorts();
    bool isConnected() const;

public slots:
    // protocol: "UART" or "CAN_SLCAN"
    void connectPort(const QString &portName, int baudRate, const QString &protocol);
    void disconnectPort();
    void sendRaw(const QByteArray &data);

signals:
    // Her satır / frame ayrıştırıldığında
    void lineReceived(const QString &csvLine);

    // Bağlantı durumu değişimi
    void connectionChanged(bool connected);

    // Hata mesajı
    void errorOccurred(const QString &errorMessage);

    // İstatistik (saniyede frame sayısı vb.)
    void statsUpdated(int framesPerSec);

private slots:
    void onReadyRead();
    void onStatsTimer();
    void onSerialError(QSerialPort::SerialPortError error);

private:
    QSerialPort *m_serial;
    Protocol     m_protocol;
    QString      m_rxBuffer;      // Bitmemiş satırlar için tampon
    QByteArray   m_rawBuffer;     // Ham byte tamponu (SLCAN için)
    QTimer      *m_statsTimer;
    int          m_frameCounter;  // İstatistik için

    // SLCAN frame ayrıştırıcı
    // Geri dönen değer: ayrıştırılmış HEDAP CSV satırı (boş ise geçersiz frame)
    QString parseSLCANFrame(const QString &frame);

    // SLCAN frame'ini HEDAP CSV formatına dönüştürür:
    // "isoTime,epoch,,,id,,,dataHex"
    QString slcanToCSV(const QString &id, const QString &dataHex);
};

#endif // SERIALWORKER_H
