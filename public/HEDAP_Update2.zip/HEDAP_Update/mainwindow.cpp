#include "mainwindow.h"
#include <limits>
#include "ui_mainwindow.h"

#include <QApplication>
#include <QStyleFactory>
#include <QPalette>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonDocument>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QMap>
#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QListWidget>
#include <QDialogButtonBox>
#include <QResizeEvent>
#include <QHeaderView>
#include <QFileInfo>
#include <QToolButton>
#include <QPainter>

static const char *QSS_COMMON = R"(
/* Tablo: sıkı satır + monospace font */
QTableView {
    font-family: "Consolas", "Courier New", monospace;
    font-size: 12px;
}
QTableView::item { padding: 1px 4px; }

/* Header görünümü – palette ile palette rengi üzerine gradient */
QHeaderView::section {
    font-size: 11px;
    font-weight: bold;
    padding: 2px 6px;
    border: none;
    border-right:  1px solid palette(mid);
    border-bottom: 1px solid palette(shadow);
}
QHeaderView::section:last { border-right: none; }

/* Toolbar buton */
QToolButton {
    padding: 2px 8px;
    border: 1px solid transparent;
    border-radius: 2px;
    font-size: 12px;
    min-height: 22px;
}
QToolButton:hover   { border: 1px solid palette(mid); }
QToolButton:pressed { border: 1px solid palette(dark); }
QToolButton:disabled { color: palette(mid); }

/* Bölüm başlıkları */
QLabel#lbl_summary_header,
QLabel#lbl_result_header {
    font-weight: bold;
    font-size: 12px;
    padding: 1px 2px;
    margin-bottom: 1px;
}

/* Status bar */
QStatusBar { font-size: 11px; }
QStatusBar::item { border: none; }

/* Menü */
QMenuBar { font-size: 12px; }
QMenu    { font-size: 12px; }
QMenu::item { padding: 4px 24px 4px 12px; }
QMenu::separator { height: 1px; margin: 2px 0; }

/* Scroll */
QScrollBar:vertical   { width: 12px; }
QScrollBar:horizontal { height: 12px; }
QScrollBar::add-line, QScrollBar::sub-line { width:0; height:0; }

/* Splitter */
QSplitter::handle:horizontal { width: 4px; }
)";

static void buildLightPalette(QApplication *app)
{
    QPalette p;
    p.setColor(QPalette::Window,          QColor(0xF0, 0xF0, 0xF0));
    p.setColor(QPalette::WindowText,      QColor(0x20, 0x20, 0x20));
    p.setColor(QPalette::Base,            QColor(0xFF, 0xFF, 0xFF));
    p.setColor(QPalette::AlternateBase,   QColor(0xF5, 0xF5, 0xF5));
    p.setColor(QPalette::Text,            QColor(0x20, 0x20, 0x20));
    p.setColor(QPalette::BrightText,      Qt::white);
    p.setColor(QPalette::Button,          QColor(0xE1, 0xE1, 0xE1));
    p.setColor(QPalette::ButtonText,      QColor(0x20, 0x20, 0x20));
    p.setColor(QPalette::Highlight,       QColor(0x38, 0x75, 0xD7));
    p.setColor(QPalette::HighlightedText, Qt::white);
    p.setColor(QPalette::ToolTipBase,     QColor(0xFF, 0xFF, 0xE0));
    p.setColor(QPalette::ToolTipText,     QColor(0x20, 0x20, 0x20));
    p.setColor(QPalette::Link,            QColor(0x00, 0x78, 0xD4));
    p.setColor(QPalette::Mid,             QColor(0xC0, 0xC0, 0xC0));
    p.setColor(QPalette::Midlight,        QColor(0xD8, 0xD8, 0xD8));
    p.setColor(QPalette::Dark,            QColor(0xA0, 0xA0, 0xA0));
    p.setColor(QPalette::Shadow,          QColor(0x80, 0x80, 0x80));
    p.setColor(QPalette::Disabled, QPalette::WindowText, QColor(0xA0, 0xA0, 0xA0));
    p.setColor(QPalette::Disabled, QPalette::Text,       QColor(0xA0, 0xA0, 0xA0));
    p.setColor(QPalette::Disabled, QPalette::ButtonText, QColor(0xA0, 0xA0, 0xA0));
    p.setColor(QPalette::Disabled, QPalette::Base,       QColor(0xF0, 0xF0, 0xF0));
    app->setPalette(p);
}

static void buildDarkPalette(QApplication *app)
{
    QPalette p;
    p.setColor(QPalette::Window,          QColor(0x2D, 0x2D, 0x2D));
    p.setColor(QPalette::WindowText,      QColor(0xD4, 0xD4, 0xD4));
    p.setColor(QPalette::Base,            QColor(0x1E, 0x1E, 0x1E));
    p.setColor(QPalette::AlternateBase,   QColor(0x25, 0x25, 0x26));
    p.setColor(QPalette::Text,            QColor(0xD4, 0xD4, 0xD4));
    p.setColor(QPalette::BrightText,      Qt::white);
    p.setColor(QPalette::Button,          QColor(0x3C, 0x3C, 0x3C));
    p.setColor(QPalette::ButtonText,      QColor(0xD4, 0xD4, 0xD4));
    p.setColor(QPalette::Highlight,       QColor(0x26, 0x4F, 0x78));
    p.setColor(QPalette::HighlightedText, Qt::white);
    p.setColor(QPalette::ToolTipBase,     QColor(0x45, 0x45, 0x45));
    p.setColor(QPalette::ToolTipText,     QColor(0xD4, 0xD4, 0xD4));
    p.setColor(QPalette::Link,            QColor(0x4E, 0xC9, 0xB0));
    p.setColor(QPalette::Mid,             QColor(0x55, 0x55, 0x55));
    p.setColor(QPalette::Midlight,        QColor(0x44, 0x44, 0x44));
    p.setColor(QPalette::Dark,            QColor(0x20, 0x20, 0x20));
    p.setColor(QPalette::Shadow,          QColor(0x14, 0x14, 0x14));
    p.setColor(QPalette::Disabled, QPalette::WindowText, QColor(0x60, 0x60, 0x60));
    p.setColor(QPalette::Disabled, QPalette::Text,       QColor(0x60, 0x60, 0x60));
    p.setColor(QPalette::Disabled, QPalette::ButtonText, QColor(0x60, 0x60, 0x60));
    p.setColor(QPalette::Disabled, QPalette::Base,       QColor(0x28, 0x28, 0x28));
    app->setPalette(p);
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_toolbar(nullptr)
    , m_summaryModel(new QStandardItemModel(this))
    , m_resultModel(new QStandardItemModel(this))
{
    QApplication::setStyle(QStyleFactory::create("Fusion"));

    ui->setupUi(this);
    setWindowTitle("HEDAP  –  Hex Data Analysis Platform");

    buildToolbar();
    setupTables();

    ui->splitter_main->setSizes({8000, 8000});

    connect(ui->action_load,        &QAction::triggered, this, &MainWindow::on_btn_load_clicked);
    connect(ui->action_unload,      &QAction::triggered, this, &MainWindow::on_btn_unload_clicked);
    connect(ui->action_export_csv,  &QAction::triggered, this, &MainWindow::on_btn_export_clicked);
    connect(ui->action_export_data, &QAction::triggered, this, &MainWindow::on_btn_exportdata_clicked);
    connect(ui->action_filter,      &QAction::triggered, this, &MainWindow::on_btn_filter_clicked);
    connect(ui->action_reset,       &QAction::triggered, this, &MainWindow::on_btn_reset_clicked);
    connect(ui->action_conf,        &QAction::triggered, this, &MainWindow::on_btn_conf_clicked);
    connect(ui->action_graph,       &QAction::triggered, this, &MainWindow::on_btn_graph_clicked);
    connect(ui->action_theme_light, &QAction::triggered, this, &MainWindow::onThemeLight);
    connect(ui->action_theme_dark,  &QAction::triggered, this, &MainWindow::onThemeDark);
    connect(ui->action_about,       &QAction::triggered, this, &MainWindow::onAbout);
    connect(ui->action_exit,        &QAction::triggered, this, &QMainWindow::close);

    setInterfaceState(false);

    // Tema ayarlarını diskten oku ve uygula
    loadSettings();
    applyTheme(m_isDark);

    loadConfigsFromFile();
    statusBar()->showMessage("Ready. Open a CSV file (Ctrl+O).");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::buildToolbar()
{
    m_toolbar = addToolBar("Main");
    m_toolbar->setMovable(false);
    m_toolbar->setFloatable(false);
    m_toolbar->setIconSize(QSize(16, 16));
    m_toolbar->setToolButtonStyle(Qt::ToolButtonTextOnly);

    m_actLoad = m_toolbar->addAction("Open CSV");
    m_actLoad->setShortcut(QKeySequence::Open);
    m_actLoad->setToolTip("Open CSV file (Ctrl+O)");
    connect(m_actLoad, &QAction::triggered, this, &MainWindow::on_btn_load_clicked);

    m_actUnload = m_toolbar->addAction("Close");
    m_actUnload->setToolTip("Close current file");
    connect(m_actUnload, &QAction::triggered, this, &MainWindow::on_btn_unload_clicked);

    m_toolbar->addSeparator();

    m_actFilter = m_toolbar->addAction("Filter…");
    m_actFilter->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_F));
    m_actFilter->setToolTip("Filter by message ID (Ctrl+F)");
    connect(m_actFilter, &QAction::triggered, this, &MainWindow::on_btn_filter_clicked);

    m_actReset = m_toolbar->addAction("Reset");
    m_actReset->setToolTip("Clear active filter");
    connect(m_actReset, &QAction::triggered, this, &MainWindow::on_btn_reset_clicked);

    m_toolbar->addSeparator();

    m_actConf = m_toolbar->addAction("Decoders…");
    m_actConf->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_K));
    m_actConf->setToolTip("Configure byte decoders (Ctrl+K)");
    connect(m_actConf, &QAction::triggered, this, &MainWindow::on_btn_conf_clicked);

    m_actGraph = m_toolbar->addAction("Plot Graph");
    m_actGraph->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_G));
    m_actGraph->setToolTip("Visualize decoded values (Ctrl+G)");
    connect(m_actGraph, &QAction::triggered, this, &MainWindow::on_btn_graph_clicked);

    m_toolbar->addSeparator();

    m_actExportCsv = m_toolbar->addAction("Export CSV…");
    m_actExportCsv->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_E));
    m_actExportCsv->setToolTip("Export raw data as CSV (Ctrl+E)");
    connect(m_actExportCsv, &QAction::triggered, this, &MainWindow::on_btn_export_clicked);

    m_actExportData = m_toolbar->addAction("Export Decoded…");
    m_actExportData->setToolTip("Export decoded values as CSV");
    connect(m_actExportData, &QAction::triggered, this, &MainWindow::on_btn_exportdata_clicked);
}

void MainWindow::setupTables()
{
    ui->tbl_summary->setModel(m_summaryModel);
    ui->tbl_summary->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tbl_summary->verticalHeader()->setVisible(false);
    ui->tbl_summary->verticalHeader()->setDefaultSectionSize(20);
    ui->tbl_summary->setSelectionMode(QAbstractItemView::SingleSelection);

    QHeaderView *sh = ui->tbl_summary->horizontalHeader();
    sh->setHighlightSections(false);
    sh->setStretchLastSection(true);
    sh->setSectionResizeMode(QHeaderView::Interactive);
    sh->setDefaultSectionSize(90);

    ui->tbl_result->setModel(m_resultModel);
    ui->tbl_result->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tbl_result->verticalHeader()->setVisible(false);
    ui->tbl_result->verticalHeader()->setDefaultSectionSize(20);
    ui->tbl_result->setSelectionMode(QAbstractItemView::SingleSelection);

    QHeaderView *rh = ui->tbl_result->horizontalHeader();
    rh->setHighlightSections(false);
    rh->setStretchLastSection(true);
    rh->setSectionResizeMode(QHeaderView::Interactive);
    rh->setDefaultSectionSize(110);
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    resizeSplitterAndColumns();
}

void MainWindow::resizeSplitterAndColumns()
{
    int total = ui->splitter_main->width();
    if (total > 100) {
        int half = (total - ui->splitter_main->handleWidth()) / 2;
        ui->splitter_main->setSizes({half, half});
    }

    if (m_summaryModel->columnCount() >= 4) {
        int w = ui->tbl_summary->viewport()->width();
        if (w > 80) {
            QHeaderView *h = ui->tbl_summary->horizontalHeader();
            h->resizeSection(0, qRound(w * 0.18));
            h->resizeSection(1, qRound(w * 0.12));
            h->resizeSection(2, qRound(w * 0.35));
        }
    }

    if (m_resultModel->columnCount() >= 5) {
        int w = ui->tbl_result->viewport()->width();
        if (w > 80) {
            QHeaderView *h = ui->tbl_result->horizontalHeader();
            h->resizeSection(0, qRound(w * 0.22));
            h->resizeSection(1, qRound(w * 0.10));
            h->resizeSection(2, qRound(w * 0.18));
            h->resizeSection(3, qRound(w * 0.14));
        }
    }
}

void MainWindow::setInterfaceState(bool hasData)
{
    m_actUnload->setEnabled(hasData);
    m_actFilter->setEnabled(hasData);
    m_actReset->setEnabled(hasData);
    m_actConf->setEnabled(hasData);
    m_actGraph->setEnabled(hasData);
    m_actExportCsv->setEnabled(hasData);
    m_actExportData->setEnabled(hasData);
    ui->action_unload->setEnabled(hasData);
    ui->action_filter->setEnabled(hasData);
    ui->action_reset->setEnabled(hasData);
    ui->action_conf->setEnabled(hasData);
    ui->action_graph->setEnabled(hasData);
    ui->action_export_csv->setEnabled(hasData);
    ui->action_export_data->setEnabled(hasData);
}

void MainWindow::applyTheme(bool dark)
{
    m_isDark = dark;
    if (dark) buildDarkPalette(qApp);
    else      buildLightPalette(qApp);
    setStyleSheet(QSS_COMMON);
}

void MainWindow::parseAndStoreLine(const QString &line)
{
    QStringList parts = line.split(',');
    if (parts.size() < 8) return;
    RawData data;
    data.isoTime   = parts[0].trimmed();
    data.timestamp = parts[1].trimmed().toLongLong();
    data.id        = parts[4].trimmed();
    data.dataHex   = parts[7].trimmed();
    m_allData.append(data);
}

void MainWindow::populateSummaryTable(const QStringList &filterIds)
{
    m_summaryModel->clear();
    m_summaryModel->setHorizontalHeaderLabels({"ID", "Frames", "First Seen", "Last Seen"});

    struct GroupInfo {
        int count = 0;
        qint64 minEpoch = -1, maxEpoch = -1;
        QString startTime, endTime;
    };
    QMap<QString, GroupInfo> groups;

    for (const RawData &row : m_allData) {
        if (!filterIds.isEmpty() && !filterIds.contains(row.id)) continue;
        GroupInfo &g = groups[row.id];
        g.count++;
        if (g.minEpoch == -1 || row.timestamp < g.minEpoch) { g.minEpoch = row.timestamp; g.startTime = row.isoTime; }
        if (g.maxEpoch == -1 || row.timestamp > g.maxEpoch) { g.maxEpoch = row.timestamp; g.endTime   = row.isoTime; }
    }

    for (auto it = groups.begin(); it != groups.end(); ++it) {
        QList<QStandardItem*> items;
        items << new QStandardItem(it.key())
              << new QStandardItem(QString::number(it.value().count))
              << new QStandardItem(it.value().startTime)
              << new QStandardItem(it.value().endTime);
        items[1]->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
        m_summaryModel->appendRow(items);
    }
    resizeSplitterAndColumns();
}

void MainWindow::calculateAndPopulateResultTable()
{
    m_resultModel->clear();
    m_resultModel->setHorizontalHeaderLabels({"Timestamp", "ID", "Decoder", "Raw Hex", "Value"});

    for (const RawData &row : m_allData) {
        if (!m_activeFilters.isEmpty() && !m_activeFilters.contains(row.id)) continue;
        for (const HexConfig &conf : m_savedConfigs) {
            if (conf.targetID != row.id) continue;
            QString cleanHex = row.dataHex.simplified().replace(" ", "");
            int startPos = conf.startByte * 2;
            int length   = (conf.endByte - conf.startByte + 1) * 2;
            if (startPos + length > cleanHex.length()) continue;
            QString subHex = cleanHex.mid(startPos, length);
            bool ok;
            qint64 rawVal = subHex.toLongLong(&ok, 16);
            if (!ok) continue;
            double finalVal = evaluateFormula((double)rawVal, conf.formula);

            QList<QStandardItem*> items;
            items << new QStandardItem(row.isoTime)
                  << new QStandardItem(row.id)
                  << new QStandardItem(conf.name)
                  << new QStandardItem(QString("0x%1").arg(subHex.toUpper()))
                  << new QStandardItem(QString::number(finalVal, 'f', 4));
            items[4]->setTextAlignment(Qt::AlignRight | Qt::AlignVCenter);
            m_resultModel->appendRow(items);
        }
    }
    resizeSplitterAndColumns();
}

double MainWindow::evaluateFormula(double rawValue, const QString &formula)
{
    if (formula.isEmpty()) return rawValue;
    static QJSEngine engine;
    engine.globalObject().setProperty("x", rawValue);
    QJSValue result = engine.evaluate(formula);
    if (result.isError()) return rawValue;
    return result.toNumber();
}

void MainWindow::on_btn_load_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open CSV File", "", "CSV Files (*.csv);;All Files (*)");
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "Cannot open file:\n" + fileName);
        return;
    }

    m_allData.clear(); m_summaryModel->clear(); m_resultModel->clear(); m_activeFilters.clear();

    QTextStream in(&file);
    if (!in.atEnd()) in.readLine();
    while (!in.atEnd()) parseAndStoreLine(in.readLine());
    file.close();

    populateSummaryTable();
    calculateAndPopulateResultTable();
    setInterfaceState(true);

    statusBar()->showMessage(QString("%1  —  %2 frames loaded")
                                 .arg(QFileInfo(fileName).fileName())
                                 .arg(m_allData.size()));
}

void MainWindow::on_btn_unload_clicked()
{
    m_allData.clear(); m_summaryModel->clear(); m_resultModel->clear(); m_activeFilters.clear();
    setInterfaceState(false);
    statusBar()->showMessage("File closed.");
}

void MainWindow::on_btn_filter_clicked()
{
    QStringList uniqueIDs;
    for (const RawData &d : m_allData) if (!uniqueIDs.contains(d.id)) uniqueIDs.append(d.id);
    uniqueIDs.sort();

    QDialog dlg(this);
    dlg.setWindowTitle("Filter by ID");
    dlg.resize(280, 380);

    QVBoxLayout *lay = new QVBoxLayout(&dlg);
    lay->setSpacing(4);
    lay->setContentsMargins(8, 8, 8, 8);

    QListWidget *lw = new QListWidget(&dlg);
    lw->setSpacing(0);
    for (const QString &id : uniqueIDs) {
        auto *item = new QListWidgetItem(id, lw);
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setCheckState((m_activeFilters.isEmpty() || m_activeFilters.contains(id)) ? Qt::Checked : Qt::Unchecked);
    }
    lay->addWidget(lw);

    QHBoxLayout *btnRow = new QHBoxLayout();
    auto *bAll  = new QPushButton("All",  &dlg);
    auto *bNone = new QPushButton("None", &dlg);
    bAll->setMaximumHeight(22); bNone->setMaximumHeight(22);
    btnRow->addWidget(bAll); btnRow->addWidget(bNone);
    lay->addLayout(btnRow);
    connect(bAll,  &QPushButton::clicked, [lw]{ for(int i=0;i<lw->count();i++) lw->item(i)->setCheckState(Qt::Checked); });
    connect(bNone, &QPushButton::clicked, [lw]{ for(int i=0;i<lw->count();i++) lw->item(i)->setCheckState(Qt::Unchecked); });

    auto *bb = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dlg);
    lay->addWidget(bb);
    connect(bb, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    connect(bb, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

    if (dlg.exec() == QDialog::Accepted) {
        QStringList sel;
        for (int i = 0; i < lw->count(); i++)
            if (lw->item(i)->checkState() == Qt::Checked) sel << lw->item(i)->text();
        if (sel.isEmpty()) { QMessageBox::warning(this, "Filter", "Select at least one ID."); return; }
        m_activeFilters = sel;
        populateSummaryTable(m_activeFilters);
        calculateAndPopulateResultTable();
        statusBar()->showMessage(QString("Filter: %1 ID(s) active").arg(sel.size()));
    }
}

void MainWindow::on_btn_reset_clicked()
{
    m_activeFilters.clear();
    populateSummaryTable();
    calculateAndPopulateResultTable();
    statusBar()->showMessage("Filter cleared.");
}

void MainWindow::on_btn_conf_clicked()
{
    QStringList uniqueIDs;
    for (const RawData &d : m_allData) if (!uniqueIDs.contains(d.id)) uniqueIDs.append(d.id);
    uniqueIDs.sort();

    ConfigDialog dlg(this);
    dlg.setIDList(uniqueIDs);
    dlg.setConfigList(m_savedConfigs);

    if (dlg.exec() == QDialog::Accepted) {
        m_savedConfigs = dlg.getConfigList();
        saveConfigsToFile();
        calculateAndPopulateResultTable();
        statusBar()->showMessage(QString("%1 decoder(s) active.").arg(m_savedConfigs.size()));
    }
}

void MainWindow::on_btn_export_clicked()
{
    if (m_allData.isEmpty()) { QMessageBox::warning(this, "Export", "No data loaded."); return; }

    QMessageBox msgBox(this);
    msgBox.setWindowTitle("Export");
    msgBox.setText("Select export scope:");
    msgBox.setIcon(QMessageBox::Question);
    auto *bSummary  = msgBox.addButton("Summary Table",  QMessageBox::ActionRole);
    auto *bSelected = msgBox.addButton("Selected ID",    QMessageBox::ActionRole);
    auto *bAll      = msgBox.addButton("All Raw Data",   QMessageBox::ActionRole);
    msgBox.addButton(QMessageBox::Cancel);
    msgBox.exec();

    auto *clicked = msgBox.clickedButton();
    if (!clicked || clicked == msgBox.button(QMessageBox::Cancel)) return;

    QString idFilter;
    if (clicked == bSelected) {
        auto idx = ui->tbl_summary->currentIndex();
        if (!idx.isValid()) { QMessageBox::warning(this, "Export", "Select a row first."); return; }
        idFilter = ui->tbl_summary->model()->index(idx.row(), 0).data().toString();
    }

    QString path = QFileDialog::getSaveFileName(this, "Export CSV", "", "CSV Files (*.csv)");
    if (path.isEmpty()) return;
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) { QMessageBox::critical(this, "Error", "Cannot write file."); return; }
    QTextStream out(&f);
    out.setEncoding(QStringConverter::Utf8);
    out.setGenerateByteOrderMark(true);

    if (clicked == bSummary) {
        out << "ID,Frames,First Seen,Last Seen\n";
        for (int i = 0; i < m_summaryModel->rowCount(); i++)
            out << m_summaryModel->item(i,0)->text() << "," << m_summaryModel->item(i,1)->text() << ","
                << m_summaryModel->item(i,2)->text() << "," << m_summaryModel->item(i,3)->text() << "\n";
    } else {
        out << "ISO Time,Epoch,ID,Data Hex\n";
        for (const RawData &d : m_allData) {
            if (clicked == bSelected && d.id != idFilter) continue;
            out << d.isoTime << "," << d.timestamp << "," << d.id << "," << d.dataHex << "\n";
        }
    }
    f.close();
    statusBar()->showMessage("Exported: " + QFileInfo(path).fileName());
}

void MainWindow::on_btn_exportdata_clicked()
{
    if (m_resultModel->rowCount() == 0) { QMessageBox::warning(this, "Export", "No decoded data to export."); return; }
    QString path = QFileDialog::getSaveFileName(this, "Export Decoded Data", "", "CSV Files (*.csv)");
    if (path.isEmpty()) return;
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) { QMessageBox::critical(this, "Error", "Cannot write file."); return; }
    QTextStream out(&f);
    out.setEncoding(QStringConverter::Utf8);
    out.setGenerateByteOrderMark(true);
    QStringList hdr;
    for (int i = 0; i < m_resultModel->columnCount(); i++) hdr << m_resultModel->headerData(i, Qt::Horizontal).toString();
    out << hdr.join(",") << "\n";
    for (int i = 0; i < m_resultModel->rowCount(); i++) {
        QStringList row;
        for (int j = 0; j < m_resultModel->columnCount(); j++) row << m_resultModel->item(i,j)->text();
        out << row.join(",") << "\n";
    }
    f.close();
    statusBar()->showMessage("Exported: " + QFileInfo(path).fileName());
}

void MainWindow::on_btn_graph_clicked()
{
    if (m_resultModel->rowCount() == 0) { QMessageBox::warning(this, "Plot", "No decoded data. Configure decoders first."); return; }

    QMap<QString, QLineSeries*> seriesMap;
    qint64 minX = std::numeric_limits<qint64>::max(), maxX = std::numeric_limits<qint64>::min();
    double minY = std::numeric_limits<double>::max(), maxY = std::numeric_limits<double>::lowest();

    for (int i = 0; i < m_resultModel->rowCount(); i++) {
        QString ts = m_resultModel->item(i,0)->text();
        QString nm = m_resultModel->item(i,2)->text();
        double  vl = m_resultModel->item(i,4)->text().toDouble();
        QDateTime dt = QDateTime::fromString(ts, "yyyy-MM-dd HH:mm:ss.zzz");
        if (!dt.isValid()) dt = QDateTime::fromString(ts, Qt::ISODate);
        qint64 xv = dt.toMSecsSinceEpoch();
        if (!seriesMap.contains(nm)) { auto *s = new QLineSeries(); s->setName(nm); seriesMap.insert(nm, s); }
        seriesMap[nm]->append(xv, vl);
        minX = qMin(minX, xv); maxX = qMax(maxX, xv);
        minY = qMin(minY, vl); maxY = qMax(maxY, vl);
    }

    auto *chart = new QChart();
    chart->setTitle("Decoded Values  –  Time Series");
    chart->setAnimationOptions(QChart::NoAnimation);
    for (auto s : seriesMap) chart->addSeries(s);

    auto *axX = new QDateTimeAxis; axX->setFormat("HH:mm:ss.zzz"); axX->setTitleText("Time");
    axX->setRange(QDateTime::fromMSecsSinceEpoch(minX), QDateTime::fromMSecsSinceEpoch(maxX));
    chart->addAxis(axX, Qt::AlignBottom);

    double pad = (maxY - minY) * 0.08 + 0.001;
    auto *axY = new QValueAxis; axY->setTitleText("Value"); axY->setRange(minY - pad, maxY + pad);
    chart->addAxis(axY, Qt::AlignLeft);
    for (auto s : seriesMap) { s->attachAxis(axX); s->attachAxis(axY); }

    QDialog dlg(this);
    dlg.setWindowTitle("Plot  –  HEDAP");
    dlg.resize(1000, 600);

    auto *lay = new QVBoxLayout(&dlg);
    lay->setContentsMargins(4, 4, 4, 4);
    auto *view = new QChartView(chart);
    view->setRenderHint(QPainter::Antialiasing);
    lay->addWidget(view);

    auto *btnSave = new QPushButton("Save Image…", &dlg);
    btnSave->setMaximumHeight(24);
    lay->addWidget(btnSave);

    connect(btnSave, &QPushButton::clicked, [view, this]{
        QString p = QFileDialog::getSaveFileName(this, "Save Image", "", "PNG (*.png);;JPEG (*.jpg)");
        if (!p.isEmpty()) { view->grab().save(p); statusBar()->showMessage("Graph saved: " + p); }
    });

    dlg.exec();
}

void MainWindow::onThemeLight() {
    applyTheme(false);
    saveSettings();
    statusBar()->showMessage("Light theme.");
}

void MainWindow::onThemeDark()  {
    applyTheme(true);
    saveSettings();
    statusBar()->showMessage("Dark theme.");
}

void MainWindow::onAbout()
{
    QMessageBox::about(this, "About HEDAP",
                       "<b>HEDAP</b>  –  Hex Data Analysis Platform<br>"
                       "Version 2.1<br><br>"
                       "CSV import · Formula decoding · Time-series plotting");
}

void MainWindow::saveConfigsToFile()
{
    QFile f("configs.json");
    if (!f.open(QIODevice::WriteOnly)) return;
    QJsonArray arr;
    for (const HexConfig &c : m_savedConfigs) { QJsonObject o; c.write(o); arr.append(o); }
    f.write(QJsonDocument(arr).toJson());
}

void MainWindow::loadConfigsFromFile()
{
    QFile f("configs.json");
    if (!f.open(QIODevice::ReadOnly)) return;
    m_savedConfigs.clear();
    for (const QJsonValue &v : QJsonDocument::fromJson(f.readAll()).array()) {
        HexConfig c; c.read(v.toObject()); m_savedConfigs.append(c);
    }
}

void MainWindow::saveSettings()
{
    QJsonObject obj;
    obj["darkTheme"] = m_isDark;

    QFile f("settings.json");
    if (!f.open(QIODevice::WriteOnly)) return;
    f.write(QJsonDocument(obj).toJson());
}

void MainWindow::loadSettings()
{
    QFile f("settings.json");
    if (!f.open(QIODevice::ReadOnly)) return;

    QJsonObject obj = QJsonDocument::fromJson(f.readAll()).object();
    if (obj.contains("darkTheme")) {
        m_isDark = obj["darkTheme"].toBool();
    }
}
