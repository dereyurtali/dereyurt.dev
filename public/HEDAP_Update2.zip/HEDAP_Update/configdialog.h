#ifndef CONFIGDIALOG_H
#define CONFIGDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QSpinBox>
#include <QLabel>
#include <QListWidget>
#include <QPushButton>
#include <QComboBox>
#include <QJsonObject>
#include <QJsonDocument>

// ─────────────────────────────────────────────────────────────────────────────
//  HexConfig: A single parsing/formula configuration for one CAN/UART message ID.
// ─────────────────────────────────────────────────────────────────────────────
struct HexConfig {
    QString name;       // Display name (e.g., "Voltage")
    QString targetID;   // CAN ID or UART identifier (e.g., "0x123")
    QString formula;    // JavaScript expression, 'x' = raw decimal value
    int startByte = 0;  // First byte index in data field (0-based)
    int endByte   = 1;  // Last byte index (inclusive)

    void read(const QJsonObject &json) {
        name      = json["name"].toString();
        targetID  = json["targetID"].toString();
        formula   = json["formula"].toString();
        startByte = json["startByte"].toInt();
        endByte   = json["endByte"].toInt();
    }
    void write(QJsonObject &json) const {
        json["name"]      = name;
        json["targetID"]  = targetID;
        json["formula"]   = formula;
        json["startByte"] = startByte;
        json["endByte"]   = endByte;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  ConfigDialog: Manage a list of HexConfig entries (add / edit / delete).
// ─────────────────────────────────────────────────────────────────────────────
class ConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ConfigDialog(QWidget *parent = nullptr);

    void setConfigList(const QVector<HexConfig>& configs);
    QVector<HexConfig> getConfigList() const;
    void setIDList(const QStringList &ids);

private slots:
    void updateVisualPreview();
    void onNewClicked();
    void onDeleteClicked();
    void onSaveClicked();
    void onItemClicked(QListWidgetItem *item);

private:
    QListWidget *m_listWidget;
    QLineEdit   *m_nameEdit;
    QComboBox   *m_idCombo;
    QLineEdit   *m_formulaEdit;
    QSpinBox    *m_startSpin;
    QSpinBox    *m_endSpin;
    QLabel      *m_previewLabel;

    QVector<HexConfig> m_configs;
    bool m_isEditMode;

    void setupUI();
    void clearForm();
};

#endif // CONFIGDIALOG_H
