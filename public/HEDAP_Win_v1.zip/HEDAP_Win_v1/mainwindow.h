#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QAction>
#include <QChartView>
#include <QComboBox>
#include <QDateTimeAxis>
#include <QFile>
#include <QKeySequence>
#include <QMap>
#include <QTextStream>

#include <QLabel>
#include <QLineSeries>
#include <QMainWindow>
#include <QProgressBar>
#include <QPushButton>
#include <QScrollArea>
#include <QStackedWidget>
#include <QStandardItemModel>
#include <QTableWidget>
#include <QTimer>
#include <QValueAxis>
#include <QVector>
#include <QtCharts>
#include <deque>

#include "canbusworker.h"
#include "configwidget.h"
#include "dbcparser.h"
#include "droppablechartview.h"

class SerialWorker;
class QSplitter;

struct RawData {
  qint64 timestamp;
  QString isoTime;
  QString id;
  QString dataHex;
  quint32 numericId;
  QString cleanHex;
};

// ── Page indices ─────────────────────────────────────────────────────────────
enum PageIndex {
  PAGE_WELCOME = 0,
  PAGE_CSV = 1,
  PAGE_LIVE = 2,
  PAGE_DECODERS = 3,
  PAGE_GRAPH = 4
};

// ── Security constants ──────────────────────────────────────────────────────
static constexpr int MAX_CSV_ROWS = 500000;     // MED-1: cap in-memory rows
static constexpr int MAX_PENDING_LINES = 10000; // MED-2: cap serial buffer

// ── User-configurable settings ───────────────────────────────────────────────
struct AppSettings {
  // Live Monitor
  int  liveWindowSec        = 30;   // rolling chart window (seconds)
  bool autoReconnect        = true; // auto-retry on unexpected disconnect
  int  reconnectIntervalSec = 2;    // seconds between reconnect attempts
  // Graph & Display
  int  graphMaxPts          = 2000; // downsampling cap for graph page plots
  int  signalDecimalPlaces  = 3;    // precision used in hover tooltip + decoded table
  // Recording
  bool autoLogOnConnect     = true; // write raw CSV log on every connection
  QString logDirectory;             // log file location; empty = ~/Documents
  // Interface
  bool darkTheme            = false;
  int  simFps               = 10;   // CSV simulation replay speed (fps)
  // Chart Tools
  bool   deltaModeEnabled    = false;
  bool   statsOverlayEnabled = false;
  bool   fixedYAxis          = false;
  double fixedYMin           = 0.0;
  double fixedYMax           = 100.0;
  bool   rectZoomEnabled     = false;
  QVector<ThresholdConfig> thresholds;
  // Export
  int exportWidth  = 1280;
  int exportHeight = 720;
  // Shortcuts: key = QAction objectName, value = key sequence
  QMap<QString, QKeySequence> shortcuts;
  // DBC Session
  bool rememberLastDbc = true;  // save DBC path to settings on close
  bool restoreLastDbc  = true;  // reload last DBC on next startup
};

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
  Q_OBJECT

public:
  explicit MainWindow(QWidget *parent = nullptr);
  ~MainWindow();

protected:
  void resizeEvent(QResizeEvent *event) override;

private slots:
  void on_btn_load_clicked();
  void on_btn_unload_clicked();
  void on_btn_filter_clicked();
  void on_btn_reset_clicked();
  void on_btn_conf_clicked();
  void on_btn_export_clicked();
  void on_btn_exportdata_clicked();
  void on_btn_graph_clicked();

  void onThemeLight();
  void onThemeDark();
  void onAbout();
  void onUserGuide();
  void openSettings();

  // ── DBC ──────────────────────────────────────────────────────────────────
  void onLoadDBC();
  void onUnloadDBC();

  // ── Page navigation ──────────────────────────────────────────────────────
  void switchPage(int index);

  // ── Live Monitor slots ────────────────────────────────────────────────────
  void onSerialLineReceived(const QString &csvLine);
  void onSerialConnChanged(bool connected);
  void onSerialError(const QString &msg);
  void onSerialStats(int fps);
  void onLiveBatchTimer();
  void onLiveMsgRateTimer();
  void onLiveConnectClicked();
  void onAddChartClicked();
  void onSimToggled();
  void onSimTick();
  void onReconnectTimer();

  void autoImportLiveSignals();

private:
  Ui::MainWindow *ui;

  QVector<RawData> m_allData;
  bool m_csvIsLiveFormat =
      false; // true when loaded CSV is 4-col live-export format
  QStandardItemModel *m_summaryModel;
  QStandardItemModel *m_resultModel;
  QStandardItemModel *m_signalTreeModel = nullptr;

  QStringList m_activeFilters;
  QVector<HexConfig> m_savedConfigs;
  bool m_isDark = false;
  AppSettings m_settings;

  // ── DBC state ─────────────────────────────────────────────────────────────
  DBCParser m_dbcParser;
  QString m_loadedDbcFile; // empty = no DBC loaded

  // ── Sidebar + pages ──────────────────────────────────────────────────────
  QWidget *m_sidebar;
  QStackedWidget *m_pages;
  QVector<QPushButton *> m_navButtons;
  QWidget *m_csvEmptyState;
  QWidget *m_csvDecoderGuide;
  DroppableChartView *m_chartView;
  ConfigWidget *m_configWidget;
  QLabel *m_decoderInfoLabel;

  // ── Live Monitor ──────────────────────────────────────────────────────────
  SerialWorker *m_serialWorker = nullptr;
  CanBusWorker *m_canBusWorker = nullptr;
  QTimer *m_liveBatchTimer = nullptr;
  QTimer *m_liveMsgRateTimer = nullptr;
  QStringList m_livePendingLines;
  bool m_liveConnected = false;
  qint64 m_liveTotalFrames = 0;
  int m_liveFps = 0;

  // Auto-reconnect
  QTimer  *m_reconnectTimer        = nullptr;
  bool     m_intentionalDisconnect = false;
  QString  m_lastPort;
  QString  m_lastProto;        // "CAN_SLCAN" or "UART"
  int      m_lastBaud          = 0;
  QString  m_lastCanPlugin;
  QString  m_lastCanIface;
  int      m_lastCanBitrate    = 0;

  // Live UI widgets (assigned in buildLivePage)
  QLabel *m_liveStatusLabel = nullptr;
  QComboBox *m_liveProtoCombo = nullptr;    // "SLCAN" / "UART" / "PCAN-USB"
  QComboBox *m_livePortCombo = nullptr;     // serial port (SLCAN/UART)
  QComboBox *m_liveBaudCombo = nullptr;     // baud rate (SLCAN/UART)
  QComboBox *m_canPluginCombo = nullptr;    // peakcan, socketcan, ...
  QComboBox *m_canInterfaceCombo = nullptr; // usb0, can0, ...
  QComboBox *m_canBitrateCombo = nullptr;   // 125k, 250k, 500k, 1M
  QWidget *m_serialControls = nullptr;      // container shown for SLCAN/UART
  QWidget *m_canControls = nullptr;         // container shown for PCAN-USB
  QPushButton *m_liveConnectBtn = nullptr;
  QTableWidget *m_liveRawTable = nullptr;
  QTableWidget *m_liveDecodedTable = nullptr;
  QWidget *m_liveGaugesContent = nullptr;
  QTableWidget *m_liveMsgRateTable = nullptr;
  QPushButton *m_addChartBtn = nullptr;
  QVector<DroppableChartView *> m_liveCharts;
  QVector<QLabel *> m_liveIndicators;

  // Simulation (CSV file replay)
  QTimer *m_liveSimTimer = nullptr;
  bool m_liveSimActive = false;
  QPushButton *m_liveSimBtn = nullptr;
  QStringList m_liveSimLines;
  int m_liveSimLineIdx = 0;

  // Per-signal / per-ID live tracking
  QSet<quint32> m_liveSeenIds;              // CAN IDs seen this session
  QHash<QString, int> m_decodedTableRowMap; // "id|name" → row
  QHash<QString, int> m_liveMsgRateCurrent;
  QHash<QString, std::deque<QPair<qint64, double>>>
      m_liveHistory; // session history
  QHash<QString, QProgressBar *> m_gaugeProgressBars;
  QHash<QString, QLabel *> m_gaugeValueLabels;
  QHash<QString, QPair<double, double>> m_gaugeRanges;

  // ── Streaming log (raw CSV lines → disk for complete session recording) ─────
  QFile       *m_liveLogFile    = nullptr;
  QTextStream *m_liveLogStream  = nullptr;
  QString      m_liveLogPath;
  int          m_liveLogFlushCtr = 0;

  void startLiveLog();
  void stopLiveLog();

  // ── Graph settings panel ──────────────────────────────────────────────────
  enum class GraphDataMode { CSV, Live };
  GraphDataMode m_graphDataMode = GraphDataMode::CSV;
  QPushButton *m_rbGraphCSV  = nullptr;
  QPushButton *m_rbGraphLive = nullptr;

  struct GraphSeriesConfig {
    QString name;
    bool enabled = true;
    QColor color = Qt::blue;
    int style = 0; // 0=solid, 1=dash, 2=scatter
  };
  QVector<GraphSeriesConfig> m_graphSeriesConfigs;
  QVBoxLayout *m_graphSignalListLayout;
  void refreshGraphSignalList();
  void plotGraphFromLiveHistory();
  static QVector<QPair<qint64, double>> downsamplePoints(
      const QVector<QPair<qint64, double>> &pts, int maxCount);

  // ── Menu actions (pointers into ui->action_*) ─────────────────────────────
  QAction *m_actLoad;
  QAction *m_actUnload;
  QAction *m_actFilter;
  QAction *m_actReset;
  QAction *m_actConf;
  QAction *m_actGraph;
  QAction *m_actExportCsv;
  QAction *m_actExportData;
  QAction *m_actLoadDBC;
  QAction *m_actUnloadDBC;

  void buildToolbar();
  void buildSidebar();
  QWidget *buildWelcomePage();
  QWidget *buildCsvPage();
  QWidget *buildLivePage();
  QWidget *buildDecodersPage();
  QWidget *buildGraphPage();

  void setupTables();
  void parseAndStoreLine(const QString &line);
  void populateSummaryTable(const QStringList &filterIds = QStringList());
  void populateSignalTree();
  void setInterfaceState(bool hasData);
  void applyTheme(bool dark);
  void resizeSplitterAndColumns();
  void calculateAndPopulateResultTable();
  double evaluateFormula(double rawValue, const QString &formula);

  void loadConfigsFromFile();
  void saveConfigsToFile();

  void loadSettings();
  void saveSettings();
  void applySettings();
  void restoreLastDBC();
  void exportManualDecodersToDBC();

  // ── Live Monitor helpers ───────────────────────────────────────────────────
  void updateLiveStatus();
  void updateLiveGauge(const QString &name, double value);
  void openSignalChart(const QString &signalName = {});
  void openCsvSignalChart(const QString &signalName);

  // ── DBC helpers ───────────────────────────────────────────────────────────
  void showDBCImportDialog();
  void autoImportMatchingSignals();
  QStringList allKnownIDs() const;
  void updateDBCStatus();
};

#endif // MAINWINDOW_H
